// 
// Decompiled by Procyon v0.5.36
// 

package org.spongepowered.asm.mixin.transformer.ext;

import java.io.File;

public interface IDecompiler
{
    void decompile(final File p0);
}
