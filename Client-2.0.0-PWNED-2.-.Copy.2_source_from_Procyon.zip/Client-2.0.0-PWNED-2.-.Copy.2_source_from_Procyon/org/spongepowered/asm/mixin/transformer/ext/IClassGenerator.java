// 
// Decompiled by Procyon v0.5.36
// 

package org.spongepowered.asm.mixin.transformer.ext;

public interface IClassGenerator
{
    byte[] generate(final String p0);
}
