// 
// Decompiled by Procyon v0.5.36
// 

package client.command;

import java.util.Iterator;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.Client;

public class HelpCommand extends Command
{
    public HelpCommand() {
        super("help");
    }
    
    @Override
    public void execute(final String[] commands) {
        Command.sendMessage("Commands: ");
        for (final Command command : Client.commandManager.getCommands()) {
            Command.sendMessage(ChatFormatting.GRAY + Client.commandManager.getPrefix() + command.getName());
        }
    }
}
