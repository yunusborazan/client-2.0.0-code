// 
// Decompiled by Procyon v0.5.36
// 

package client.mixin.loader;

import java.util.Map;
import client.Client;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.launch.MixinBootstrap;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

public class ClientLoader implements IFMLLoadingPlugin
{
    private static boolean isObfuscatedEnvironment;
    
    public ClientLoader() {
        MixinBootstrap.init();
        Mixins.addConfiguration("mixins.client.json");
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
        Client.LOGGER.info(MixinEnvironment.getDefaultEnvironment().getObfuscationContext());
    }
    
    public String[] getASMTransformerClass() {
        return new String[0];
    }
    
    public String getModContainerClass() {
        return null;
    }
    
    public String getSetupClass() {
        return null;
    }
    
    public void injectData(final Map<String, Object> data) {
        ClientLoader.isObfuscatedEnvironment = data.get("runtimeDeobfuscationEnabled");
    }
    
    public String getAccessTransformerClass() {
        return null;
    }
    
    static {
        ClientLoader.isObfuscatedEnvironment = false;
    }
}
