// 
// Decompiled by Procyon v0.5.36
// 

package client.mixin;

import org.spongepowered.asm.mixin.Shadow;
import javax.annotation.Nullable;
import net.minecraft.client.gui.GuiScreen;
import client.gui.impl.background.MainMenuScreen;
import client.gui.impl.background.MenuToggler;
import net.minecraft.client.gui.GuiMainMenu;
import client.Client;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.crash.CrashReport;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import client.util.Util;

@Mixin({ Minecraft.class })
public abstract class MixinMinecraft implements Util
{
    @Inject(method = { "shutdownMinecraftApplet" }, at = { @At("HEAD") })
    private void stopClient(final CallbackInfo callbackInfo) {
        this.unload();
    }
    
    @Redirect(method = { "run" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"))
    public void displayCrashReport(final Minecraft minecraft, final CrashReport crashReport) {
        this.unload();
    }
    
    private void unload() {
        Client.LOGGER.info("Initiated client shutdown.");
        Client.onUnload();
        Client.LOGGER.info("Finished client shutdown.");
    }
    
    @Inject(method = { "runTick()V" }, at = { @At("RETURN") })
    private void runTick(final CallbackInfo callbackInfo) {
        if (Minecraft.func_71410_x().field_71462_r instanceof GuiMainMenu && MenuToggler.getInstance().isOn()) {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)new MainMenuScreen());
        }
    }
    
    @Shadow
    public abstract void func_147108_a(@Nullable final GuiScreen p0);
    
    @Inject(method = { "displayGuiScreen" }, at = { @At("HEAD") })
    private void displayGuiScreen(final GuiScreen screen, final CallbackInfo ci) {
        if (screen instanceof GuiMainMenu) {
            this.func_147108_a(new MainMenuScreen());
        }
    }
}
