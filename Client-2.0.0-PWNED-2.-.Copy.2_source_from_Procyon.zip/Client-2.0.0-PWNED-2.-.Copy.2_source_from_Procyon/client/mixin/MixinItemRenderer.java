// 
// Decompiled by Procyon v0.5.36
// 

package client.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import client.modules.visual.Viewmodel;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.RenderItem;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ RenderItem.class })
public abstract class MixinItemRenderer
{
    @Inject(method = { "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;Z)V" }, at = { @At("INVOKE") })
    public void renderItem(final ItemStack stack, final EntityLivingBase entitylivingbaseIn, final ItemCameraTransforms.TransformType transform, final boolean leftHanded, final CallbackInfo ci) {
        if (Viewmodel.getINSTANCE().isEnabled() && (transform == ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND || transform == ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND)) {
            final Viewmodel changer = Viewmodel.getINSTANCE();
            GlStateManager.func_179152_a((float)Viewmodel.getINSTANCE().sizeX.getCurrentState(), (float)Viewmodel.getINSTANCE().sizeY.getCurrentState(), (float)Viewmodel.getINSTANCE().sizeZ.getCurrentState());
            if (transform.equals((Object)ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND)) {
                GL11.glTranslated((double)(changer.offhandX.getCurrentState() / 4.0f), (double)(changer.offhandY.getCurrentState() / 4.0f), (double)(changer.offhandZ.getCurrentState() / 4.0f));
            }
            else {
                GL11.glTranslated((double)(changer.offsetX.getCurrentState() / 4.0f), (double)(changer.offsetY.getCurrentState() / 4.0f), (double)(changer.offsetZ.getCurrentState() / 4.0f));
            }
        }
    }
}
