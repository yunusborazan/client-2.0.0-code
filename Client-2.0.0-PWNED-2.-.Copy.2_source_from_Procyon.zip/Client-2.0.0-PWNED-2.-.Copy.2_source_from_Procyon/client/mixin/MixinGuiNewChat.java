// 
// Decompiled by Procyon v0.5.36
// 

package client.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.client.Minecraft;
import client.util.ColorUtil;
import client.modules.client.ClickGui;
import client.Client;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.client.gui.ChatLine;
import java.util.List;
import net.minecraft.client.gui.GuiNewChat;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.Gui;

@Mixin(value = { GuiNewChat.class }, priority = 999999999)
public class MixinGuiNewChat extends Gui
{
    @Shadow
    @Final
    public List<ChatLine> field_146253_i;
    private ChatLine chatLine;
    
    @Redirect(method = { "drawChat" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/FontRenderer;drawStringWithShadow(Ljava/lang/String;FFI)I"))
    private int drawStringWithShadow(final FontRenderer fontRenderer, final String text, final float x, final float y, final int color) {
        if (text.contains("§+")) {
            final int[] arrayOfInt = { 1 };
            final char[] stringToCharArray = text.toCharArray();
            float f = 0.0f;
            for (final char c : stringToCharArray) {
                Client.textManager.drawString(String.valueOf(c), x + f, y, ColorUtil.rainbowHud(arrayOfInt[0] * ClickGui.getInstance().rainbowHue.getCurrentState()).getRGB(), true);
                f += Client.textManager.getStringWidth(String.valueOf(c));
                ++arrayOfInt[0];
            }
        }
        else {
            Minecraft.func_71410_x().field_71466_p.func_175063_a(text, x, y, color);
        }
        return 0;
    }
}
