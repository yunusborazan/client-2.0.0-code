// 
// Decompiled by Procyon v0.5.36
// 

package client.manager;

import client.gui.ClientGui;
import org.lwjgl.input.Keyboard;
import java.util.function.Consumer;
import net.minecraftforge.common.MinecraftForge;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Comparator;
import client.events.Render3DEvent;
import client.events.Render2DEvent;
import java.util.Arrays;
import java.util.Iterator;
import client.modules.visual.ESP;
import client.modules.visual.CityESP;
import client.modules.visual.NameTags;
import client.modules.visual.PrestigeChams;
import client.modules.visual.PearlRender;
import client.modules.visual.ShulkerViewer;
import client.modules.visual.SwingAnimations;
import client.modules.visual.AntiFog;
import client.modules.visual.Viewmodel;
import client.modules.visual.ThirdPerson;
import client.modules.visual.BurrowESP;
import client.modules.visual.FullBright;
import client.modules.visual.CrystalChanger;
import client.modules.player.Blink;
import client.modules.player.AntiRotate;
import client.modules.player.Freecam;
import client.modules.player.Interactions;
import client.modules.player.AutoEnderChest;
import client.modules.player.Speedmine;
import client.modules.player.Quiver;
import client.modules.player.HotbarRefill;
import client.modules.player.FastPlace;
import client.modules.player.Burrow;
import client.modules.player.KeyEXP;
import client.modules.movement.FastSwim;
import client.modules.movement.NoFall;
import client.modules.movement.Strafe;
import client.modules.movement.Jesus;
import client.modules.movement.ElytraFlight;
import client.modules.movement.NoSlow;
import client.modules.movement.Velocity;
import client.modules.movement.Phase;
import client.modules.movement.Step;
import client.modules.movement.YPort;
import client.modules.movement.Sprint;
import client.modules.movement.ReverseStep;
import client.modules.miscellaneous.ChorusPredict;
import client.modules.miscellaneous.MiddleClickPearl;
import client.modules.miscellaneous.TabTweaks;
import client.modules.miscellaneous.PingSpoofer;
import client.modules.miscellaneous.ChatModifications;
import client.modules.miscellaneous.TotemPopCounter;
import client.modules.miscellaneous.Spammer;
import client.modules.miscellaneous.MCFriends;
import client.modules.miscellaneous.NoEntityTrace;
import client.modules.miscellaneous.AutoRespawn;
import client.modules.miscellaneous.FakePlayer;
import client.modules.combat.AntiCity;
import client.modules.combat.Criticals;
import client.modules.combat.Aura;
import client.modules.combat.AutoTrap;
import client.modules.combat.PistonAura;
import client.modules.combat.AutoCrystal;
import client.modules.combat.Flatten;
import client.modules.combat.AutoWeb;
import client.modules.combat.Surround;
import client.modules.combat.Offhand;
import client.modules.combat.Holefiller;
import client.modules.combat.AutoArmor;
import client.gui.impl.background.MenuToggler;
import client.modules.client.RPC;
import client.modules.client.Notify;
import client.modules.client.Hud;
import client.modules.client.FontMod;
import client.modules.client.ClickGui;
import java.util.List;
import client.modules.Module;
import java.util.ArrayList;
import client.modules.Feature;

public class ModuleManager extends Feature
{
    public ArrayList<Module> modules;
    public List<Module> sortedModules;
    
    public ModuleManager() {
        this.modules = new ArrayList<Module>();
        this.sortedModules = new ArrayList<Module>();
    }
    
    public void init() {
        this.modules.add(new ClickGui());
        this.modules.add(new FontMod());
        this.modules.add(new Hud());
        this.modules.add(new Notify());
        this.modules.add(new RPC());
        this.modules.add(new MenuToggler());
        this.modules.add(new AutoArmor());
        this.modules.add(new Holefiller());
        this.modules.add(new Offhand());
        this.modules.add(new Surround());
        this.modules.add(new AutoWeb());
        this.modules.add(new Flatten());
        this.modules.add(new AutoCrystal());
        this.modules.add(new PistonAura());
        this.modules.add(new AutoTrap());
        this.modules.add(new Aura());
        this.modules.add(new Criticals());
        this.modules.add(new AntiCity());
        this.modules.add(new FakePlayer());
        this.modules.add(new AutoRespawn());
        this.modules.add(new NoEntityTrace());
        this.modules.add(new MCFriends());
        this.modules.add(new Spammer());
        this.modules.add(new TotemPopCounter());
        this.modules.add(new ChatModifications());
        this.modules.add(new PingSpoofer());
        this.modules.add(new TabTweaks());
        this.modules.add(new MiddleClickPearl());
        this.modules.add(new ChorusPredict());
        this.modules.add(new ReverseStep());
        this.modules.add(new Sprint());
        this.modules.add(new YPort());
        this.modules.add(new Step());
        this.modules.add(new Phase());
        this.modules.add(new Velocity());
        this.modules.add(new NoSlow());
        this.modules.add(new ElytraFlight());
        this.modules.add(new Jesus());
        this.modules.add(new Strafe());
        this.modules.add(new NoFall());
        this.modules.add(new FastSwim());
        this.modules.add(new KeyEXP());
        this.modules.add(new Burrow());
        this.modules.add(new FastPlace());
        this.modules.add(new HotbarRefill());
        this.modules.add(new Quiver());
        this.modules.add(new Speedmine());
        this.modules.add(new AutoEnderChest());
        this.modules.add(new Interactions());
        this.modules.add(new Freecam());
        this.modules.add(new AntiRotate());
        this.modules.add(new Blink());
        this.modules.add(new CrystalChanger());
        this.modules.add(new FullBright());
        this.modules.add(new BurrowESP());
        this.modules.add(new ThirdPerson());
        this.modules.add(new Viewmodel());
        this.modules.add(new AntiFog());
        this.modules.add(new SwingAnimations());
        this.modules.add(new ShulkerViewer());
        this.modules.add(new PearlRender());
        this.modules.add(new PrestigeChams());
        this.modules.add(new NameTags());
        this.modules.add(new CityESP());
        this.modules.add(new ESP());
    }
    
    public Module getModuleByName(final String name) {
        for (final Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(name)) {
                continue;
            }
            return module;
        }
        return null;
    }
    
    public <T extends Module> T getModuleByClass(final Class<T> clazz) {
        for (final Module module : this.modules) {
            if (!clazz.isInstance(module)) {
                continue;
            }
            return (T)module;
        }
        return null;
    }
    
    public boolean isModuleEnabled(final String name) {
        final Module module = this.getModuleByName(name);
        return module != null && module.isOn();
    }
    
    public Module getModuleByDisplayName(final String displayName) {
        for (final Module module : this.modules) {
            if (!module.getDisplayName().equalsIgnoreCase(displayName)) {
                continue;
            }
            return module;
        }
        return null;
    }
    
    public ArrayList<Module> getEnabledModules() {
        final ArrayList<Module> enabledModules = new ArrayList<Module>();
        for (final Module module : this.modules) {
            if (!module.isEnabled()) {
                continue;
            }
            enabledModules.add(module);
        }
        return enabledModules;
    }
    
    public ArrayList<Module> getModulesByCategory(final Module.Category category) {
        final ArrayList<Module> modulesCategory = new ArrayList<Module>();
        final ArrayList<Module> list;
        this.modules.forEach(module -> {
            if (module.getCategory() == category) {
                list.add(module);
            }
            return;
        });
        return modulesCategory;
    }
    
    public List<Module.Category> getCategories() {
        return Arrays.asList(Module.Category.values());
    }
    
    public void onLoad() {
        this.modules.forEach(Module::onLoad);
    }
    
    public void onUpdate() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
    }
    
    public void onTick() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
    }
    
    public void onRender2D(final Render2DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
    }
    
    public void onRender3D(final Render3DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
    }
    
    public void sortModules(final boolean reverse) {
        this.sortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1))).collect((Collector<? super Object, ?, List<Module>>)Collectors.toList());
    }
    
    public void onLogout() {
        this.modules.forEach(Module::onLogout);
    }
    
    public void onLogin() {
        this.modules.forEach(Module::onLogin);
        if (Strafe.getInstance().isEnabled()) {
            Strafe.getInstance().disable();
            Strafe.getInstance().enable();
        }
    }
    
    public void onUnload() {
        this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
        this.modules.forEach(Module::onUnload);
    }
    
    public void onUnloadPost() {
        for (final Module module : this.modules) {
            module.enabled.setValue(false);
        }
    }
    
    public void onKeyPressed(final int eventKey) {
        if (eventKey == 0 || !Keyboard.getEventKeyState() || ModuleManager.mc.field_71462_r instanceof ClientGui) {
            return;
        }
        this.modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey) {
                module.toggle();
            }
        });
    }
}
