// 
// Decompiled by Procyon v0.5.36
// 

package client.manager;

import client.events.DeathEvent;
import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.network.play.client.CPacketUseEntity;
import client.events.PacketEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.Client;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import client.util.MathUtil;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.Packet;
import java.util.List;
import client.modules.Feature;

public class PacketManager extends Feature
{
    private final List<Packet<?>> noEventPackets;
    public final ConcurrentHashMap<String, Integer> targets;
    private double totalDeaths;
    private double totalKills;
    private int currentKills;
    
    public PacketManager() {
        this.noEventPackets = new ArrayList<Packet<?>>();
        this.targets = new ConcurrentHashMap<String, Integer>();
    }
    
    public void sendPacketNoEvent(final Packet<?> packet) {
        if (packet != null && !Feature.nullCheck()) {
            this.noEventPackets.add(packet);
            PacketManager.mc.field_71439_g.field_71174_a.func_147297_a((Packet)packet);
        }
    }
    
    public boolean shouldSendPacket(final Packet<?> packet) {
        if (this.noEventPackets.contains(packet)) {
            this.noEventPackets.remove(packet);
            return false;
        }
        return true;
    }
    
    public int getCurrentKills() {
        return this.currentKills;
    }
    
    public String getKD() {
        if (this.totalDeaths == 0.0) {
            return "" + this.totalKills;
        }
        return "" + MathUtil.round(this.totalKills / this.totalDeaths, 2);
    }
    
    public String getTotalKills() {
        return "" + this.totalKills;
    }
    
    public String getTotalDeaths() {
        return "" + this.totalDeaths;
    }
    
    public void addDeath() {
        ++this.totalDeaths;
        this.currentKills = 0;
    }
    
    public void onUpdate() {
        this.targets.forEach((name, timeout) -> {
            if (timeout <= 0) {
                this.targets.remove(name);
            }
            else {
                this.targets.put(name, timeout - 1);
            }
        });
    }
    
    @SubscribeEvent
    public void onAttackEntity(final AttackEntityEvent event) {
        if (event.getTarget() instanceof EntityPlayer && !Client.friendManager.isFriend(event.getEntityPlayer().func_70005_c_())) {
            this.targets.put(event.getTarget().func_70005_c_(), 20);
        }
    }
    
    @SubscribeEvent
    public void onSendAttackPacket(final PacketEvent.Send event) {
        final CPacketUseEntity packet;
        if (event.getPacket() instanceof CPacketUseEntity && (packet = event.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK && packet.func_149564_a((World)PacketManager.mc.field_71441_e) instanceof EntityPlayer && !Client.friendManager.isFriend(Objects.requireNonNull(packet.func_149564_a((World)PacketManager.mc.field_71441_e)).func_70005_c_())) {
            this.targets.put(Objects.requireNonNull(packet.func_149564_a((World)PacketManager.mc.field_71441_e)).func_70005_c_(), 20);
        }
    }
    
    @SubscribeEvent
    public void onEntityDeath(final DeathEvent event) {
        if (this.targets.containsKey(event.player.func_70005_c_())) {
            ++this.totalKills;
            ++this.currentKills;
            this.targets.remove(event.player.func_70005_c_());
        }
    }
}
