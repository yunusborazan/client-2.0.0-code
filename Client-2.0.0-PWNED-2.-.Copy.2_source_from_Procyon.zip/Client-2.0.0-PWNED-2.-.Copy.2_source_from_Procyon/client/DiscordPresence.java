// 
// Decompiled by Procyon v0.5.36
// 

package client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRichPresence;
import club.minnced.discord.rpc.DiscordRPC;

public class DiscordPresence
{
    private static final DiscordRPC rpc;
    public static DiscordRichPresence presence;
    private static Thread thread;
    private static final int index;
    
    public static void start() {
        final DiscordEventHandlers handlers = new DiscordEventHandlers();
        DiscordPresence.rpc.Discord_Initialize("866743885722812467", handlers, true, "");
        DiscordPresence.presence.startTimestamp = System.currentTimeMillis() / 1000L;
        DiscordPresence.presence.details = ((Minecraft.func_71410_x().field_71462_r instanceof GuiMainMenu) ? "In the main menu." : ("Playing " + ((Minecraft.func_71410_x().field_71422_O != null) ? " multiplayer." : " singleplayer.")));
        DiscordPresence.presence.state = "Winning (Like always)";
        DiscordPresence.presence.largeImageKey = "LogoButBetter";
        DiscordPresence.presence.largeImageText = "Client 2.0.0";
        DiscordPresence.rpc.Discord_UpdatePresence(DiscordPresence.presence);
        DiscordRichPresence presence;
        String string;
        (DiscordPresence.thread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                DiscordPresence.rpc.Discord_RunCallbacks();
                presence = DiscordPresence.presence;
                if (Minecraft.func_71410_x().field_71462_r instanceof GuiMainMenu) {
                    string = "In the main menu.";
                }
                else {
                    string = "Playing " + ((Minecraft.func_71410_x().field_71422_O != null) ? " multiplayer." : " singleplayer.");
                }
                presence.details = string;
                DiscordPresence.presence.state = "Winning (Like always)";
                DiscordPresence.rpc.Discord_UpdatePresence(DiscordPresence.presence);
                try {
                    Thread.sleep(2000L);
                }
                catch (InterruptedException ex) {}
            }
        }, "RPC-Callback-Handler")).start();
    }
    
    public static void stop() {
        if (DiscordPresence.thread != null && !DiscordPresence.thread.isInterrupted()) {
            DiscordPresence.thread.interrupt();
        }
        DiscordPresence.rpc.Discord_Shutdown();
    }
    
    static {
        index = 1;
        rpc = DiscordRPC.INSTANCE;
        DiscordPresence.presence = new DiscordRichPresence();
    }
}
