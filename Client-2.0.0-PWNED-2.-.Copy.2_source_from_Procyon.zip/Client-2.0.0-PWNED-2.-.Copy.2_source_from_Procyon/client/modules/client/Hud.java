// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.client;

import java.util.function.ToIntFunction;
import net.minecraft.init.Items;
import client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import java.util.Iterator;
import java.util.List;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.Client;
import java.util.Collection;
import net.minecraft.potion.PotionEffect;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import client.util.ColorUtil;
import client.events.Render2DEvent;
import net.minecraft.client.settings.GameSettings;
import client.gui.impl.setting.Setting;
import net.minecraft.item.ItemStack;
import client.modules.Module;

public class Hud extends Module
{
    private static Hud INSTANCE;
    private int color;
    private static final ItemStack totem;
    private static final ItemStack crystals;
    private static final ItemStack gapples;
    private static final ItemStack exp;
    public Setting<Boolean> rainbow;
    public Setting<Boolean> sideway;
    public Setting<Integer> rainbowDelay;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    public Setting<Boolean> fovSetting;
    public Setting<Float> fov;
    Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Boolean> watermark;
    public Setting<Integer> watermarkX;
    public Setting<Integer> watermarkY;
    public Setting<Boolean> welcomer;
    public Setting<Integer> welcomerX;
    public Setting<Integer> welcomerY;
    public Setting<Boolean> welcomerAlign;
    public Setting<Boolean> nameHider;
    public Setting<String> name;
    private final Setting<Boolean> potionEffects;
    private final Setting<Boolean> bottomAlign;
    private final Setting<Boolean> coords;
    private final Setting<Boolean> armor;
    private final Setting<Boolean> percent;
    private final Setting<Boolean> itemInfo;
    
    public Hud() {
        super("Hud", "Displays strings on your screen", Category.CORE);
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)true));
        this.sideway = (Setting<Boolean>)this.register(new Setting("RainbowSideway", (T)true, v -> this.rainbow.getCurrentState()));
        this.rainbowDelay = (Setting<Integer>)this.register(new Setting("Delay", (T)200, (T)0, (T)600, v -> this.rainbow.getCurrentState()));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", (T)150.0f, (T)1.0f, (T)255.0f, v -> this.rainbow.getCurrentState()));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", (T)150.0f, (T)1.0f, (T)255.0f, v -> this.rainbow.getCurrentState()));
        this.fovSetting = (Setting<Boolean>)this.register(new Setting("Fov", (T)false));
        this.fov = (Setting<Float>)this.register(new Setting("FovValue", (T)150.0f, (T)0.0f, (T)180.0f));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.watermark = (Setting<Boolean>)this.register(new Setting("Watermark", (T)false));
        this.watermarkX = (Setting<Integer>)this.register(new Setting("WatermarkX", (T)0, (T)0, (T)900, v -> this.watermark.getCurrentState()));
        this.watermarkY = (Setting<Integer>)this.register(new Setting("WatermarkY", (T)0, (T)0, (T)530, v -> this.watermark.getCurrentState()));
        this.welcomer = (Setting<Boolean>)this.register(new Setting("Welcomer", (T)false));
        this.welcomerX = (Setting<Integer>)this.register(new Setting("WelcomerX", (T)0, (T)0, (T)900, v -> this.welcomer.getCurrentState() && !this.welcomerAlign.getCurrentState()));
        this.welcomerY = (Setting<Integer>)this.register(new Setting("WelcomerY", (T)0, (T)0, (T)530, v -> this.welcomer.getCurrentState() && !this.welcomerAlign.getCurrentState()));
        this.welcomerAlign = (Setting<Boolean>)this.register(new Setting("WelcomerAlign", (T)false, v -> this.welcomer.getCurrentState()));
        this.nameHider = (Setting<Boolean>)this.register(new Setting("NameHider", (T)false));
        this.name = (Setting<String>)this.register(new Setting("Name...", (T)"popbob"));
        this.potionEffects = (Setting<Boolean>)this.register(new Setting("PotionEffects", (T)false));
        this.bottomAlign = (Setting<Boolean>)this.register(new Setting("BottomAlign", (T)false, v -> this.potionEffects.getCurrentState()));
        this.coords = (Setting<Boolean>)this.register(new Setting("Coords", (T)false, "Your current coordinates"));
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)false, "ArmorHUD"));
        this.percent = (Setting<Boolean>)this.register(new Setting("Percent", (T)true, v -> this.armor.getCurrentState()));
        this.itemInfo = (Setting<Boolean>)this.register(new Setting("ItemInfo", (T)true));
        this.setInstance();
    }
    
    public static Hud getInstance() {
        if (Hud.INSTANCE == null) {
            Hud.INSTANCE = new Hud();
        }
        return Hud.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        if (this.fovSetting.getCurrentState()) {
            Hud.mc.field_71474_y.func_74304_a(GameSettings.Options.FOV, (float)this.fov.getCurrentState());
        }
    }
    
    private void setInstance() {
        Hud.INSTANCE = this;
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        if (fullNullCheck()) {
            return;
        }
        this.color = ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState());
        final String string = "Client 2.0.0-b12";
        final String welcome = this.nameHider.getCurrentState() ? ("Weclome to Client 2.0.0-b12 " + this.name.getCurrentState()) : ("Weclome to Client 2.0.0-b12 " + Hud.mc.field_71439_g.func_70005_c_());
        if (this.watermark.getCurrentState()) {
            if (this.rainbow.getCurrentState()) {
                if (!this.sideway.getCurrentState()) {
                    this.renderer.drawString(string, this.watermarkX.getCurrentState(), this.watermarkY.getCurrentState(), ColorUtil.rainbowHud(this.rainbowDelay.getCurrentState()).getRGB(), true);
                }
                else {
                    final int[] arrayOfInt = { 1 };
                    final char[] stringToCharArray = string.toCharArray();
                    float f = 0.0f;
                    for (final char c : stringToCharArray) {
                        this.renderer.drawString(String.valueOf(c), this.watermarkX.getCurrentState() + f, this.watermarkY.getCurrentState(), ColorUtil.rainbowHud(arrayOfInt[0] * this.rainbowDelay.getCurrentState()).getRGB(), true);
                        f += this.renderer.getStringWidth(String.valueOf(c));
                        ++arrayOfInt[0];
                    }
                }
            }
            else {
                this.renderer.drawString(string, this.watermarkX.getCurrentState(), this.watermarkY.getCurrentState(), this.color, true);
            }
        }
        if (this.welcomer.getCurrentState()) {
            float f2 = 0.0f;
            if (this.rainbow.getCurrentState()) {
                if (!this.sideway.getCurrentState()) {
                    this.renderer.drawString(welcome, ((boolean)this.welcomerAlign.getCurrentState()) ? (400.0f + f2) : (this.welcomerX.getCurrentState() + f2), this.welcomerY.getCurrentState(), ColorUtil.rainbowHud(this.rainbowDelay.getCurrentState()).getRGB(), true);
                }
                else {
                    final int[] arrayOfInt2 = { 1 };
                    final char[] charArray;
                    final char[] stringToCharArray2 = charArray = welcome.toCharArray();
                    for (final char c : charArray) {
                        this.renderer.drawString(String.valueOf(c), ((boolean)this.welcomerAlign.getCurrentState()) ? (400.0f + f2) : (this.welcomerX.getCurrentState() + f2), this.welcomerY.getCurrentState(), ColorUtil.rainbowHud(arrayOfInt2[0] * this.rainbowDelay.getCurrentState()).getRGB(), true);
                        f2 += this.renderer.getStringWidth(String.valueOf(c));
                        ++arrayOfInt2[0];
                    }
                }
            }
            else {
                this.renderer.drawString(welcome, ((boolean)this.welcomerAlign.getCurrentState()) ? (400.0f + f2) : (this.welcomerX.getCurrentState() + f2), this.welcomerY.getCurrentState(), this.color, true);
            }
        }
        if (this.potionEffects.getCurrentState()) {
            if (fullNullCheck()) {
                return;
            }
            final int width = this.renderer.scaledWidth;
            final int height = this.renderer.scaledHeight;
            this.color = ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState());
            int i = (Hud.mc.field_71462_r instanceof GuiChat && this.bottomAlign.getCurrentState()) ? 13 : (this.bottomAlign.getCurrentState() ? -3 : 0);
            final List<PotionEffect> effects = new ArrayList<PotionEffect>(Minecraft.func_71410_x().field_71439_g.func_70651_bq());
            if (this.bottomAlign.getCurrentState()) {
                for (final PotionEffect potionEffect : effects) {
                    final String str = Client.potionManager.getColoredPotionString(potionEffect);
                    i += 10;
                    this.renderer.drawString(str, (float)(width - this.renderer.getStringWidth(str) - 2), (float)(height - 2 - i), potionEffect.func_188419_a().func_76401_j(), true);
                }
            }
            else {
                for (final PotionEffect potionEffect : effects) {
                    final String str = Client.potionManager.getColoredPotionString(potionEffect);
                    this.renderer.drawString(str, (float)(width - this.renderer.getStringWidth(str) - 2), (float)(2 + i++ * 10), potionEffect.func_188419_a().func_76401_j(), true);
                }
            }
        }
        final boolean inHell = Hud.mc.field_71441_e.func_180494_b(Hud.mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
        int j = (Hud.mc.field_71462_r instanceof GuiChat) ? 14 : 0;
        final int height2 = this.renderer.scaledHeight;
        final int posX = (int)Hud.mc.field_71439_g.field_70165_t;
        final int posY = (int)Hud.mc.field_71439_g.field_70163_u;
        final int posZ = (int)Hud.mc.field_71439_g.field_70161_v;
        final float nether = inHell ? 8.0f : 0.125f;
        final int hposX = (int)(Hud.mc.field_71439_g.field_70165_t * nether);
        final int hposZ = (int)(Hud.mc.field_71439_g.field_70161_v * nether);
        final String coordinates = ChatFormatting.WHITE + "XYZ " + ChatFormatting.RESET + (inHell ? (posX + ", " + posY + ", " + posZ + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + hposX + ", " + hposZ + ChatFormatting.WHITE + "]" + ChatFormatting.RESET) : (posX + ", " + posY + ", " + posZ + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + hposX + ", " + hposZ + ChatFormatting.WHITE + "]"));
        final String coords = this.coords.getCurrentState() ? coordinates : "";
        j += 10;
        if (ClickGui.getInstance().rainbow.getCurrentState()) {
            final String rainbowCoords = this.coords.getCurrentState() ? ("XYZ " + (inHell ? (posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]") : (posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]"))) : "";
            if (ClickGui.getInstance().rainbowModeHud.getCurrentState() == ClickGui.rainbowMode.Static) {
                this.renderer.drawString(rainbowCoords, 2.0f, (float)(height2 - j), ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getCurrentState()).getRGB(), true);
            }
            else {
                final int[] counter3 = { 1 };
                final char[] stringToCharArray3 = rainbowCoords.toCharArray();
                float u = 0.0f;
                for (final char c2 : stringToCharArray3) {
                    this.renderer.drawString(String.valueOf(c2), 2.0f + u, (float)(height2 - j), ColorUtil.rainbow(counter3[0] * ClickGui.getInstance().rainbowHue.getCurrentState()).getRGB(), true);
                    u += this.renderer.getStringWidth(String.valueOf(c2));
                    ++counter3[0];
                }
            }
        }
        else {
            this.renderer.drawString(coords, 2.0f, (float)(height2 - j), this.color, true);
        }
        if (this.armor.getCurrentState()) {
            this.renderArmorHUD(this.percent.getCurrentState());
        }
        if (this.itemInfo.getCurrentState()) {
            this.renderTotemHUD();
            this.renderCrystalHud();
            this.renderExpHud();
            this.renderGapsHud();
        }
    }
    
    public void renderArmorHUD(final boolean percent) {
        final int width = this.renderer.scaledWidth;
        final int height = this.renderer.scaledHeight;
        GlStateManager.func_179098_w();
        final int i = width / 2;
        int iteration = 0;
        final int y = height - 55 - ((Hud.mc.field_71439_g.func_70090_H() && Hud.mc.field_71442_b.func_78763_f()) ? 10 : 0);
        for (final ItemStack is : Hud.mc.field_71439_g.field_71071_by.field_70460_b) {
            ++iteration;
            if (is.func_190926_b()) {
                continue;
            }
            final int x = i - 90 + (9 - iteration) * 20 + 2;
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0f;
            RenderUtil.itemRender.func_180450_b(is, x, y);
            RenderUtil.itemRender.func_180453_a(Hud.mc.field_71466_p, is, x, y, "");
            RenderUtil.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            final String s = (is.func_190916_E() > 1) ? (is.func_190916_E() + "") : "";
            this.renderer.drawStringWithShadow(s, (float)(x + 19 - 2 - this.renderer.getStringWidth(s)), (float)(y + 9), 16777215);
            if (!percent) {
                continue;
            }
            final float green = (is.func_77958_k() - (float)is.func_77952_i()) / is.func_77958_k();
            final float red = 1.0f - green;
            final int dmg = 100 - (int)(red * 100.0f);
            this.renderer.drawStringWithShadow(dmg + "", (float)(x + 8 - this.renderer.getStringWidth(dmg + "") / 2), (float)(y - 11), ColorUtil.toRGBA((int)(red * 255.0f), (int)(green * 255.0f), 0));
        }
        GlStateManager.func_179126_j();
        GlStateManager.func_179140_f();
    }
    
    public void renderTotemHUD() {
        int totems = Hud.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum();
        if (Hud.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            totems += Hud.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        if (totems > 0) {
            GlStateManager.func_179098_w();
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0f;
            RenderUtil.itemRender.func_180450_b(Hud.totem, 0, 20);
            RenderUtil.itemRender.func_180453_a(Hud.mc.field_71466_p, Hud.totem, 0, 20, "");
            RenderUtil.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            this.renderer.drawStringWithShadow(totems + "", 10.0f, 30.0f, 16777215);
            GlStateManager.func_179126_j();
            GlStateManager.func_179140_f();
        }
    }
    
    public void renderCrystalHud() {
        int totems = Hud.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_185158_cP).mapToInt(ItemStack::func_190916_E).sum();
        if (Hud.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            totems += Hud.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        if (totems > 0) {
            GlStateManager.func_179098_w();
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0f;
            RenderUtil.itemRender.func_180450_b(Hud.crystals, 0, 37);
            RenderUtil.itemRender.func_180453_a(Hud.mc.field_71466_p, Hud.crystals, 0, 37, "");
            RenderUtil.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            this.renderer.drawStringWithShadow(totems + "", 10.0f, 47.0f, 16777215);
            GlStateManager.func_179126_j();
            GlStateManager.func_179140_f();
        }
    }
    
    public void renderExpHud() {
        int totems = Hud.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_151062_by).mapToInt(ItemStack::func_190916_E).sum();
        if (Hud.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151062_by) {
            totems += Hud.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        if (totems > 0) {
            GlStateManager.func_179098_w();
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0f;
            RenderUtil.itemRender.func_180450_b(Hud.exp, 0, 54);
            RenderUtil.itemRender.func_180453_a(Hud.mc.field_71466_p, Hud.exp, 10, 54, "");
            RenderUtil.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            this.renderer.drawStringWithShadow(totems + "", 10.0f, 64.0f, 16777215);
            GlStateManager.func_179126_j();
            GlStateManager.func_179140_f();
        }
    }
    
    public void renderGapsHud() {
        int totems = Hud.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_151153_ao).mapToInt(ItemStack::func_190916_E).sum();
        if (Hud.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao) {
            totems += Hud.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        if (totems > 0) {
            GlStateManager.func_179098_w();
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0f;
            RenderUtil.itemRender.func_180450_b(Hud.gapples, 0, 69);
            RenderUtil.itemRender.func_180453_a(Hud.mc.field_71466_p, Hud.gapples, 0, 69, "");
            RenderUtil.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            this.renderer.drawStringWithShadow(totems + "", 10.0f, 79.0f, 16777215);
            GlStateManager.func_179126_j();
            GlStateManager.func_179140_f();
        }
    }
    
    static {
        Hud.INSTANCE = new Hud();
        totem = new ItemStack(Items.field_190929_cY);
        crystals = new ItemStack(Items.field_185158_cP);
        gapples = new ItemStack(Items.field_151153_ao);
        exp = new ItemStack(Items.field_151062_by);
    }
}
