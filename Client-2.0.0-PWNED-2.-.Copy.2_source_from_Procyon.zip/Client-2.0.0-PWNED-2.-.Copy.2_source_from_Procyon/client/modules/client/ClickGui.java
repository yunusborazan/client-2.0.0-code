// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.client;

import net.minecraft.client.gui.GuiScreen;
import client.gui.ClientGui;
import client.util.Util;
import client.util.HoleUtil;
import client.gui.impl.background.MainMenuButton;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.Client;
import client.events.ClientEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class ClickGui extends Module
{
    private static ClickGui INSTANCE;
    public Setting<Gui> gui;
    public Setting<Integer> newtopred;
    public Setting<Integer> newtopgreen;
    public Setting<Integer> newtopblue;
    public Setting<Integer> newtopalpha;
    public Setting<Integer> newared;
    public Setting<Integer> newagreen;
    public Setting<Integer> newablue;
    public Setting<Integer> newaalpha;
    public Setting<Integer> newred;
    public Setting<Integer> newgreen;
    public Setting<Integer> newblue;
    public Setting<Integer> newtheAlpha;
    public Setting<Integer> newbgAlpha;
    public Setting<Integer> newthirdRed;
    public Setting<Integer> newthirdGreen;
    public Setting<Integer> newthirdBlue;
    public Setting<Integer> newthirdAlpha;
    public Setting<Boolean> topRectTextBold;
    public Setting<Rect> topRect;
    public Setting<Roundedness> roundedness;
    public Setting<Bottom> bottomRect;
    public Setting<Boolean> particles;
    public Setting<Integer> particleLength;
    public Setting<Integer> particlered;
    public Setting<Integer> particlegreen;
    public Setting<Integer> particleblue;
    public Setting<Boolean> snowing;
    public Setting<Boolean> blur;
    public Setting<Align> componentAlign;
    public Setting<String> prefix;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> b_alpha;
    public Setting<Boolean> disabled;
    public Setting<Integer> d_red;
    public Setting<Integer> d_green;
    public Setting<Integer> d_blue;
    public Setting<Integer> d_alpha;
    public Setting<Integer> alpha;
    public Setting<Integer> topRed;
    public Setting<Integer> topGreen;
    public Setting<Integer> topBlue;
    public Setting<Integer> secondAlpha;
    public Setting<Boolean> outline;
    public Setting<Integer> o_red;
    public Setting<Integer> o_green;
    public Setting<Integer> o_blue;
    public Setting<Integer> o_alpha;
    public Setting<Boolean> button;
    public Setting<Button> buttonButton;
    public Setting<Boolean> rainbow;
    public Setting<rainbowMode> rainbowModeHud;
    public Setting<Integer> rainbowHue;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    
    public ClickGui() {
        super("ClickGui", "Opens the ClickGui", Category.CORE);
        this.gui = (Setting<Gui>)this.register(new Setting("Gui", (T)Gui.OLD));
        this.newtopred = (Setting<Integer>)this.register(new Setting("TopRed", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newtopgreen = (Setting<Integer>)this.register(new Setting("TopGreen", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newtopblue = (Setting<Integer>)this.register(new Setting("TopBlue", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newtopalpha = (Setting<Integer>)this.register(new Setting("TopAlpha", (T)110, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newared = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newagreen = (Setting<Integer>)this.register(new Setting("Green", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newablue = (Setting<Integer>)this.register(new Setting("Blue", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newaalpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)110, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newred = (Setting<Integer>)this.register(new Setting("SideRed", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newgreen = (Setting<Integer>)this.register(new Setting("SideGreen", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newblue = (Setting<Integer>)this.register(new Setting("SideBlue", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newtheAlpha = (Setting<Integer>)this.register(new Setting("SideAlpha", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newbgAlpha = (Setting<Integer>)this.register(new Setting("BackGroundAlpha", (T)27, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newthirdRed = (Setting<Integer>)this.register(new Setting("ThirdRed", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newthirdGreen = (Setting<Integer>)this.register(new Setting("ThirdGreen", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newthirdBlue = (Setting<Integer>)this.register(new Setting("ThirdBlue", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.newthirdAlpha = (Setting<Integer>)this.register(new Setting("ThirdAlpha", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.NEW));
        this.topRectTextBold = (Setting<Boolean>)this.register(new Setting("TopRectTextBold", (T)true, v -> this.gui.getCurrentState() == Gui.OLD));
        this.topRect = (Setting<Rect>)this.register(new Setting("TopRectangle", (T)Rect.ROUNDED, v -> this.gui.getCurrentState() == Gui.OLD));
        this.roundedness = (Setting<Roundedness>)this.register(new Setting("Roundedness", (T)Roundedness.FULL, v -> this.gui.getCurrentState() == Gui.OLD));
        this.bottomRect = (Setting<Bottom>)this.register(new Setting("BottomRect", (T)Bottom.ROUNDED, v -> this.gui.getCurrentState() == Gui.OLD));
        this.particles = (Setting<Boolean>)this.register(new Setting("Particles", (T)true, v -> this.gui.getCurrentState() == Gui.OLD));
        this.particleLength = (Setting<Integer>)this.register(new Setting("ParticleLength", (T)50, (T)0, (T)300, v -> this.particles.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.particlered = (Setting<Integer>)this.register(new Setting("ParticleRed", (T)255, (T)0, (T)255, v -> this.particles.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.particlegreen = (Setting<Integer>)this.register(new Setting("ParticleGreen", (T)255, (T)0, (T)255, v -> this.particles.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.particleblue = (Setting<Integer>)this.register(new Setting("ParticleBlue", (T)255, (T)0, (T)255, v -> this.particles.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.snowing = (Setting<Boolean>)this.register(new Setting("Snowing", (T)true, v -> this.gui.getCurrentState() == Gui.OLD));
        this.blur = (Setting<Boolean>)this.register(new Setting("Blur", (T)true, v -> this.gui.getCurrentState() == Gui.OLD));
        this.componentAlign = (Setting<Align>)this.register(new Setting("ComponentAlign", (T)Align.LEFT, v -> this.gui.getCurrentState() == Gui.OLD));
        this.prefix = (Setting<String>)this.register(new Setting("Prefix", (T)":", v -> this.gui.getCurrentState() == Gui.OLD));
        this.red = (Setting<Integer>)this.register(new Setting("BackgroundRed", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.green = (Setting<Integer>)this.register(new Setting("BackgroundGreen", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.blue = (Setting<Integer>)this.register(new Setting("BackgroundBlue", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.b_alpha = (Setting<Integer>)this.register(new Setting("BackgroundAlpha", (T)50, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.disabled = (Setting<Boolean>)this.register(new Setting("Disabled", (T)true, v -> this.gui.getCurrentState() == Gui.OLD));
        this.d_red = (Setting<Integer>)this.register(new Setting("DisabledRed", (T)127, (T)0, (T)255, v -> this.disabled.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.d_green = (Setting<Integer>)this.register(new Setting("DisabledGreen", (T)127, (T)0, (T)255, v -> this.disabled.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.d_blue = (Setting<Integer>)this.register(new Setting("DisabledBlue", (T)127, (T)0, (T)255, v -> this.disabled.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.d_alpha = (Setting<Integer>)this.register(new Setting("DisabledAlpha", (T)40, (T)0, (T)255, v -> this.disabled.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.alpha = (Setting<Integer>)this.register(new Setting("EnabledAlpha", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.topRed = (Setting<Integer>)this.register(new Setting("SecondRed", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.topGreen = (Setting<Integer>)this.register(new Setting("SecondGreen", (T)0, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.topBlue = (Setting<Integer>)this.register(new Setting("SecondBlue", (T)150, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.secondAlpha = (Setting<Integer>)this.register(new Setting("SecondAlpha", (T)255, (T)0, (T)255, v -> this.gui.getCurrentState() == Gui.OLD));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)false, v -> this.gui.getCurrentState() == Gui.OLD));
        this.o_red = (Setting<Integer>)this.register(new Setting("OutlineRed", (T)0, (T)0, (T)255, v -> this.outline.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.o_green = (Setting<Integer>)this.register(new Setting("OutlineGreen", (T)0, (T)0, (T)255, v -> this.outline.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.o_blue = (Setting<Integer>)this.register(new Setting("OutlineBlue", (T)150, (T)0, (T)255, v -> this.outline.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.o_alpha = (Setting<Integer>)this.register(new Setting("OutlineAlpha", (T)255, (T)0, (T)255, v -> this.outline.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.button = (Setting<Boolean>)this.register(new Setting("Button", (T)true, v -> this.gui.getCurrentState() == Gui.OLD));
        this.buttonButton = (Setting<Button>)this.register(new Setting("ButtonSort", (T)Button.PLUS, v -> this.button.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)false, v -> this.gui.getCurrentState() == Gui.OLD));
        this.rainbowModeHud = (Setting<rainbowMode>)this.register(new Setting("HRainbowMode", (T)rainbowMode.Static, v -> this.rainbow.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.rainbowHue = (Setting<Integer>)this.register(new Setting("Delay", (T)240, (T)0, (T)600, v -> this.rainbow.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", (T)150.0f, (T)1.0f, (T)255.0f, v -> this.rainbow.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", (T)150.0f, (T)1.0f, (T)255.0f, v -> this.rainbow.getCurrentState() && this.gui.getCurrentState() == Gui.OLD));
        this.setBind(24);
        this.setInstance();
    }
    
    public static ClickGui getInstance() {
        if (ClickGui.INSTANCE == null) {
            ClickGui.INSTANCE = new ClickGui();
        }
        return ClickGui.INSTANCE;
    }
    
    private void setInstance() {
        ClickGui.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
            if (event.getSetting().equals(this.prefix)) {
                Client.commandManager.setPrefix(this.prefix.getPlannedValue());
                Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + Client.commandManager.getPrefix());
            }
            Client.colorManager.setColor(this.red.getPlannedValue(), this.green.getPlannedValue(), this.blue.getPlannedValue(), this.alpha.getPlannedValue());
        }
    }
    
    @Override
    public void onEnable() {
        if (!MainMenuButton.grdnguyferht8gvy34y785g43ynb57gny34875nt34t5bv7n3t7634gny53674t5gv3487256g7826b5342n58gv341tb5763tgb567v32t55gt34()) {
            Client.dsj8rtuf9ynwe87vyn587bw3gy857ybwebgidwuy58g7yw34875y3487yb5g873y583gty57834tyb857t3857t3g4875bt37();
            throw new HoleUtil("Unexpected error occurred during Client launch whilst performing HoleUtil.onRender3D(Render3DEvent event) :: 71");
        }
        Util.mc.func_147108_a((GuiScreen)ClientGui.getClickGui());
    }
    
    @Override
    public void onDisable() {
        Client.configManager.saveConfig("Default");
    }
    
    @Override
    public void onLoad() {
        Client.colorManager.setColor(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState());
        Client.commandManager.setPrefix(this.prefix.getCurrentState());
    }
    
    @Override
    public void onTick() {
        if (!(ClickGui.mc.field_71462_r instanceof ClientGui)) {
            this.disable();
        }
    }
    
    static {
        ClickGui.INSTANCE = new ClickGui();
    }
    
    public enum Gui
    {
        NEW, 
        OLD;
    }
    
    public enum Rect
    {
        ROUNDED, 
        SQUARE;
    }
    
    public enum Roundedness
    {
        TINY, 
        LITTLE, 
        MEDIUM, 
        LARGE, 
        FULL;
    }
    
    public enum Bottom
    {
        ROUNDED, 
        NORMAL;
    }
    
    public enum Align
    {
        LEFT, 
        MIDDLE;
    }
    
    public enum Button
    {
        PLUS, 
        DOT;
    }
    
    public enum rainbowModeArray
    {
        Static, 
        Up;
    }
    
    public enum rainbowMode
    {
        Static, 
        Sideway;
    }
}
