// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.client;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.events.ClientEvent;
import client.Client;
import client.util.TextUtil;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Notify extends Module
{
    private static Notify INSTANCE;
    public Setting<Boolean> chatMessages;
    public Setting<Boolean> rainbowPrefix;
    public Setting<String> command;
    public Setting<String> commandBracket;
    public Setting<String> commandBracket2;
    public Setting<TextUtil.Color> commandColor;
    public Setting<TextUtil.Color> bracketColor;
    
    public Notify() {
        super("Notify", "Notifies things in chat.", Category.CORE);
        this.chatMessages = (Setting<Boolean>)this.register(new Setting("ToggleMessages", (T)true));
        this.rainbowPrefix = (Setting<Boolean>)this.register(new Setting("RainbowPrefix", (T)true));
        this.command = (Setting<String>)this.register(new Setting("NotifyString", (T)"Client 2.0.0"));
        this.commandBracket = (Setting<String>)this.register(new Setting("Bracket", (T)"<"));
        this.commandBracket2 = (Setting<String>)this.register(new Setting("Bracket2", (T)">"));
        this.commandColor = (Setting<TextUtil.Color>)this.register(new Setting("NameColor", (T)TextUtil.Color.WHITE));
        this.bracketColor = (Setting<TextUtil.Color>)this.register(new Setting("BracketColor", (T)TextUtil.Color.WHITE));
        this.setInstance();
    }
    
    public static Notify getInstance() {
        if (Notify.INSTANCE == null) {
            Notify.INSTANCE = new Notify();
        }
        return Notify.INSTANCE;
    }
    
    private void setInstance() {
        Notify.INSTANCE = this;
    }
    
    @Override
    public void onLoad() {
        Client.commandManager.setClientMessage(this.getCommandMessage());
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2 && this.equals(event.getSetting().getFeature())) {
            Client.commandManager.setClientMessage(this.getCommandMessage());
        }
    }
    
    public String getCommandMessage() {
        return TextUtil.coloredString(this.commandBracket.getPlannedValue(), this.bracketColor.getPlannedValue()) + TextUtil.coloredString(this.command.getPlannedValue(), this.commandColor.getPlannedValue()) + TextUtil.coloredString(this.commandBracket2.getPlannedValue(), this.bracketColor.getPlannedValue());
    }
    
    public String getRainbowCommandMessage() {
        final StringBuilder stringBuilder = new StringBuilder(this.getRawCommandMessage());
        stringBuilder.insert(0, "§+");
        stringBuilder.append("§r");
        return stringBuilder.toString();
    }
    
    public String getRawCommandMessage() {
        return this.commandBracket.getCurrentState() + this.command.getCurrentState() + this.commandBracket2.getCurrentState();
    }
    
    static {
        Notify.INSTANCE = new Notify();
    }
}
