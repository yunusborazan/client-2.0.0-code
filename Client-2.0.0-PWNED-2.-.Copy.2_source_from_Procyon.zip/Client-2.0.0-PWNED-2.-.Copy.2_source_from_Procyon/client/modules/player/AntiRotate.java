// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.mixin.AccessorSPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import client.events.PacketEvent;
import client.modules.Module;

public class AntiRotate extends Module
{
    public AntiRotate() {
        super("AntiRotate", "", Category.PLAYER);
    }
    
    @SubscribeEvent
    public void onPacket(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            final AccessorSPacketPlayerPosLook packet = event.getPacket();
            packet.setPitch(AntiRotate.mc.field_71439_g.field_70125_A);
            packet.setYaw(AntiRotate.mc.field_71439_g.field_70177_z);
        }
        if (fullNullCheck()) {
            return;
        }
    }
}
