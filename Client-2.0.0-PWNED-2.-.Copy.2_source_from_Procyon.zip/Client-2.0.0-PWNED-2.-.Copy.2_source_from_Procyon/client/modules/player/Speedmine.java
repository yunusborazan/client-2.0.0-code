// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumHand;
import client.util.BlockUtil;
import client.events.BlockEvent;
import client.util.RenderUtil;
import java.awt.Color;
import client.Client;
import client.events.Render3DEvent;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import client.gui.impl.setting.Setting;
import client.util.Timer;
import client.modules.Module;

public class Speedmine extends Module
{
    private static Speedmine INSTANCE;
    private final Timer timer;
    public Setting<Mode> mode;
    public Setting<Boolean> render;
    public Setting<Boolean> box;
    private final Setting<Integer> boxAlpha;
    public Setting<Boolean> outline;
    private final Setting<Float> lineWidth;
    public BlockPos currentPos;
    public IBlockState currentBlockState;
    
    public Speedmine() {
        super("Speedmine", "Speeds up mining.", Category.PLAYER);
        this.timer = new Timer();
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.PACKET));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (T)false));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)false, v -> this.render.getCurrentState()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)85, (T)0, (T)255, v -> this.box.getCurrentState() && this.render.getCurrentState()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, v -> this.render.getCurrentState()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("Width", (T)1.0f, (T)0.1f, (T)5.0f, v -> this.outline.getCurrentState() && this.render.getCurrentState()));
        this.setInstance();
    }
    
    public static Speedmine getInstance() {
        if (Speedmine.INSTANCE == null) {
            Speedmine.INSTANCE = new Speedmine();
        }
        return Speedmine.INSTANCE;
    }
    
    private void setInstance() {
        Speedmine.INSTANCE = this;
    }
    
    @Override
    public void onTick() {
        if (this.currentPos != null && (!Speedmine.mc.field_71441_e.func_180495_p(this.currentPos).equals(this.currentBlockState) || Speedmine.mc.field_71441_e.func_180495_p(this.currentPos).func_177230_c() == Blocks.field_150350_a)) {
            this.currentPos = null;
            this.currentBlockState = null;
        }
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        Speedmine.mc.field_71442_b.field_78781_i = 0;
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.render.getCurrentState() && this.currentPos != null && this.currentBlockState.func_177230_c() == Blocks.field_150343_Z) {
            final Color color = new Color(this.timer.passedMs((int)(2000.0f * Client.serverManager.getTpsFactor())) ? 0 : 255, this.timer.passedMs((int)(2000.0f * Client.serverManager.getTpsFactor())) ? 255 : 0, 0, 255);
            RenderUtil.drawBoxESP(this.currentPos, color, false, color, this.lineWidth.getCurrentState(), this.outline.getCurrentState(), this.box.getCurrentState(), this.boxAlpha.getCurrentState(), false);
        }
    }
    
    @SubscribeEvent
    public void onBlockEvent(final BlockEvent event) {
        if (fullNullCheck()) {
            return;
        }
        if (event.getStage() == 3 && Speedmine.mc.field_71442_b.field_78770_f > 0.1f) {
            Speedmine.mc.field_71442_b.field_78778_j = true;
        }
        if (event.getStage() == 4 && BlockUtil.canBreak(event.pos)) {
            Speedmine.mc.field_71442_b.field_78778_j = false;
            switch (this.mode.getCurrentState()) {
                case PACKET: {
                    if (this.currentPos == null) {
                        this.currentPos = event.pos;
                        this.currentBlockState = Speedmine.mc.field_71441_e.func_180495_p(this.currentPos);
                        this.timer.reset();
                    }
                    Speedmine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                    Speedmine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                    Speedmine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                    event.setCanceled(true);
                    break;
                }
                case INSTANT: {
                    Speedmine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                    Speedmine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                    Speedmine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                    Speedmine.mc.field_71442_b.func_187103_a(event.pos);
                    Speedmine.mc.field_71441_e.func_175698_g(event.pos);
                    break;
                }
            }
        }
    }
    
    @Override
    public String getDisplayInfo() {
        return this.mode.currentEnumName();
    }
    
    static {
        Speedmine.INSTANCE = new Speedmine();
    }
    
    public enum Mode
    {
        PACKET, 
        INSTANT;
    }
}
