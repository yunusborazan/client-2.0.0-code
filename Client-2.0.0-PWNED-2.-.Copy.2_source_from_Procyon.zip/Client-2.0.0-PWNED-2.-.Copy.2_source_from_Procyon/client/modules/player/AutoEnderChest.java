// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraft.util.math.BlockPos;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.item.ItemPickaxe;
import client.util.InventoryUtil;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.Entity;
import client.util.EntityUtil;
import client.modules.Module;

public class AutoEnderChest extends Module
{
    public AutoEnderChest() {
        super("AutoEnderChest", "Farms enderschests automatically for you.", Category.PLAYER);
    }
    
    @Override
    public void onEnable() {
        final BlockPos pos = EntityUtil.getPlayerPosWithEntity().func_177982_a(0, -1, 0);
        if (EntityUtil.isSafe((Entity)AutoEnderChest.mc.field_71439_g)) {
            AutoEnderChest.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString("Make sure to have echests in your hotbar and hold down Left Click."), 1);
            Burrow.getInstance().swapBlock = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            Burrow.getInstance().enable();
            AutoEnderChest.mc.field_71439_g.field_70125_A = 90.0f;
            AutoEnderChest.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(ItemPickaxe.class);
            AutoEnderChest.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.DOWN));
            AutoEnderChest.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.DOWN));
            this.disable();
        }
    }
}
