// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraft.init.MobEffects;
import net.minecraft.init.PotionTypes;
import net.minecraft.potion.PotionUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTippedArrow;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import client.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.util.InventoryUtil;
import net.minecraft.item.ItemBow;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import client.modules.Module;

public class Quiver extends Module
{
    private int timer;
    private int stage;
    private int returnSlot;
    
    public Quiver() {
        super("Quiver", "Shoots arrows at yourself", Category.PLAYER);
        this.timer = 0;
        this.stage = 1;
        this.returnSlot = -1;
    }
    
    @Override
    public void onDisable() {
        this.timer = 0;
        this.stage = 0;
        Quiver.mc.field_71474_y.field_74313_G.field_74513_e = false;
        if (this.returnSlot != -1) {
            Quiver.mc.field_71442_b.func_187098_a(Quiver.mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, (EntityPlayer)Quiver.mc.field_71439_g);
            Quiver.mc.field_71442_b.func_187098_a(Quiver.mc.field_71439_g.field_71069_bz.field_75152_c, this.returnSlot, 0, ClickType.PICKUP, (EntityPlayer)Quiver.mc.field_71439_g);
            Quiver.mc.field_71442_b.func_187098_a(Quiver.mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, (EntityPlayer)Quiver.mc.field_71439_g);
            this.returnSlot = -1;
        }
    }
    
    @Override
    public void onTick() {
        if (nullCheck()) {
            return;
        }
        if (Quiver.mc.field_71462_r != null) {
            return;
        }
        InventoryUtil.switchToHotbarSlot(ItemBow.class, false);
        if (InventoryUtil.findHotbarBlock(ItemBow.class) == -1) {
            this.disable();
            Command.sendMessage(ChatFormatting.RED + "No bow found!");
            return;
        }
        Quiver.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(Quiver.mc.field_71439_g.field_70177_z, -90.0f, Quiver.mc.field_71439_g.field_70122_E));
        if (this.stage == 0) {
            if (!this.mapArrows()) {
                this.disable();
                Command.sendMessage(ChatFormatting.GREEN + "All effects applied!");
                return;
            }
            ++this.stage;
        }
        else {
            if (this.stage == 1) {
                ++this.stage;
                ++this.timer;
                return;
            }
            if (this.stage == 2) {
                Quiver.mc.field_71474_y.field_74313_G.field_74513_e = true;
                this.timer = 0;
                ++this.stage;
            }
            else if (this.stage == 3) {
                if (this.timer > 4) {
                    ++this.stage;
                }
            }
            else if (this.stage == 4) {
                Quiver.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, Quiver.mc.field_71439_g.func_174811_aO()));
                Quiver.mc.field_71439_g.func_184602_cy();
                Quiver.mc.field_71474_y.field_74313_G.field_74513_e = false;
                this.timer = 0;
                ++this.stage;
            }
            else if (this.stage == 5) {
                if (this.timer < 10) {
                    ++this.timer;
                    return;
                }
                this.stage = 0;
                this.timer = 0;
            }
        }
        ++this.timer;
    }
    
    private boolean mapArrows() {
        for (int a = 9; a < 45; ++a) {
            if (((ItemStack)Quiver.mc.field_71439_g.field_71069_bz.func_75138_a().get(a)).func_77973_b() instanceof ItemTippedArrow) {
                final ItemStack arrow = (ItemStack)Quiver.mc.field_71439_g.field_71069_bz.func_75138_a().get(a);
                if ((PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185223_F) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185225_H) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185224_G)) && !Quiver.mc.field_71439_g.func_70644_a(MobEffects.field_76420_g)) {
                    this.switchTo(a);
                    return true;
                }
                if ((PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185243_o) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185244_p) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185245_q)) && !Quiver.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
                    this.switchTo(a);
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public String getDisplayInfo() {
        return "Stage: " + this.stage;
    }
    
    private void switchTo(final int from) {
        if (from == 9) {
            return;
        }
        this.returnSlot = from;
        Quiver.mc.field_71442_b.func_187098_a(Quiver.mc.field_71439_g.field_71069_bz.field_75152_c, from, 0, ClickType.PICKUP, (EntityPlayer)Quiver.mc.field_71439_g);
        Quiver.mc.field_71442_b.func_187098_a(Quiver.mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, (EntityPlayer)Quiver.mc.field_71439_g);
        Quiver.mc.field_71442_b.func_187098_a(Quiver.mc.field_71439_g.field_71069_bz.field_75152_c, from, 0, ClickType.PICKUP, (EntityPlayer)Quiver.mc.field_71439_g);
        Quiver.mc.field_71442_b.func_78765_e();
    }
}
