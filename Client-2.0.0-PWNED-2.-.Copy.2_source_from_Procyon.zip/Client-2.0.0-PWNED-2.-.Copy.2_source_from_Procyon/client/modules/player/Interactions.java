// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import client.events.PacketEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Interactions extends Module
{
    private static Interactions INSTANCE;
    public Setting<Boolean> liquid;
    public Setting<Boolean> heightLimit;
    public Setting<Boolean> reach;
    public Setting<Float> reachAmount;
    
    public Interactions() {
        super("Interactions", "Changes the way you interact with things", Category.PLAYER);
        this.liquid = (Setting<Boolean>)this.register(new Setting("LiquidPlace", (T)false));
        this.heightLimit = (Setting<Boolean>)this.register(new Setting("HeightLimit", (T)false));
        this.reach = (Setting<Boolean>)this.register(new Setting("Reach", (T)false));
        this.reachAmount = (Setting<Float>)this.register(new Setting("ReachAmount", (T)6.0f, (T)0.0f, (T)10.0f, v -> this.reach.getCurrentState()));
        this.setInstance();
    }
    
    public static Interactions getInstance() {
        if (Interactions.INSTANCE == null) {
            Interactions.INSTANCE = new Interactions();
        }
        return Interactions.INSTANCE;
    }
    
    private void setInstance() {
        Interactions.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        final CPacketPlayerTryUseItemOnBlock packet;
        if (this.heightLimit.getCurrentState() && event.getStage() == 0 && event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && (packet = event.getPacket()).func_187023_a().func_177956_o() >= 255 && packet.func_187024_b() == EnumFacing.UP) {
            packet.field_149579_d = EnumFacing.DOWN;
        }
    }
    
    static {
        Interactions.INSTANCE = new Interactions();
    }
}
