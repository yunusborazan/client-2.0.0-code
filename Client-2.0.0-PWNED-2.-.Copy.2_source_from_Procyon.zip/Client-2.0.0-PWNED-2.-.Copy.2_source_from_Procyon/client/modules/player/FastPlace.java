// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.item.ItemEndCrystal;
import client.util.InventoryUtil;
import net.minecraft.item.ItemExpBottle;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class FastPlace extends Module
{
    public Setting<Boolean> exp;
    public Setting<Boolean> crazyFastExpExploit;
    public Setting<Integer> packets;
    public Setting<Boolean> crystal;
    
    public FastPlace() {
        super("FastPlace", "Changes the delay of things", Category.PLAYER);
        this.exp = (Setting<Boolean>)this.register(new Setting("Exp", (T)true));
        this.crazyFastExpExploit = (Setting<Boolean>)this.register(new Setting("UltraSpeed", (T)false));
        this.packets = (Setting<Integer>)this.register(new Setting("Packets", (T)1, (T)0, (T)20, v -> this.crazyFastExpExploit.getCurrentState()));
        this.crystal = (Setting<Boolean>)this.register(new Setting("Crystal", (T)true));
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        if (InventoryUtil.holdingItem(ItemExpBottle.class) && this.exp.getCurrentState()) {
            FastPlace.mc.field_71467_ac = 0;
        }
        if (InventoryUtil.holdingItem(ItemEndCrystal.class) && this.crystal.getCurrentState()) {
            FastPlace.mc.field_71467_ac = 0;
        }
        if (this.crazyFastExpExploit.getCurrentState() && InventoryUtil.holdingItem(ItemExpBottle.class)) {
            FastPlace.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.HotbarEXP()));
            for (int i = 0; i < this.packets.getCurrentState(); ++i) {
                FastPlace.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
            }
            FastPlace.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(FastPlace.mc.field_71439_g.field_71071_by.field_70461_c));
        }
    }
    
    private int HotbarEXP() {
        int slot = 0;
        for (int i = 0; i < 9; ++i) {
            if (FastPlace.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151062_by) {
                slot = i;
                break;
            }
        }
        return slot;
    }
}
