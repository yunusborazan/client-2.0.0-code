// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.events.PacketEvent;
import client.modules.Module;

public class Blink extends Module
{
    private final int entityId = -420;
    
    public Blink() {
        super("Blink", "", Category.PLAYER);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        event.setCanceled(true);
    }
    
    @Override
    public void onLogout() {
        this.disable();
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            return;
        }
        final GameProfile profile = new GameProfile(UUID.fromString("12cbdfad-33b7-4c07-aeac-01766e609482"), "FakePlayer");
        final EntityOtherPlayerMP player = new EntityOtherPlayerMP((World)Blink.mc.field_71441_e, profile);
        player.func_82149_j((Entity)Blink.mc.field_71439_g);
        player.field_70759_as = Blink.mc.field_71439_g.field_70759_as;
        player.field_71071_by.func_70455_b(Blink.mc.field_71439_g.field_71071_by);
        Blink.mc.field_71441_e.func_73027_a(-420, (Entity)player);
    }
    
    @Override
    public void onDisable() {
        if (fullNullCheck()) {
            return;
        }
        Blink.mc.field_71441_e.func_73028_b(-420);
    }
}
