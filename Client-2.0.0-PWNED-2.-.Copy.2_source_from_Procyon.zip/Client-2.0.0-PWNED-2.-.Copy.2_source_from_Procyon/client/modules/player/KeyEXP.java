// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import client.Client;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Mouse;
import client.util.PlayerUtil;
import client.modules.combat.AutoArmor;
import org.lwjgl.input.Keyboard;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class KeyEXP extends Module
{
    private int armorCheck;
    private int delay_count;
    int prvSlot;
    public Setting<Bind> bind;
    public Setting<Boolean> feet;
    public Setting<Boolean> takeOff;
    public Setting<Integer> threshold;
    public Setting<Integer> enemyRange;
    
    public KeyEXP() {
        super("KeyEXP", "", Category.PLAYER);
        this.armorCheck = 0;
        this.bind = (Setting<Bind>)this.register(new Setting("EXPBind:", (T)new Bind(-1)));
        this.feet = (Setting<Boolean>)this.register(new Setting("Feet", (T)false));
        this.takeOff = (Setting<Boolean>)this.register(new Setting("ArmorTakeOff", (T)false));
        this.threshold = (Setting<Integer>)this.register(new Setting("Threshold", (T)100, (T)0, (T)100, v -> this.takeOff.getCurrentState()));
        this.enemyRange = (Setting<Integer>)this.register(new Setting("EnemyRange", (T)0, (T)0, (T)20, v -> this.takeOff.getCurrentState()));
    }
    
    @Override
    public void onUpdate() {
        if (this.bind.getCurrentState().getKey() > -1) {
            if (Keyboard.isKeyDown(this.bind.getCurrentState().getKey()) && KeyEXP.mc.field_71462_r == null) {
                this.useXp();
                if (AutoArmor.getInstance().isEnabled()) {
                    this.armorCheck = 1;
                }
            }
            else if (this.armorCheck == 2) {
                AutoArmor.getInstance().enable();
                this.armorCheck = 0;
            }
        }
        else if (this.bind.getCurrentState().getKey() < -1 && Mouse.isButtonDown(PlayerUtil.convertToMouse(this.bind.getCurrentState().getKey())) && KeyEXP.mc.field_71462_r == null) {
            this.useXp();
        }
    }
    
    @Override
    public void onEnable() {
        this.delay_count = 0;
    }
    
    private ItemStack getArmor(final int first) {
        return (ItemStack)KeyEXP.mc.field_71439_g.field_71069_bz.func_75138_a().get(first);
    }
    
    private void takeArmorOff() {
        for (int slot = 5; slot <= 8; ++slot) {
            final ItemStack item = this.getArmor(slot);
            final double max_dam = item.func_77958_k();
            final double dam_left = item.func_77958_k() - item.func_77952_i();
            final double percent = dam_left / max_dam * 100.0;
            if (percent >= this.threshold.getCurrentState() && !item.equals(Items.field_190931_a)) {
                if (!this.notInInv(Items.field_190931_a)) {
                    return;
                }
                if (this.delay_count < 1) {
                    ++this.delay_count;
                    return;
                }
                this.delay_count = 0;
                KeyEXP.mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.QUICK_MOVE, (EntityPlayer)KeyEXP.mc.field_71439_g);
            }
        }
    }
    
    private int HotbarEXP() {
        int slot = 0;
        for (int i = 0; i < 9; ++i) {
            if (KeyEXP.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151062_by) {
                slot = i;
                break;
            }
        }
        return slot;
    }
    
    public static EntityPlayer getClosestEnemy() {
        EntityPlayer closestPlayer = null;
        for (final EntityPlayer player : KeyEXP.mc.field_71441_e.field_73010_i) {
            if (player != KeyEXP.mc.field_71439_g) {
                if (Client.friendManager.isFriend(player)) {
                    continue;
                }
                if (closestPlayer == null) {
                    closestPlayer = player;
                }
                else {
                    if (KeyEXP.mc.field_71439_g.func_70068_e((Entity)player) >= KeyEXP.mc.field_71439_g.func_70068_e((Entity)closestPlayer)) {
                        continue;
                    }
                    closestPlayer = player;
                }
            }
        }
        return closestPlayer;
    }
    
    private void useXp() {
        this.prvSlot = KeyEXP.mc.field_71439_g.field_71071_by.field_70461_c;
        if (this.armorCheck == 1) {
            AutoArmor.getInstance().disable();
            this.armorCheck = 2;
        }
        if (this.feet.getCurrentState()) {
            KeyEXP.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(KeyEXP.mc.field_71439_g.field_70177_z, 90.0f, true));
        }
        KeyEXP.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.HotbarEXP()));
        KeyEXP.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
        KeyEXP.mc.field_71439_g.field_71071_by.field_70461_c = this.prvSlot;
        KeyEXP.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.prvSlot));
        if (getClosestEnemy() == null) {
            this.takeArmorOff();
        }
        if (getClosestEnemy() != null && this.takeOff.getCurrentState() && (int)getClosestEnemy().func_70032_d((Entity)KeyEXP.mc.field_71439_g) > this.enemyRange.getCurrentState()) {
            this.takeArmorOff();
        }
    }
    
    @Override
    public String getDisplayInfo() {
        if (this.bind.getCurrentState().getKey() > -1 && Keyboard.isKeyDown(this.bind.getCurrentState().getKey()) && KeyEXP.mc.field_71462_r == null) {
            return "Throwing";
        }
        return null;
    }
    
    public Boolean notInInv(final Item itemOfChoice) {
        int n = 0;
        if (itemOfChoice == KeyEXP.mc.field_71439_g.func_184592_cb().func_77973_b()) {
            return true;
        }
        for (int i = 35; i >= 0; --i) {
            final Item item = KeyEXP.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if (item == itemOfChoice) {
                return true;
            }
            if (item != itemOfChoice) {
                ++n;
            }
        }
        if (n >= 35) {
            return false;
        }
        return true;
    }
}
