// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import java.util.ArrayList;
import client.util.Timer;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class HotbarRefill extends Module
{
    private final Setting<Integer> delay;
    private final Setting<Boolean> gapples;
    private final Setting<Integer> gapAmount;
    private final Setting<Boolean> exp;
    private final Setting<Integer> expAmount;
    private final Setting<Boolean> crystal;
    private final Setting<Integer> crystalAmount;
    private final Timer timer;
    private final ArrayList<Item> Hotbar;
    
    public HotbarRefill() {
        super("HotbarRefill", "Refills item stacks in your hotbar", Category.PLAYER);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)10));
        this.gapples = (Setting<Boolean>)this.register(new Setting("Gapples", (T)true));
        this.gapAmount = (Setting<Integer>)this.register(new Setting("GapAmount", (T)1, (T)1, (T)64, v -> this.gapples.getCurrentState()));
        this.exp = (Setting<Boolean>)this.register(new Setting("Exp", (T)true));
        this.expAmount = (Setting<Integer>)this.register(new Setting("ExpAmount", (T)1, (T)1, (T)64, v -> this.exp.getCurrentState()));
        this.crystal = (Setting<Boolean>)this.register(new Setting("Crystals", (T)true));
        this.crystalAmount = (Setting<Integer>)this.register(new Setting("CrystalAmount", (T)1, (T)1, (T)64, v -> this.crystal.getCurrentState()));
        this.timer = new Timer();
        this.Hotbar = new ArrayList<Item>();
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            return;
        }
        this.Hotbar.clear();
        for (int l_I = 0; l_I < 9; ++l_I) {
            final ItemStack l_Stack = HotbarRefill.mc.field_71439_g.field_71071_by.func_70301_a(l_I);
            if (!l_Stack.func_190926_b() && !this.Hotbar.contains(l_Stack.func_77973_b())) {
                this.Hotbar.add(l_Stack.func_77973_b());
            }
            else {
                this.Hotbar.add(Items.field_190931_a);
            }
        }
    }
    
    @Override
    public void onUpdate() {
        if (HotbarRefill.mc.field_71462_r != null) {
            return;
        }
        if (!this.timer.passedMs(this.delay.getCurrentState() * 1000)) {
            return;
        }
        for (int l_I = 0; l_I < 9; ++l_I) {
            if (this.RefillSlotIfNeed(l_I)) {
                this.timer.reset();
                return;
            }
        }
    }
    
    private boolean RefillSlotIfNeed(final int p_Slot) {
        final ItemStack l_Stack = HotbarRefill.mc.field_71439_g.field_71071_by.func_70301_a(p_Slot);
        if (l_Stack.func_190926_b() || l_Stack.func_77973_b() == Items.field_190931_a) {
            return false;
        }
        if (!l_Stack.func_77985_e()) {
            return false;
        }
        if (l_Stack.func_190916_E() >= l_Stack.func_77976_d()) {
            return false;
        }
        if (this.gapples.getCurrentState() && l_Stack.func_77973_b().equals(Items.field_151153_ao) && l_Stack.func_190916_E() >= this.gapAmount.getCurrentState()) {
            return false;
        }
        if (this.exp.getCurrentState() && l_Stack.func_77973_b().equals(Items.field_151062_by) && l_Stack.func_190916_E() > this.expAmount.getCurrentState()) {
            return false;
        }
        if (this.crystal.getCurrentState() && l_Stack.func_77973_b().equals(Items.field_185158_cP) && l_Stack.func_190916_E() > this.crystalAmount.getCurrentState()) {
            return false;
        }
        for (int l_I = 9; l_I < 36; ++l_I) {
            final ItemStack l_Item = HotbarRefill.mc.field_71439_g.field_71071_by.func_70301_a(l_I);
            if (!l_Item.func_190926_b() && this.CanItemBeMergedWith(l_Stack, l_Item)) {
                HotbarRefill.mc.field_71442_b.func_187098_a(HotbarRefill.mc.field_71439_g.field_71069_bz.field_75152_c, l_I, 0, ClickType.QUICK_MOVE, (EntityPlayer)HotbarRefill.mc.field_71439_g);
                HotbarRefill.mc.field_71442_b.func_78765_e();
                return true;
            }
        }
        return false;
    }
    
    private boolean CanItemBeMergedWith(final ItemStack p_Source, final ItemStack p_Target) {
        return p_Source.func_77973_b() == p_Target.func_77973_b() && p_Source.func_82833_r().equals(p_Target.func_82833_r());
    }
}
