// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.player;

import java.lang.reflect.Field;
import client.util.Timer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import client.modules.Feature;
import client.util.BlockUtil;
import net.minecraft.util.EnumHand;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockEnderChest;
import client.util.InventoryUtil;
import net.minecraft.block.BlockAnvil;
import client.util.PlayerUtil;
import net.minecraft.init.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Burrow extends Module
{
    private static Burrow INSTANCE;
    private final Setting<Double> force;
    private final Setting<Boolean> instant;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> anvil;
    int swapBlock;
    BlockPos oldPos;
    Block blockW;
    boolean flag;
    
    public Burrow() {
        super("Burrow", "Tps you inside a block", Category.PLAYER);
        this.force = (Setting<Double>)this.register(new Setting("Offset", (T)1.5, (T)(-5.0), (T)10.0));
        this.instant = (Setting<Boolean>)this.register(new Setting("Instant", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.anvil = (Setting<Boolean>)this.register(new Setting("Anvil", (T)false));
        this.swapBlock = -1;
        this.blockW = (this.anvil.getCurrentState() ? Blocks.field_150467_bQ : Blocks.field_150343_Z);
        this.setInstance();
    }
    
    public static Burrow getInstance() {
        if (Burrow.INSTANCE == null) {
            Burrow.INSTANCE = new Burrow();
        }
        return Burrow.INSTANCE;
    }
    
    private void setInstance() {
        Burrow.INSTANCE = this;
    }
    
    @Override
    public void onEnable() {
        if (nullCheck()) {
            this.disable();
            return;
        }
        this.flag = false;
        Burrow.mc.field_71439_g.field_70159_w = 0.0;
        Burrow.mc.field_71439_g.field_70179_y = 0.0;
        this.oldPos = PlayerUtil.getPlayerPos();
        if (this.anvil.getCurrentState()) {
            if (InventoryUtil.findHotbarBlock(BlockAnvil.class) > 1) {
                this.swapBlock = InventoryUtil.findHotbarBlock(BlockAnvil.class);
            }
            else {
                this.disable();
            }
        }
        else {
            if (InventoryUtil.findHotbarBlock(BlockEnderChest.class) > 1) {
                this.swapBlock = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            }
            else if (InventoryUtil.findHotbarBlock(BlockObsidian.class) > 1) {
                this.swapBlock = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            }
            else {
                this.disable();
            }
            if (this.swapBlock == -1) {
                this.disable();
                return;
            }
            if (this.instant.getCurrentState()) {
                this.setTimer(50.0f);
            }
        }
    }
    
    @Override
    public void onUpdate() {
        if (nullCheck()) {
            return;
        }
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 0.41999998688698, Burrow.mc.field_71439_g.field_70161_v, true));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 0.7531999805211997, Burrow.mc.field_71439_g.field_70161_v, true));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 1.00133597911214, Burrow.mc.field_71439_g.field_70161_v, true));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 1.16610926093821, Burrow.mc.field_71439_g.field_70161_v, true));
        final int old = Burrow.mc.field_71439_g.field_71071_by.field_70461_c;
        this.switchToSlot(this.swapBlock);
        BlockUtil.placeBlock(this.oldPos, EnumHand.MAIN_HAND, this.rotate.getCurrentState(), true, false);
        this.switchToSlot(old);
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + this.force.getCurrentState(), Burrow.mc.field_71439_g.field_70161_v, false));
        this.disable();
    }
    
    @Override
    public void onDisable() {
        if (this.instant.getCurrentState() && !Feature.nullCheck()) {
            this.setTimer(1.0f);
        }
    }
    
    private void switchToSlot(final int slot) {
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
        Burrow.mc.field_71439_g.field_71071_by.field_70461_c = slot;
        Burrow.mc.field_71442_b.func_78765_e();
    }
    
    private void setTimer(final float value) {
        try {
            final Field timer = Minecraft.class.getDeclaredField(Timer.timer);
            timer.setAccessible(true);
            final Field tickLength = net.minecraft.util.Timer.class.getDeclaredField(Timer.tickLength);
            tickLength.setAccessible(true);
            tickLength.setFloat(timer.get(Burrow.mc), 50.0f / value);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public String getDisplayInfo() {
        return "PACKET";
    }
    
    public void setBlock(final Block b) {
        this.blockW = b;
    }
    
    public Block getBlock() {
        return this.blockW;
    }
    
    static {
        Burrow.INSTANCE = new Burrow();
    }
}
