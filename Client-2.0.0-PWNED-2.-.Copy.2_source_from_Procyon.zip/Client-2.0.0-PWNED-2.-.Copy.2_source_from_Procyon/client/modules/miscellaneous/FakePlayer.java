// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class FakePlayer extends Module
{
    private static FakePlayer INSTANCE;
    public Setting<Boolean> copyInv;
    public Setting<Boolean> moving;
    public Setting<Integer> motion;
    private final int entityId = -420;
    
    public FakePlayer() {
        super("FakePlayer", "Spawns a FakePlayer for testing.", Category.MISC);
        this.copyInv = (Setting<Boolean>)this.register(new Setting("Copy Inventory", (T)true));
        this.moving = (Setting<Boolean>)this.register(new Setting("Moving", (T)false));
        this.motion = (Setting<Integer>)this.register(new Setting("Motion", (T)2, (T)(-5), (T)5, v -> this.moving.getCurrentState()));
        this.setInstance();
    }
    
    public static FakePlayer getInstance() {
        if (FakePlayer.INSTANCE == null) {
            FakePlayer.INSTANCE = new FakePlayer();
        }
        return FakePlayer.INSTANCE;
    }
    
    private void setInstance() {
        FakePlayer.INSTANCE = this;
    }
    
    @Override
    public void onDisable() {
        if (fullNullCheck()) {
            return;
        }
        FakePlayer.mc.field_71441_e.func_73028_b(-420);
    }
    
    @Override
    public void onUpdate() {
        if (!this.moving.getCurrentState()) {
            return;
        }
        if (fullNullCheck()) {
            return;
        }
        final GameProfile profile = new GameProfile(UUID.fromString("12cbdfad-33b7-4c07-aeac-01766e609482"), "FakePlayer");
        final EntityOtherPlayerMP player = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, profile);
        player.func_70012_b(FakePlayer.mc.field_71439_g.field_70165_t + player.field_70159_w + this.motion.getCurrentState(), FakePlayer.mc.field_71439_g.field_70163_u + player.field_70181_x, FakePlayer.mc.field_71439_g.field_70161_v + player.field_70179_y + this.motion.getCurrentState(), 90.0f, 90.0f);
        player.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
        if (this.copyInv.getCurrentState()) {
            player.field_71071_by.func_70455_b(FakePlayer.mc.field_71439_g.field_71071_by);
        }
        FakePlayer.mc.field_71441_e.func_73027_a(-420, (Entity)player);
    }
    
    @Override
    public void onEnable() {
        if (this.moving.getCurrentState()) {
            return;
        }
        if (fullNullCheck()) {
            return;
        }
        final GameProfile profile = new GameProfile(UUID.fromString("12cbdfad-33b7-4c07-aeac-01766e609482"), "FakePlayer");
        final EntityOtherPlayerMP player = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, profile);
        player.func_82149_j((Entity)FakePlayer.mc.field_71439_g);
        player.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
        if (this.copyInv.getCurrentState()) {
            player.field_71071_by.func_70455_b(FakePlayer.mc.field_71439_g.field_71071_by);
        }
        FakePlayer.mc.field_71441_e.func_73027_a(-420, (Entity)player);
    }
    
    static {
        FakePlayer.INSTANCE = new FakePlayer();
    }
}
