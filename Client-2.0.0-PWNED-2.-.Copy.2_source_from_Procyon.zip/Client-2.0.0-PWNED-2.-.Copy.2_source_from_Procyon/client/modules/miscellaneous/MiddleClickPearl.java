// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.init.Items;
import client.util.InventoryUtil;
import net.minecraft.item.ItemEnderPearl;
import org.lwjgl.input.Mouse;
import client.modules.Module;

public class MiddleClickPearl extends Module
{
    private boolean clicked;
    
    public MiddleClickPearl() {
        super("MiddleClickPearl", "Throws a pearl when middle clicked", Category.MISC);
        this.clicked = false;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onTick() {
        if (Mouse.isButtonDown(2)) {
            if (!this.clicked) {
                this.throwPearl();
            }
            this.clicked = true;
        }
        else {
            this.clicked = false;
        }
    }
    
    private void throwPearl() {
        final int pearlSlot = InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
        final boolean offhand = MiddleClickPearl.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151079_bi;
        if (pearlSlot != -1 || offhand) {
            final int oldslot = MiddleClickPearl.mc.field_71439_g.field_71071_by.field_70461_c;
            if (!offhand) {
                InventoryUtil.switchToHotbarSlot(pearlSlot, false);
            }
            MiddleClickPearl.mc.field_71442_b.func_187101_a((EntityPlayer)MiddleClickPearl.mc.field_71439_g, (World)MiddleClickPearl.mc.field_71441_e, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            if (!offhand) {
                InventoryUtil.switchToHotbarSlot(oldslot, false);
            }
        }
    }
}
