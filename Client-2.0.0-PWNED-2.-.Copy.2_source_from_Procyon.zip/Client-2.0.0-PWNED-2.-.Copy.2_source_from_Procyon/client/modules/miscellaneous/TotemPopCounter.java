// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.modules.client.Notify;
import net.minecraft.entity.player.EntityPlayer;
import java.util.HashMap;
import client.modules.Module;

public class TotemPopCounter extends Module
{
    private static TotemPopCounter INSTANCE;
    public static HashMap<String, Integer> TotemPopContainer;
    
    public TotemPopCounter() {
        super("TotemPopCounter", "Counts enemy pops", Category.MISC);
        this.setInstance();
    }
    
    public static TotemPopCounter getInstance() {
        if (TotemPopCounter.INSTANCE == null) {
            TotemPopCounter.INSTANCE = new TotemPopCounter();
        }
        return TotemPopCounter.INSTANCE;
    }
    
    private void setInstance() {
        TotemPopCounter.INSTANCE = this;
    }
    
    public void onDeath(final EntityPlayer player) {
        if (TotemPopCounter.TotemPopContainer.containsKey(player.func_70005_c_())) {
            final int l_Count = TotemPopCounter.TotemPopContainer.get(player.func_70005_c_());
            TotemPopCounter.TotemPopContainer.remove(player.func_70005_c_());
            if (l_Count == 1) {
                int id = 0;
                for (final char character : player.func_70005_c_().toCharArray()) {
                    id += character;
                    id *= 10;
                }
                TotemPopCounter.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " died after popping " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totem."), id);
            }
            else {
                int id = 0;
                for (final char character : player.func_70005_c_().toCharArray()) {
                    id += character;
                    id *= 10;
                }
                TotemPopCounter.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " died after popping " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totems."), id);
            }
        }
    }
    
    public void onTotemPop(final EntityPlayer player) {
        if (fullNullCheck()) {
            return;
        }
        if (TotemPopCounter.mc.field_71439_g.equals((Object)player)) {
            return;
        }
        int l_Count = 1;
        if (TotemPopCounter.TotemPopContainer.containsKey(player.func_70005_c_())) {
            l_Count = TotemPopCounter.TotemPopContainer.get(player.func_70005_c_());
            TotemPopCounter.TotemPopContainer.put(player.func_70005_c_(), ++l_Count);
        }
        else {
            TotemPopCounter.TotemPopContainer.put(player.func_70005_c_(), l_Count);
        }
        if (l_Count == 1) {
            int id = 0;
            for (final char character : player.func_70005_c_().toCharArray()) {
                id += character;
                id *= 10;
            }
            TotemPopCounter.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " has popped " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totem."), id);
        }
        else {
            int id = 0;
            for (final char character : player.func_70005_c_().toCharArray()) {
                id += character;
                id *= 10;
            }
            TotemPopCounter.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " has popped " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totems."), id);
        }
    }
    
    static {
        TotemPopCounter.INSTANCE = new TotemPopCounter();
        TotemPopCounter.TotemPopContainer = new HashMap<String, Integer>();
    }
}
