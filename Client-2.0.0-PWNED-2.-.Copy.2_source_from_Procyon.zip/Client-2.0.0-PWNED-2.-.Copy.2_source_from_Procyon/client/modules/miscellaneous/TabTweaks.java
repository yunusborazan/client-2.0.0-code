// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.client.network.NetworkPlayerInfo;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class TabTweaks extends Module
{
    private static TabTweaks INSTANCE;
    public Setting<Boolean> pingDisplay;
    public Setting<Boolean> coloredPing;
    public Setting<Integer> size;
    
    public TabTweaks() {
        super("TabTweaks", "Lets you do stuff with tab", Category.MISC);
        this.pingDisplay = (Setting<Boolean>)this.register(new Setting("Ping", (T)true));
        this.coloredPing = (Setting<Boolean>)this.register(new Setting("Colored", (T)true));
        this.size = (Setting<Integer>)this.register(new Setting("Size", (T)250, (T)1, (T)1000));
        this.setInstance();
    }
    
    public static String getPlayerName(final NetworkPlayerInfo networkPlayerInfoIn) {
        final String name = (networkPlayerInfoIn.func_178854_k() != null) ? networkPlayerInfoIn.func_178854_k().func_150254_d() : ScorePlayerTeam.func_96667_a((Team)networkPlayerInfoIn.func_178850_i(), networkPlayerInfoIn.func_178845_a().getName());
        if (getINSTANCE().pingDisplay.getCurrentState()) {
            if (!getINSTANCE().coloredPing.getCurrentState()) {
                return name + ChatFormatting.GRAY + " " + (((boolean)getINSTANCE().pingDisplay.getCurrentState()) ? Integer.valueOf(networkPlayerInfoIn.func_178853_c()) : "");
            }
            if (networkPlayerInfoIn.func_178853_c() <= 50) {
                return name + ChatFormatting.GREEN + " " + (((boolean)getINSTANCE().pingDisplay.getCurrentState()) ? Integer.valueOf(networkPlayerInfoIn.func_178853_c()) : "");
            }
            if (networkPlayerInfoIn.func_178853_c() <= 100) {
                return name + ChatFormatting.GOLD + " " + (((boolean)getINSTANCE().pingDisplay.getCurrentState()) ? Integer.valueOf(networkPlayerInfoIn.func_178853_c()) : "");
            }
            if (networkPlayerInfoIn.func_178853_c() <= 150) {
                return name + ChatFormatting.RED + " " + (((boolean)getINSTANCE().pingDisplay.getCurrentState()) ? Integer.valueOf(networkPlayerInfoIn.func_178853_c()) : "");
            }
            if (networkPlayerInfoIn.func_178853_c() <= 1000) {
                return name + ChatFormatting.DARK_RED + " " + (((boolean)getINSTANCE().pingDisplay.getCurrentState()) ? Integer.valueOf(networkPlayerInfoIn.func_178853_c()) : "");
            }
        }
        return name;
    }
    
    public static TabTweaks getINSTANCE() {
        if (TabTweaks.INSTANCE == null) {
            TabTweaks.INSTANCE = new TabTweaks();
        }
        return TabTweaks.INSTANCE;
    }
    
    private void setInstance() {
        TabTweaks.INSTANCE = this;
    }
    
    static {
        TabTweaks.INSTANCE = new TabTweaks();
    }
}
