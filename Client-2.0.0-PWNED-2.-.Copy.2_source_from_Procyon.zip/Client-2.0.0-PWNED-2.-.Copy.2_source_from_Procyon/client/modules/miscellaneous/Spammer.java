// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import java.util.ArrayList;
import java.util.Iterator;
import client.util.FileUtil;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketChatMessage;
import java.util.Random;
import java.util.List;
import client.util.Timer;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Spammer extends Module
{
    public Setting<Double> delay;
    public Setting<Boolean> greentext;
    public Setting<Boolean> random;
    private final Timer timer;
    private static final List<String> spamMessages;
    private static final Random rnd;
    
    public Spammer() {
        super("Spammer", "Spams stuff.", Category.MISC);
        this.delay = (Setting<Double>)this.register(new Setting("Delay", (T)6.0, (T)0.1, (T)20.0));
        this.greentext = (Setting<Boolean>)this.register(new Setting("Green", (T)false));
        this.random = (Setting<Boolean>)this.register(new Setting("Random", (T)false));
        this.timer = new Timer();
    }
    
    @Override
    public void onLoad() {
        this.readSpamFile();
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            this.disable();
            return;
        }
        this.readSpamFile();
    }
    
    @Override
    public void onLogin() {
        if (this.isEnabled()) {
            this.disable();
        }
        this.readSpamFile();
    }
    
    @Override
    public void onLogout() {
        if (this.isEnabled()) {
            this.disable();
        }
    }
    
    @Override
    public void onDisable() {
        Spammer.spamMessages.clear();
        this.timer.reset();
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            this.disable();
            return;
        }
        if (!this.timer.passedS(this.delay.getCurrentState())) {
            return;
        }
        if (Spammer.spamMessages.size() > 0) {
            String messageOut;
            if (this.random.getCurrentState()) {
                final int index = Spammer.rnd.nextInt(Spammer.spamMessages.size());
                messageOut = Spammer.spamMessages.get(index);
                Spammer.spamMessages.remove(index);
            }
            else {
                messageOut = Spammer.spamMessages.get(0);
                Spammer.spamMessages.remove(0);
            }
            Spammer.spamMessages.add(messageOut);
            if (this.greentext.getCurrentState()) {
                messageOut = "> " + messageOut;
            }
            Spammer.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage(messageOut.replaceAll("\u00c2§", "")));
        }
        this.timer.reset();
    }
    
    private void readSpamFile() {
        final List<String> fileInput = FileUtil.readTextFileAllLines("client/util/Spammer.txt");
        final Iterator<String> i = fileInput.iterator();
        Spammer.spamMessages.clear();
        while (i.hasNext()) {
            final String s = i.next();
            if (!s.replaceAll("\\s", "").isEmpty()) {
                Spammer.spamMessages.add(s);
            }
        }
        if (Spammer.spamMessages.size() == 0) {
            Spammer.spamMessages.add("f");
        }
    }
    
    static {
        spamMessages = new ArrayList<String>();
        rnd = new Random();
    }
}
