// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.ChatType;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraft.client.gui.GuiIngame;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketChatMessage;
import client.events.PacketEvent;
import net.minecraft.client.gui.GuiNewChat;
import client.gui.impl.background.GuiChat;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class ChatModifications extends Module
{
    private static ChatModifications getInstance;
    public Setting<Boolean> suffix;
    public Setting<Boolean> customChat;
    public Setting<Boolean> nameHighLight;
    public Setting<Boolean> smoothChat;
    public Setting<Double> xOffset;
    public Setting<Double> yOffset;
    public Setting<Double> vSpeed;
    public Setting<Double> vLength;
    public Setting<Double> vIncrements;
    public Setting<Type> type;
    public static GuiChat guiChatSmooth;
    public static GuiNewChat guiChat;
    
    public ChatModifications() {
        super("ChatModifications", "Modifies your chat", Category.MISC);
        this.suffix = (Setting<Boolean>)this.register(new Setting("Suffix", (T)true));
        this.customChat = (Setting<Boolean>)this.register(new Setting("CustomChat", (T)false));
        this.nameHighLight = (Setting<Boolean>)this.register(new Setting("NameHighLight", (T)false, v -> this.customChat.getCurrentState()));
        this.smoothChat = (Setting<Boolean>)this.register(new Setting("SmoothChat", (T)false, v -> this.customChat.getCurrentState()));
        this.xOffset = (Setting<Double>)this.register(new Setting("XOffset", (T)0.0, (T)0.0, (T)600, v -> this.smoothChat.getCurrentState() && this.customChat.getCurrentState()));
        this.yOffset = (Setting<Double>)this.register(new Setting("YOffset", (T)0.0, (T)0.0, (T)30.0, v -> this.smoothChat.getCurrentState() && this.customChat.getCurrentState()));
        this.vSpeed = (Setting<Double>)this.register(new Setting("VSpeed", (T)30.0, (T)1.0, (T)100.0, v -> this.smoothChat.getCurrentState() && this.customChat.getCurrentState()));
        this.vLength = (Setting<Double>)this.register(new Setting("VLength", (T)10.0, (T)5.0, (T)100.0, v -> this.smoothChat.getCurrentState() && this.customChat.getCurrentState()));
        this.vIncrements = (Setting<Double>)this.register(new Setting("VIncrements", (T)1.0, (T)1.0, (T)5.0, v -> this.smoothChat.getCurrentState() && this.customChat.getCurrentState()));
        this.type = (Setting<Type>)this.register(new Setting("Type", (T)Type.HORIZONTAL, v -> this.smoothChat.getCurrentState() && this.customChat.getCurrentState()));
        this.setInstance();
    }
    
    public static ChatModifications getInstance() {
        if (ChatModifications.getInstance == null) {
            ChatModifications.getInstance = new ChatModifications();
        }
        return ChatModifications.getInstance;
    }
    
    private void setInstance() {
        ChatModifications.getInstance = this;
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getStage() == 0 && event.getPacket() instanceof CPacketChatMessage && this.suffix.getCurrentState()) {
            final CPacketChatMessage packet = event.getPacket();
            String s = packet.func_149439_c();
            if (s.startsWith("/")) {
                return;
            }
            s += " \u23e3";
            if (s.length() >= 256) {
                s = s.substring(0, 256);
            }
            packet.field_149440_a = s;
        }
    }
    
    @Override
    public void onEnable() {
        ChatModifications.guiChatSmooth = new GuiChat(ChatModifications.mc);
        ObfuscationReflectionHelper.setPrivateValue((Class)GuiIngame.class, (Object)ChatModifications.mc.field_71456_v, (Object)ChatModifications.guiChatSmooth, new String[] { "field_73840_e" });
    }
    
    @Override
    public void onDisable() {
        ChatModifications.guiChat = new GuiNewChat(ChatModifications.mc);
        ObfuscationReflectionHelper.setPrivateValue((Class)GuiIngame.class, (Object)ChatModifications.mc.field_71456_v, (Object)ChatModifications.guiChat, new String[] { "field_73840_e" });
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketChat) {
            if (event.getPacket().func_192590_c() == ChatType.GAME_INFO) {
                return;
            }
            String message;
            final String originalMessage = message = event.getPacket().field_148919_a.func_150254_d();
            if (this.nameHighLight.getCurrentState()) {
                try {
                    message = message.replace(ChatModifications.mc.field_71439_g.func_70005_c_(), ChatFormatting.RED + ChatModifications.mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    @Override
    public void onLogin() {
        if (this.isEnabled()) {
            this.disable();
            this.enable();
        }
    }
    
    static {
        ChatModifications.getInstance = new ChatModifications();
    }
    
    public enum Type
    {
        HORIZONTAL, 
        VERTICAL;
    }
}
