// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiGameOver;
import client.modules.Module;

public class AutoRespawn extends Module
{
    public AutoRespawn() {
        super("AutoRespawn", "Respawns you if you die.", Category.MISC);
    }
    
    @Override
    public void onUpdate() {
        if (AutoRespawn.mc.field_71462_r instanceof GuiGameOver) {
            AutoRespawn.mc.field_71439_g.func_71004_bE();
            AutoRespawn.mc.func_147108_a((GuiScreen)null);
        }
    }
}
