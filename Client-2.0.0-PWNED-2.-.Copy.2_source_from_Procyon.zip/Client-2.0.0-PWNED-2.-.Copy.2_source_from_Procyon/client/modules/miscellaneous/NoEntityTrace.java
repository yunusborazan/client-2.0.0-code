// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.RayTraceResult;
import java.util.function.Consumer;
import net.minecraft.entity.EntityLivingBase;
import client.modules.Module;

public class NoEntityTrace extends Module
{
    private boolean focus;
    
    public NoEntityTrace() {
        super("NoEntityTrace", "Ignores entities on pickaxe swings", Category.MISC);
        this.focus = false;
    }
    
    @Override
    public void onUpdate() {
        NoEntityTrace.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity instanceof EntityLivingBase).filter(entity -> NoEntityTrace.mc.field_71439_g == entity).map(entity -> entity).filter(entity -> !entity.field_70128_L).forEach(this::process);
        final RayTraceResult normalResult = NoEntityTrace.mc.field_71476_x;
        if (normalResult != null) {
            this.focus = (normalResult.field_72313_a == RayTraceResult.Type.ENTITY);
        }
    }
    
    private void process(final EntityLivingBase event) {
        final RayTraceResult bypassEntityResult = event.func_174822_a(6.0, NoEntityTrace.mc.func_184121_ak());
        if (bypassEntityResult != null && this.focus && bypassEntityResult.field_72313_a == RayTraceResult.Type.BLOCK) {
            final BlockPos pos = bypassEntityResult.func_178782_a();
            if (NoEntityTrace.mc.field_71474_y.field_74312_F.func_151470_d()) {
                NoEntityTrace.mc.field_71442_b.func_180512_c(pos, EnumFacing.UP);
            }
        }
    }
}
