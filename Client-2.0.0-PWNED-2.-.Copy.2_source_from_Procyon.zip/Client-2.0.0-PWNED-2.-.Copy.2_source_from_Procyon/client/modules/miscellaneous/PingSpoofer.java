// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.miscellaneous;

import client.util.MathUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketKeepAlive;
import client.events.PacketEvent;
import java.util.concurrent.ConcurrentLinkedQueue;
import client.util.Timer;
import net.minecraft.network.Packet;
import java.util.Queue;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class PingSpoofer extends Module
{
    private final Setting<Integer> delay;
    private final Queue<Packet<?>> packets;
    private final Timer timer;
    private boolean receive;
    
    public PingSpoofer() {
        super("PingSpoofer", "Makes it look like you have higher ping than you really do.", Category.MISC);
        this.delay = (Setting<Integer>)this.register(new Setting("DelayMS", (T)20, (T)0, (T)1000));
        this.packets = new ConcurrentLinkedQueue<Packet<?>>();
        this.timer = new Timer();
        this.receive = true;
    }
    
    @Override
    public void onUpdate() {
        this.clearQueue();
    }
    
    @Override
    public void onDisable() {
        this.clearQueue();
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (this.receive && PingSpoofer.mc.field_71439_g != null && !PingSpoofer.mc.func_71356_B() && PingSpoofer.mc.field_71439_g.func_70089_S() && event.getStage() == 0 && event.getPacket() instanceof CPacketKeepAlive) {
            this.packets.add(event.getPacket());
            event.setCanceled(true);
        }
    }
    
    public void clearQueue() {
        if (PingSpoofer.mc.field_71439_g != null && !PingSpoofer.mc.func_71356_B() && PingSpoofer.mc.field_71439_g.func_70089_S() && this.timer.passedMs(this.delay.getCurrentState())) {
            final double limit = MathUtil.getIncremental(Math.random() * 10.0, 1.0);
            this.receive = false;
            for (int i = 0; i < limit; ++i) {
                final Packet<?> packet = this.packets.poll();
                if (packet != null) {
                    PingSpoofer.mc.field_71439_g.field_71174_a.func_147297_a((Packet)packet);
                }
            }
            this.timer.reset();
            this.receive = true;
        }
    }
}
