// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import client.Client;
import client.util.BlockUtil;
import net.minecraft.util.EnumHand;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import client.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import net.minecraft.util.math.Vec3d;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Flatten extends Module
{
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> packet;
    private final Vec3d[] offsetsDefault;
    private int offsetStep;
    private int oldSlot;
    private boolean placing;
    
    public Flatten() {
        super("Flatten", "Flatter than 19xp's 14yr old girlfriend", Category.COMBAT);
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)8, (T)1, (T)30));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.packet = (Setting<Boolean>)this.register(new Setting("PacketPlace", (T)false));
        this.offsetsDefault = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(-1.0, 0.0, 0.0) };
        this.offsetStep = 0;
        this.oldSlot = -1;
        this.placing = false;
    }
    
    @Override
    public void onEnable() {
        this.oldSlot = Flatten.mc.field_71439_g.field_71071_by.field_70461_c;
    }
    
    @Override
    public void onDisable() {
        this.oldSlot = -1;
    }
    
    @Override
    public void onTick() {
        final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        if (obbySlot == -1) {
            this.toggle();
        }
    }
    
    @Override
    public void onUpdate() {
        final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        if (obbySlot == -1) {
            this.toggle();
        }
        final EntityPlayer closest_target = this.findClosestTarget();
        if (closest_target == null) {
            return;
        }
        final List<Vec3d> place_targets = new ArrayList<Vec3d>();
        Collections.addAll(place_targets, this.offsetsDefault);
        int blocks_placed = 0;
        while (blocks_placed < this.blocksPerTick.getCurrentState()) {
            if (this.offsetStep >= place_targets.size()) {
                this.offsetStep = 0;
                break;
            }
            this.placing = true;
            final BlockPos offset_pos = new BlockPos((Vec3d)place_targets.get(this.offsetStep));
            final BlockPos target_pos = new BlockPos(closest_target.func_174791_d()).func_177977_b().func_177982_a(offset_pos.func_177958_n(), offset_pos.func_177956_o(), offset_pos.func_177952_p());
            boolean should_try_place = Flatten.mc.field_71441_e.func_180495_p(target_pos).func_185904_a().func_76222_j();
            for (final Entity entity : Flatten.mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(target_pos))) {
                if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                    should_try_place = false;
                    break;
                }
            }
            if (should_try_place) {
                this.place(target_pos, obbySlot, this.oldSlot);
                ++blocks_placed;
            }
            ++this.offsetStep;
            this.placing = false;
        }
    }
    
    private void place(final BlockPos pos, final int slot, final int oldSlot) {
        Flatten.mc.field_71439_g.field_71071_by.field_70461_c = slot;
        Flatten.mc.field_71442_b.func_78765_e();
        BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), Flatten.mc.field_71439_g.func_70093_af());
        Flatten.mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
        Flatten.mc.field_71442_b.func_78765_e();
    }
    
    @Override
    public void onLogout() {
        if (this.isOn()) {
            this.disable();
        }
    }
    
    private EntityPlayer findClosestTarget() {
        if (Flatten.mc.field_71441_e.field_73010_i.isEmpty()) {
            return null;
        }
        EntityPlayer closestTarget = null;
        for (final EntityPlayer target : Flatten.mc.field_71441_e.field_73010_i) {
            if (target != Flatten.mc.field_71439_g) {
                if (!target.func_70089_S()) {
                    continue;
                }
                if (Client.friendManager.isFriend(target.func_70005_c_())) {
                    continue;
                }
                if (target.func_110143_aJ() <= 0.0f) {
                    continue;
                }
                if (Flatten.mc.field_71439_g.func_70032_d((Entity)target) > 5.0f) {
                    continue;
                }
                if (closestTarget != null && Flatten.mc.field_71439_g.func_70032_d((Entity)target) > Flatten.mc.field_71439_g.func_70032_d((Entity)closestTarget)) {
                    continue;
                }
                closestTarget = target;
            }
        }
        return closestTarget;
    }
}
