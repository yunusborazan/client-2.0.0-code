// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import java.util.Arrays;
import java.util.List;
import net.minecraft.util.EnumHand;
import client.Client;
import java.util.Iterator;
import client.command.Command;
import net.minecraft.block.BlockEnderChest;
import client.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.util.BlockUtil;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import client.util.PlayerUtil;
import net.minecraft.entity.Entity;
import client.util.EntityUtil;
import java.util.HashMap;
import java.util.HashSet;
import net.minecraft.util.math.BlockPos;
import java.util.Map;
import net.minecraft.util.math.Vec3d;
import java.util.Set;
import client.util.Timer;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Surround extends Module
{
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> noGhost;
    private final boolean floor;
    private final Setting<Boolean> centerp;
    private final Setting<Center> centerPlayer;
    private final Setting<Boolean> rotate;
    private final Timer timer;
    private final Timer retryTimer;
    private final Set<Vec3d> extendingBlocks;
    private final Map<BlockPos, Integer> retries;
    private int isSafe;
    public static boolean isPlacing;
    private BlockPos startPos;
    private boolean didPlace;
    private int lastHotbarSlot;
    private boolean isSneaking;
    private int placements;
    private int extenders;
    private int obbySlot;
    private boolean offHand;
    Vec3d center;
    
    public Surround() {
        super("Surround", "Surrounds you with Obsidian", Category.COMBAT);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)250));
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)20, (T)1, (T)20));
        this.noGhost = (Setting<Boolean>)this.register(new Setting("PacketPlace", (T)false));
        this.centerp = (Setting<Boolean>)this.register(new Setting("Center", (T)false));
        this.centerPlayer = (Setting<Center>)this.register(new Setting("Center", (T)Center.SMOOTH, v -> this.centerp.getCurrentState()));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.floor = true;
        this.timer = new Timer();
        this.retryTimer = new Timer();
        this.extendingBlocks = new HashSet<Vec3d>();
        this.retries = new HashMap<BlockPos, Integer>();
        this.didPlace = false;
        this.placements = 0;
        this.extenders = 1;
        this.obbySlot = -1;
        this.offHand = false;
        this.center = Vec3d.field_186680_a;
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            this.disable();
        }
        this.lastHotbarSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
        this.startPos = EntityUtil.getRoundedBlockPos((Entity)Surround.mc.field_71439_g);
        this.center = PlayerUtil.getCenter(Surround.mc.field_71439_g.field_70165_t, Surround.mc.field_71439_g.field_70163_u, Surround.mc.field_71439_g.field_70161_v);
        if (this.centerp.getCurrentState()) {
            switch (this.centerPlayer.getCurrentState()) {
                case INSTANT: {
                    Surround.mc.field_71439_g.field_70159_w = 0.0;
                    Surround.mc.field_71439_g.field_70179_y = 0.0;
                    Surround.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(this.center.field_72450_a, this.center.field_72448_b, this.center.field_72449_c, true));
                    Surround.mc.field_71439_g.func_70107_b(this.center.field_72450_a, this.center.field_72448_b, this.center.field_72449_c);
                    break;
                }
                case SMOOTH: {
                    Surround.mc.field_71439_g.field_70159_w = (this.center.field_72450_a - Surround.mc.field_71439_g.field_70165_t) / 2.0;
                    Surround.mc.field_71439_g.field_70179_y = (this.center.field_72449_c - Surround.mc.field_71439_g.field_70161_v) / 2.0;
                    break;
                }
            }
        }
        this.retries.clear();
        this.retryTimer.reset();
    }
    
    @Override
    public void onTick() {
        this.doSurround();
    }
    
    @Override
    public void onUpdate() {
        if (this.check()) {
            return;
        }
        final boolean onWeb = Surround.mc.field_71441_e.func_180495_p(new BlockPos(Surround.mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150321_G;
        if (!BlockUtil.isSafe((Entity)Surround.mc.field_71439_g, onWeb ? 1 : 0, this.floor)) {
            this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), BlockUtil.getUnsafeBlockArray(Surround.mc.field_71439_g.func_174791_d(), (int)(onWeb ? 1 : 0), true), false, false, false);
        }
        boolean inEChest = Surround.mc.field_71441_e.func_180495_p(new BlockPos(Surround.mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150477_bB;
        if (Surround.mc.field_71439_g.field_70163_u - (int)Surround.mc.field_71439_g.field_70163_u < 0.7) {
            inEChest = false;
        }
        this.processExtendingBlocks();
        if (this.didPlace) {
            this.timer.reset();
        }
    }
    
    @Override
    public void onDisable() {
        if (nullCheck()) {
            return;
        }
        Surround.isPlacing = false;
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
    }
    
    @Override
    public String getDisplayInfo() {
        switch (this.isSafe) {
            case 0: {
                return ChatFormatting.RED + "Unsafe";
            }
            case 1: {
                return ChatFormatting.YELLOW + "Safe";
            }
            default: {
                return ChatFormatting.GREEN + "Safe";
            }
        }
    }
    
    private void doSurround() {
        if (this.check()) {
            return;
        }
        if (!EntityUtil.isSafe((Entity)Surround.mc.field_71439_g, 0, true)) {
            this.isSafe = 0;
            this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, 0, true), true, false, false);
        }
        else if (!EntityUtil.isSafe((Entity)Surround.mc.field_71439_g, -1, false)) {
            this.isSafe = 1;
            this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, -1, false), false, false, true);
        }
        else {
            this.isSafe = 3;
            if (Surround.mc.field_71441_e.func_180495_p(EntityUtil.getRoundedBlockPos((Entity)Surround.mc.field_71439_g)).func_177230_c().equals(Blocks.field_150477_bB) && Surround.mc.field_71439_g.field_70163_u != EntityUtil.getRoundedBlockPos((Entity)Surround.mc.field_71439_g).func_177956_o()) {
                this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, 1, false), false, false, true);
            }
            else {
                this.isSafe = 4;
            }
        }
        this.processExtendingBlocks();
        if (this.didPlace) {
            this.timer.reset();
        }
    }
    
    private boolean check() {
        if (nullCheck()) {
            return true;
        }
        final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        final int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
        if (obbySlot == -1 && eChestSot == -1) {
            this.toggle();
        }
        this.offHand = InventoryUtil.isBlock(Surround.mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
        Surround.isPlacing = false;
        this.didPlace = false;
        this.extenders = 1;
        this.placements = 0;
        this.obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        final int echestSlot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
        if (this.isOff()) {
            return true;
        }
        if (this.retryTimer.passedMs(2500L)) {
            this.retries.clear();
            this.retryTimer.reset();
        }
        if (this.obbySlot == -1 && !this.offHand && echestSlot == -1) {
            Command.sendMessage("No obsidian, toggling");
            this.disable();
            return true;
        }
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        if (Surround.mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && Surround.mc.field_71439_g.field_71071_by.field_70461_c != this.obbySlot && Surround.mc.field_71439_g.field_71071_by.field_70461_c != echestSlot) {
            this.lastHotbarSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
        }
        if (!this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)Surround.mc.field_71439_g))) {
            this.disable();
            return true;
        }
        return !this.timer.passedMs(this.delay.getCurrentState());
    }
    
    private void processExtendingBlocks() {
        if (this.extendingBlocks.size() == 2 && this.extenders < 1) {
            final Vec3d[] array = new Vec3d[2];
            int i = 0;
            final Iterator<Vec3d> iterator = this.extendingBlocks.iterator();
            while (iterator.hasNext()) {
                final Vec3d[] array2 = array;
                final int n = i;
                final Vec3d vec3d2 = iterator.next();
                array2[n] = vec3d2;
                final Vec3d vec3d = vec3d2;
                ++i;
            }
            final int placementsBefore = this.placements;
            if (this.areClose(array) != null) {
                this.placeBlocks(this.areClose(array), BlockUtil.getUnsafeBlockArray(this.areClose(array), 0, this.floor), false, false, true);
            }
            if (placementsBefore < this.placements) {
                this.extendingBlocks.clear();
            }
        }
        else if (this.extendingBlocks.size() > 2 || this.extenders >= 1) {
            this.extendingBlocks.clear();
        }
    }
    
    private Vec3d areClose(final Vec3d[] vec3ds) {
        int matches = 0;
        for (final Vec3d vec3d : vec3ds) {
            for (final Vec3d pos : BlockUtil.getUnsafeBlockArray(Surround.mc.field_71439_g.func_174791_d(), 0, this.floor)) {
                if (vec3d.equals((Object)pos)) {
                    ++matches;
                }
            }
        }
        if (matches == 2) {
            return Surround.mc.field_71439_g.func_174791_d().func_178787_e(vec3ds[0].func_178787_e(vec3ds[1]));
        }
        return null;
    }
    
    private boolean placeBlocks(final Vec3d pos, final Vec3d[] vec3ds, final boolean hasHelpingBlocks, final boolean isHelping, final boolean isExtending) {
        boolean gotHelp = true;
        for (final Vec3d vec3d : vec3ds) {
            gotHelp = true;
            final BlockPos position = new BlockPos(pos).func_177963_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
            switch (BlockUtil.isPositionPlaceable(position, false)) {
                case 1: {
                    if (this.retries.get(position) == null || this.retries.get(position) < 4) {
                        this.placeBlock(position);
                        this.retries.put(position, (this.retries.get(position) == null) ? 1 : (this.retries.get(position) + 1));
                        this.retryTimer.reset();
                        break;
                    }
                    if (Client.speedManager.getSpeedKpH() != 0.0) {
                        break;
                    }
                    if (isExtending) {
                        break;
                    }
                    if (this.extenders >= 1) {
                        break;
                    }
                    this.placeBlocks(Surround.mc.field_71439_g.func_174791_d().func_178787_e(vec3d), EntityUtil.getUnsafeBlockArrayFromVec3d(Surround.mc.field_71439_g.func_174791_d().func_178787_e(vec3d), 0, true), hasHelpingBlocks, false, true);
                    this.extendingBlocks.add(vec3d);
                    ++this.extenders;
                    break;
                }
                case 2: {
                    if (!hasHelpingBlocks) {
                        break;
                    }
                    gotHelp = this.placeBlocks(pos, BlockUtil.getHelpingBlocks(vec3d), false, true, true);
                }
                case 3: {
                    if (gotHelp) {
                        this.placeBlock(position);
                    }
                    if (!isHelping) {
                        break;
                    }
                    return true;
                }
            }
        }
        return false;
    }
    
    private void placeBlock(final BlockPos pos) {
        if (this.placements < this.blocksPerTick.getCurrentState()) {
            final int originalSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
            final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            if (obbySlot == -1 && eChestSot == -1) {
                this.toggle();
            }
            Surround.isPlacing = true;
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = ((obbySlot == -1) ? eChestSot : obbySlot);
            Surround.mc.field_71442_b.func_78765_e();
            this.isSneaking = BlockUtil.placeBlock(pos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.noGhost.getCurrentState(), this.isSneaking);
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
            Surround.mc.field_71442_b.func_78765_e();
            this.didPlace = true;
            ++this.placements;
        }
    }
    
    private List<BlockPos> position() {
        if (this.floor) {
            return Arrays.asList(new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(0, -1, 0), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(1, 0, 0), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(-1, 0, 0), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(0, 0, -1), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(0, 0, 1));
        }
        return Arrays.asList(new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(1, 0, 0), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(-1, 0, 0), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(0, 0, -1), new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(0, 0, 1));
    }
    
    static {
        Surround.isPlacing = false;
    }
    
    public enum Center
    {
        INSTANT, 
        SMOOTH;
    }
}
