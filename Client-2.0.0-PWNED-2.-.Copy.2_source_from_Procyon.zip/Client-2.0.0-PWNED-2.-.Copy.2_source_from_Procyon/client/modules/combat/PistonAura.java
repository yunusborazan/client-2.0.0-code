// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketPlayer;
import client.events.PacketEvent;
import java.util.ArrayList;
import net.minecraft.block.BlockRedstoneTorch;
import net.minecraft.block.BlockObsidian;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.block.BlockLiquid;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import client.util.BlockUtil;
import net.minecraft.block.BlockAir;
import java.util.Iterator;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.block.BlockPistonBase;
import client.util.EntityUtil;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import client.manager.ModuleManager;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class PistonAura extends Module
{
    public Setting<Boolean> rotate;
    public Setting<Boolean> blockPlayer;
    public Setting<Boolean> antiWeakness;
    public Setting<Double> enemyRange;
    public Setting<Integer> blocksPerTick;
    public Setting<Integer> startDelay;
    public Setting<Integer> trapDelay;
    public Setting<Integer> pistonDelay;
    public Setting<Integer> crystalDelay;
    public Setting<Integer> hitDelay;
    public Setting<BreakModes> breakMode;
    private boolean isSneaking;
    private boolean firstRun;
    private boolean noMaterials;
    private boolean hasMoved;
    private boolean isHole;
    private boolean enoughSpace;
    private int oldSlot;
    private int[] slot_mat;
    private int[] delayTable;
    private int stage;
    private int delayTimeTicks;
    private structureTemp toPlace;
    int[][] disp_surblock;
    Double[][] sur_block;
    private int stuck;
    boolean broken;
    boolean brokenCrystalBug;
    boolean brokenRedstoneTorch;
    public static ModuleManager moduleManager;
    private static PistonAura instance;
    private EntityPlayer closestTarget;
    double[] coordsD;
    private static boolean isSpoofingAngles;
    private static double yaw;
    private static double pitch;
    
    public PistonAura() {
        super("PistonAura", "Use Pistons and Crystals to pvp.", Category.COMBAT);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.blockPlayer = (Setting<Boolean>)this.register(new Setting("TrapPlayer", (T)true));
        this.antiWeakness = (Setting<Boolean>)this.register(new Setting("AntiWeakness", (T)false));
        this.enemyRange = (Setting<Double>)this.register(new Setting("Range", (T)5.9, (T)0.0, (T)6.0));
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)4, (T)0, (T)20));
        this.startDelay = (Setting<Integer>)this.register(new Setting("StartDelay", (T)4, (T)0, (T)20));
        this.trapDelay = (Setting<Integer>)this.register(new Setting("TrapDelay", (T)4, (T)0, (T)20));
        this.pistonDelay = (Setting<Integer>)this.register(new Setting("PistonDelay", (T)2, (T)0, (T)20));
        this.crystalDelay = (Setting<Integer>)this.register(new Setting("CrystalDelay", (T)2, (T)0, (T)20));
        this.hitDelay = (Setting<Integer>)this.register(new Setting("HitDelay", (T)2, (T)0, (T)20));
        this.breakMode = (Setting<BreakModes>)this.register(new Setting("Break Mode", (T)BreakModes.swing));
        this.isSneaking = false;
        this.firstRun = false;
        this.noMaterials = false;
        this.hasMoved = false;
        this.isHole = true;
        this.enoughSpace = true;
        this.oldSlot = -1;
        this.disp_surblock = new int[][] { { 1, 0, 0 }, { -1, 0, 0 }, { 0, 0, 1 }, { 0, 0, -1 } };
        this.stuck = 0;
        PistonAura.instance = this;
    }
    
    public static PistonAura getInstance() {
        if (PistonAura.instance == null) {
            PistonAura.instance = new PistonAura();
        }
        return PistonAura.instance;
    }
    
    @Override
    public void onEnable() {
        this.coordsD = new double[3];
        this.delayTable = new int[] { this.startDelay.getCurrentState(), this.trapDelay.getCurrentState(), this.pistonDelay.getCurrentState(), this.crystalDelay.getCurrentState(), this.hitDelay.getCurrentState() };
        this.toPlace = new structureTemp(0.0, 0, null);
        final boolean b = true;
        this.firstRun = true;
        this.isHole = true;
        final boolean b2 = false;
        this.brokenRedstoneTorch = false;
        this.brokenCrystalBug = false;
        this.broken = false;
        this.hasMoved = false;
        this.slot_mat = new int[] { -1, -1, -1, -1, -1 };
        final int stage = 0;
        this.stuck = 0;
        this.delayTimeTicks = 0;
        this.stage = 0;
        if (PistonAura.mc.field_71439_g == null) {
            this.disable();
            return;
        }
        this.oldSlot = PistonAura.mc.field_71439_g.field_71071_by.field_70461_c;
    }
    
    @Override
    public void onDisable() {
        if (PistonAura.mc.field_71439_g == null) {
            return;
        }
        if (this.isSneaking) {
            PistonAura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)PistonAura.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
        if (this.oldSlot != PistonAura.mc.field_71439_g.field_71071_by.field_70461_c && this.oldSlot != -1) {
            PistonAura.mc.field_71439_g.field_71071_by.field_70461_c = this.oldSlot;
            this.oldSlot = -1;
        }
        this.noMaterials = false;
        this.firstRun = true;
    }
    
    @Override
    public void onUpdate() {
        if (PistonAura.mc.field_71439_g == null) {
            this.disable();
            return;
        }
        if (this.firstRun) {
            this.closestTarget = EntityUtil.getTargetDouble(this.enemyRange.getCurrentState());
            if (this.closestTarget == null) {
                return;
            }
            this.firstRun = false;
            if (this.getMaterialsSlot()) {
                if (this.is_in_hole()) {
                    this.enoughSpace = this.createStructure();
                }
                else {
                    this.isHole = false;
                }
            }
            else {
                this.noMaterials = true;
            }
        }
        else {
            if (this.delayTable == null) {
                return;
            }
            if (this.delayTimeTicks < this.delayTable[this.stage]) {
                ++this.delayTimeTicks;
                return;
            }
            this.delayTimeTicks = 0;
        }
        if (this.noMaterials || !this.isHole || !this.enoughSpace || this.hasMoved) {
            this.disable();
            return;
        }
        if (this.trapPlayer()) {
            if (this.stage == 1) {
                final BlockPos targetPos = this.compactBlockPos(this.stage);
                this.placeBlock(targetPos, this.stage, this.toPlace.offsetX, this.toPlace.offsetZ);
                ++this.stage;
            }
            else if (this.stage == 2) {
                final BlockPos targetPosPiston = this.compactBlockPos(this.stage - 1);
                if (!(this.get_block(targetPosPiston.func_177958_n(), targetPosPiston.func_177956_o(), targetPosPiston.func_177952_p()) instanceof BlockPistonBase)) {
                    --this.stage;
                }
                else {
                    final BlockPos targetPos2 = this.compactBlockPos(this.stage);
                    if (this.placeBlock(targetPos2, this.stage, this.toPlace.offsetX, this.toPlace.offsetZ)) {
                        ++this.stage;
                    }
                }
            }
            else if (this.stage == 3) {
                for (final Entity t : PistonAura.mc.field_71441_e.field_72996_f) {
                    if (t instanceof EntityEnderCrystal && (int)t.field_70165_t == (int)this.toPlace.to_place.get(this.toPlace.supportBlock + 1).field_72450_a && (int)t.field_70161_v == (int)this.toPlace.to_place.get(this.toPlace.supportBlock + 1).field_72449_c) {
                        --this.stage;
                        break;
                    }
                }
                if (this.stage == 3) {
                    final BlockPos targetPos = this.compactBlockPos(this.stage);
                    this.placeBlock(targetPos, this.stage, this.toPlace.offsetX, this.toPlace.offsetZ);
                    ++this.stage;
                }
            }
            else if (this.stage == 4) {
                this.destroyLeCrystal();
            }
        }
    }
    
    public void destroyLeCrystal() {
        Entity crystal = null;
        for (final Entity t : PistonAura.mc.field_71441_e.field_72996_f) {
            if (t instanceof EntityEnderCrystal && (((t.field_70165_t == (int)t.field_70165_t || (int)t.field_70165_t == (int)this.closestTarget.field_70165_t) && ((int)((int)t.field_70165_t - 0.1) == (int)this.closestTarget.field_70165_t || (int)((int)t.field_70165_t + 0.1) == (int)this.closestTarget.field_70165_t) && (int)t.field_70161_v == (int)this.closestTarget.field_70161_v) || ((t.field_70161_v == (int)t.field_70161_v || (int)t.field_70161_v == (int)this.closestTarget.field_70161_v) && ((int)((int)t.field_70161_v - 0.1) == (int)this.closestTarget.field_70161_v || (int)((int)t.field_70161_v + 0.1) == (int)this.closestTarget.field_70161_v) && (int)t.field_70165_t == (int)this.closestTarget.field_70165_t))) {
                crystal = t;
            }
        }
        if (this.broken && crystal == null) {
            final int n = 0;
            this.stuck = 0;
            this.stage = 0;
            this.broken = false;
        }
        if (crystal != null) {
            this.breakCrystalPiston(crystal);
            this.broken = true;
        }
        else if (++this.stuck >= 35) {
            boolean found = false;
            for (final Entity t2 : PistonAura.mc.field_71441_e.field_72996_f) {
                if (t2 instanceof EntityEnderCrystal && (int)t2.field_70165_t == (int)this.toPlace.to_place.get(this.toPlace.supportBlock + 1).field_72450_a && (int)t2.field_70161_v == (int)this.toPlace.to_place.get(this.toPlace.supportBlock + 1).field_72449_c) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                final BlockPos offsetPosPist = new BlockPos((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 2));
                final BlockPos pos = new BlockPos(this.closestTarget.func_174791_d()).func_177982_a(offsetPosPist.func_177958_n(), offsetPosPist.func_177956_o(), offsetPosPist.func_177952_p());
                if (this.brokenRedstoneTorch && this.get_block(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p()) instanceof BlockAir) {
                    this.stage = 1;
                    this.brokenRedstoneTorch = false;
                }
                else {
                    final EnumFacing side = BlockUtil.getPlaceableSide(pos);
                    if (side != null) {
                        if (this.rotate.getCurrentState()) {
                            final BlockPos neighbour = pos.func_177972_a(side);
                            final EnumFacing opposite = side.func_176734_d();
                            final Vec3d hitVec = new Vec3d((Vec3i)neighbour).func_72441_c(0.5, 1.0, 0.5).func_178787_e(new Vec3d(opposite.func_176730_m()).func_186678_a(0.5));
                            BlockUtil.faceVectorPacketInstant(hitVec);
                        }
                        PistonAura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        PistonAura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, side));
                        PistonAura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, side));
                        this.brokenRedstoneTorch = true;
                    }
                }
            }
            else {
                boolean ext = false;
                for (final Entity t3 : PistonAura.mc.field_71441_e.field_72996_f) {
                    if (t3 instanceof EntityEnderCrystal && (int)t3.field_70165_t == (int)this.toPlace.to_place.get(this.toPlace.supportBlock + 1).field_72450_a && (int)t3.field_70161_v == (int)this.toPlace.to_place.get(this.toPlace.supportBlock + 1).field_72449_c) {
                        ext = true;
                        break;
                    }
                }
                final int n2 = 0;
                this.stuck = 0;
                this.stage = 0;
                this.brokenCrystalBug = false;
                if (ext) {
                    this.breakCrystalPiston(null);
                    this.brokenCrystalBug = true;
                }
            }
        }
    }
    
    public BlockPos compactBlockPos(final int step) {
        final BlockPos offsetPos = new BlockPos((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + step - 1));
        return new BlockPos(this.closestTarget.func_174791_d()).func_177982_a(offsetPos.func_177958_n(), offsetPos.func_177956_o(), offsetPos.func_177952_p());
    }
    
    private void breakCrystalPiston(final Entity crystal) {
        if (this.antiWeakness.getCurrentState()) {
            PistonAura.mc.field_71439_g.field_71071_by.field_70461_c = this.slot_mat[4];
        }
        if (this.rotate.getCurrentState()) {
            this.lookAtPacket(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, (EntityPlayer)PistonAura.mc.field_71439_g);
        }
        if (this.breakMode.getCurrentState().equals(BreakModes.swing)) {
            this.breakCrystal(crystal);
            PistonAura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(crystal));
            PistonAura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
        if (this.rotate.getCurrentState()) {
            resetRotation();
        }
    }
    
    private boolean trapPlayer() {
        int i = 0;
        int blockPlaced = 0;
        if (this.toPlace.to_place.size() <= 0 || this.toPlace.supportBlock <= 0) {
            this.stage = ((this.stage == 0) ? 1 : this.stage);
            return true;
        }
        while (true) {
            final BlockPos offsetPos = new BlockPos((Vec3d)this.toPlace.to_place.get(i));
            final BlockPos targetPos = new BlockPos(this.closestTarget.func_174791_d()).func_177982_a(offsetPos.func_177958_n(), offsetPos.func_177956_o(), offsetPos.func_177952_p());
            if (this.placeBlock(targetPos, 0, 0.0, 0.0)) {
                ++blockPlaced;
            }
            if (blockPlaced == this.blocksPerTick.getCurrentState()) {
                return false;
            }
            if (++i >= this.toPlace.supportBlock) {
                this.stage = ((this.stage == 0) ? 1 : this.stage);
                return true;
            }
        }
    }
    
    private boolean placeBlock(final BlockPos pos, final int step, final double offsetX, final double offsetZ) {
        final Block block = PistonAura.mc.field_71441_e.func_180495_p(pos).func_177230_c();
        final EnumFacing side = BlockUtil.getPlaceableSide(pos);
        if (!(block instanceof BlockAir) && !(block instanceof BlockLiquid)) {
            return false;
        }
        if (side == null) {
            return false;
        }
        final BlockPos neighbour = pos.func_177972_a(side);
        final EnumFacing opposite = side.func_176734_d();
        if (!BlockUtil.canBeClicked(neighbour)) {
            return false;
        }
        final Vec3d hitVec = new Vec3d((Vec3i)neighbour).func_72441_c(0.5 + offsetX, 1.0, 0.5 + offsetZ).func_178787_e(new Vec3d(opposite.func_176730_m()).func_186678_a(0.5));
        final Block neighbourBlock = PistonAura.mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
        if (PistonAura.mc.field_71439_g.field_71071_by.func_70301_a(this.slot_mat[step]) != ItemStack.field_190927_a) {
            if (PistonAura.mc.field_71439_g.field_71071_by.field_70461_c != this.slot_mat[step]) {
                PistonAura.mc.field_71439_g.field_71071_by.field_70461_c = ((this.slot_mat[step] == 11) ? PistonAura.mc.field_71439_g.field_71071_by.field_70461_c : this.slot_mat[step]);
            }
            if ((!this.isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
                PistonAura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)PistonAura.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                this.isSneaking = true;
            }
            if (this.rotate.getCurrentState() || step == 1) {
                Vec3d positionHit = hitVec;
                if (!this.rotate.getCurrentState() && step == 1) {
                    positionHit = new Vec3d(PistonAura.mc.field_71439_g.field_70165_t + offsetX, PistonAura.mc.field_71439_g.field_70163_u, PistonAura.mc.field_71439_g.field_70161_v + offsetZ);
                }
                BlockUtil.faceVectorPacketInstant(positionHit);
            }
            EnumHand handSwing = EnumHand.MAIN_HAND;
            if (this.slot_mat[step] == 11) {
                handSwing = EnumHand.OFF_HAND;
            }
            PistonAura.mc.field_71442_b.func_187099_a(PistonAura.mc.field_71439_g, PistonAura.mc.field_71441_e, neighbour, opposite, hitVec, handSwing);
            PistonAura.mc.field_71439_g.func_184609_a(handSwing);
            return true;
        }
        return false;
    }
    
    private boolean getMaterialsSlot() {
        if (PistonAura.mc.field_71439_g.func_184592_cb().func_77973_b() instanceof ItemEndCrystal) {
            this.slot_mat[2] = 11;
        }
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = PistonAura.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != ItemStack.field_190927_a) {
                if (stack.func_77973_b() instanceof ItemEndCrystal) {
                    this.slot_mat[2] = i;
                }
                else if (this.antiWeakness.getCurrentState() && stack.func_77973_b() instanceof ItemSword) {
                    this.slot_mat[4] = i;
                }
                else if (stack.func_77973_b() instanceof ItemBlock) {
                    final Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
                    if (block instanceof BlockObsidian) {
                        this.slot_mat[0] = i;
                    }
                    else if (block instanceof BlockPistonBase) {
                        this.slot_mat[1] = i;
                    }
                    else if (block instanceof BlockRedstoneTorch || block.field_149770_b.equals("blockRedstone")) {
                        this.slot_mat[3] = i;
                    }
                }
            }
        }
        int count = 0;
        for (final int val : this.slot_mat) {
            if (val != -1) {
                ++count;
            }
        }
        return count == 4 + (((boolean)this.antiWeakness.getCurrentState()) ? 1 : 0);
    }
    
    private boolean is_in_hole() {
        this.sur_block = new Double[][] { { this.closestTarget.field_70165_t + 1.0, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v }, { this.closestTarget.field_70165_t - 1.0, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v }, { this.closestTarget.field_70165_t, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v + 1.0 }, { this.closestTarget.field_70165_t, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v - 1.0 } };
        return !(this.get_block(this.sur_block[0][0], this.sur_block[0][1], this.sur_block[0][2]) instanceof BlockAir) && !(this.get_block(this.sur_block[1][0], this.sur_block[1][1], this.sur_block[1][2]) instanceof BlockAir) && !(this.get_block(this.sur_block[2][0], this.sur_block[2][1], this.sur_block[2][2]) instanceof BlockAir) && !(this.get_block(this.sur_block[3][0], this.sur_block[3][1], this.sur_block[3][2]) instanceof BlockAir);
    }
    
    private boolean createStructure() {
        final structureTemp addedStructure = new structureTemp(Double.MAX_VALUE, 0, null);
        int i = 0;
        final int[] meCord = { (int)PistonAura.mc.field_71439_g.field_70165_t, (int)PistonAura.mc.field_71439_g.field_70163_u, (int)PistonAura.mc.field_71439_g.field_70161_v };
        if (meCord[1] - this.closestTarget.field_70163_u > -1.0) {
            for (final Double[] cord_b : this.sur_block) {
                final double[] crystalCords = { cord_b[0], cord_b[1] + 1.0, cord_b[2] };
                final BlockPos positionCrystal = new BlockPos(crystalCords[0], crystalCords[1], crystalCords[2]);
                final double distance_now;
                if ((distance_now = PistonAura.mc.field_71439_g.func_70011_f(crystalCords[0], crystalCords[1], crystalCords[2])) < addedStructure.distance && (positionCrystal.func_177956_o() != meCord[1] || meCord[0] != positionCrystal.func_177958_n() || (Math.abs(meCord[2] - positionCrystal.func_177952_p()) > 3 && meCord[2] != positionCrystal.func_177952_p()) || Math.abs(meCord[0] - positionCrystal.func_177958_n()) > 3)) {
                    ++cord_b[1];
                    if (this.get_block(crystalCords[0], crystalCords[1], crystalCords[2]) instanceof BlockAir) {
                        final double[] pistonCord = { crystalCords[0] + this.disp_surblock[i][0], crystalCords[1], crystalCords[2] + this.disp_surblock[i][2] };
                        final Block blockPiston = this.get_block(pistonCord[0], pistonCord[1], pistonCord[2]);
                        if ((blockPiston instanceof BlockAir || blockPiston instanceof BlockPistonBase) && this.someoneInCoords(pistonCord[0], pistonCord[1], pistonCord[2])) {
                            boolean b = false;
                            Label_0664: {
                                if (this.rotate.getCurrentState()) {
                                    if ((int)pistonCord[0] == meCord[0]) {
                                        if (this.closestTarget.field_70161_v > PistonAura.mc.field_71439_g.field_70161_v == this.closestTarget.field_70161_v > pistonCord[2]) {
                                            if (Math.abs((int)this.closestTarget.field_70161_v - (int)PistonAura.mc.field_71439_g.field_70161_v) != 1) {
                                                break Label_0664;
                                            }
                                        }
                                    }
                                    else if ((int)pistonCord[2] == meCord[2] && ((this.closestTarget.field_70165_t > PistonAura.mc.field_71439_g.field_70165_t == this.closestTarget.field_70165_t > pistonCord[0] && Math.abs((int)this.closestTarget.field_70165_t - (int)PistonAura.mc.field_71439_g.field_70165_t) != 1) || (Math.abs((int)this.closestTarget.field_70165_t - (int)PistonAura.mc.field_71439_g.field_70165_t) > 1 && pistonCord[0] > this.closestTarget.field_70165_t == meCord[0] > this.closestTarget.field_70165_t))) {
                                        break Label_0664;
                                    }
                                }
                                b = true;
                            }
                            final boolean join = b;
                            if (join) {
                                boolean b2 = false;
                                Label_0853: {
                                    if (this.rotate.getCurrentState()) {
                                        if (meCord[0] == (int)this.closestTarget.field_70165_t || meCord[2] == (int)this.closestTarget.field_70161_v) {
                                            if (PistonAura.mc.field_71439_g.func_70011_f(crystalCords[0], crystalCords[1], crystalCords[2]) > 3.5) {
                                                if (meCord[0] != (int)crystalCords[0]) {
                                                    if (meCord[2] != (int)crystalCords[2]) {
                                                        break Label_0853;
                                                    }
                                                }
                                            }
                                        }
                                        else if (meCord[0] == (int)pistonCord[0] && Math.abs((int)this.closestTarget.field_70161_v - (int)PistonAura.mc.field_71439_g.field_70161_v) != 1 && (meCord[2] != (int)pistonCord[2] || Math.abs((int)this.closestTarget.field_70161_v - (int)PistonAura.mc.field_71439_g.field_70161_v) == 1)) {
                                            break Label_0853;
                                        }
                                    }
                                    b2 = true;
                                }
                                final boolean enter = b2;
                                if (enter) {
                                    int[] poss = null;
                                    for (final int[] possibilites : this.disp_surblock) {
                                        final double[] coordinatesTemp = { cord_b[0] + this.disp_surblock[i][0] + possibilites[0], cord_b[1], cord_b[2] + this.disp_surblock[i][2] + possibilites[2] };
                                        final int[] torchCoords = { (int)coordinatesTemp[0], (int)coordinatesTemp[1], (int)coordinatesTemp[2] };
                                        final int[] crystalCoords = { (int)crystalCords[0], (int)crystalCords[1], (int)crystalCords[2] };
                                        if (this.get_block(coordinatesTemp[0], coordinatesTemp[1], coordinatesTemp[2]) instanceof BlockAir && (torchCoords[0] != crystalCoords[0] || torchCoords[1] != crystalCoords[1] || crystalCoords[2] != torchCoords[2]) && this.someoneInCoords(coordinatesTemp[0], coordinatesTemp[1], coordinatesTemp[2])) {
                                            poss = possibilites;
                                            break;
                                        }
                                    }
                                    if (poss != null) {
                                        final List<Vec3d> toPlaceTemp = new ArrayList<Vec3d>();
                                        int supportBlock = 0;
                                        if (this.get_block(cord_b[0] + this.disp_surblock[i][0], cord_b[1] - 1.0, cord_b[2] + this.disp_surblock[i][2]) instanceof BlockAir) {
                                            toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2), (double)this.disp_surblock[i][1], (double)(this.disp_surblock[i][2] * 2)));
                                            ++supportBlock;
                                        }
                                        if (this.get_block(cord_b[0] + this.disp_surblock[i][0] + poss[0], cord_b[1] - 1.0, cord_b[2] + this.disp_surblock[i][2] + poss[2]) instanceof BlockAir) {
                                            toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2 + poss[0]), (double)this.disp_surblock[i][1], (double)(this.disp_surblock[i][2] * 2 + poss[2])));
                                            ++supportBlock;
                                        }
                                        toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2), (double)(this.disp_surblock[i][1] + 1), (double)(this.disp_surblock[i][2] * 2)));
                                        toPlaceTemp.add(new Vec3d((double)this.disp_surblock[i][0], (double)(this.disp_surblock[i][1] + 1), (double)this.disp_surblock[i][2]));
                                        toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2 + poss[0]), (double)(this.disp_surblock[i][1] + 1), (double)(this.disp_surblock[i][2] * 2 + poss[2])));
                                        float offsetX;
                                        float offsetZ;
                                        if (this.disp_surblock[i][0] != 0) {
                                            offsetX = (this.rotate.getCurrentState() ? (this.disp_surblock[i][0] / 2.0f) : ((float)this.disp_surblock[i][0]));
                                            if (this.rotate.getCurrentState()) {
                                                if (PistonAura.mc.field_71439_g.func_70092_e(pistonCord[0], pistonCord[1], pistonCord[2] + 0.5) > PistonAura.mc.field_71439_g.func_70092_e(pistonCord[0], pistonCord[1], pistonCord[2] - 0.5)) {
                                                    offsetZ = -0.5f;
                                                }
                                                else {
                                                    offsetZ = 0.5f;
                                                }
                                            }
                                            else {
                                                offsetZ = (float)this.disp_surblock[i][2];
                                            }
                                        }
                                        else {
                                            offsetZ = (this.rotate.getCurrentState() ? (this.disp_surblock[i][2] / 2.0f) : ((float)this.disp_surblock[i][2]));
                                            if (this.rotate.getCurrentState()) {
                                                if (PistonAura.mc.field_71439_g.func_70092_e(pistonCord[0] + 0.5, pistonCord[1], pistonCord[2]) > PistonAura.mc.field_71439_g.func_70092_e(pistonCord[0] - 0.5, pistonCord[1], pistonCord[2])) {
                                                    offsetX = -0.5f;
                                                }
                                                else {
                                                    offsetX = 0.5f;
                                                }
                                            }
                                            else {
                                                offsetX = (float)this.disp_surblock[i][0];
                                            }
                                        }
                                        addedStructure.replaceValues(distance_now, supportBlock, toPlaceTemp, -1, offsetX, offsetZ);
                                    }
                                }
                            }
                        }
                    }
                }
                ++i;
            }
            if (addedStructure.to_place != null) {
                if (this.blockPlayer.getCurrentState()) {
                    final Vec3d valuesStart = addedStructure.to_place.get(addedStructure.supportBlock + 1);
                    final int[] valueBegin = { (int)(-valuesStart.field_72450_a), (int)valuesStart.field_72448_b, (int)(-valuesStart.field_72449_c) };
                    addedStructure.to_place.add(0, new Vec3d(0.0, 2.0, 0.0));
                    addedStructure.to_place.add(0, new Vec3d((double)valueBegin[0], (double)(valueBegin[1] + 1), (double)valueBegin[2]));
                    addedStructure.to_place.add(0, new Vec3d((double)valueBegin[0], (double)valueBegin[1], (double)valueBegin[2]));
                    final structureTemp structureTemp = addedStructure;
                    structureTemp.supportBlock += 3;
                }
                this.toPlace = addedStructure;
                return true;
            }
        }
        return false;
    }
    
    private boolean someoneInCoords(final double x, final double y, final double z) {
        final int xCheck = (int)x;
        final int yCheck = (int)y;
        final int zCheck = (int)z;
        final List<EntityPlayer> playerList = (List<EntityPlayer>)PistonAura.mc.field_71441_e.field_73010_i;
        for (final EntityPlayer player : playerList) {
            if ((int)player.field_70165_t == xCheck && (int)player.field_70161_v == zCheck && (int)player.field_70163_u >= yCheck - 1 && (int)player.field_70163_u <= yCheck + 1) {
                return false;
            }
        }
        return true;
    }
    
    private Block get_block(final double x, final double y, final double z) {
        return PistonAura.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
    }
    
    private void lookAtPacket(final double px, final double py, final double pz, final EntityPlayer me) {
        final double[] v = calculateLookAt(px, py, pz, me);
        setYawAndPitch((float)v[0], (float)v[1]);
    }
    
    public static double[] calculateLookAt(final double px, final double py, final double pz, final EntityPlayer me) {
        double dirx = me.field_70165_t - px;
        double diry = me.field_70163_u - py;
        double dirz = me.field_70161_v - pz;
        final double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
        dirx /= len;
        diry /= len;
        dirz /= len;
        double pitch = Math.asin(diry);
        double yaw = Math.atan2(dirz, dirx);
        pitch = pitch * 180.0 / 3.141592653589793;
        yaw = yaw * 180.0 / 3.141592653589793;
        yaw += 90.0;
        return new double[] { yaw, pitch };
    }
    
    private static void setYawAndPitch(final float yaw1, final float pitch1) {
        PistonAura.yaw = yaw1;
        PistonAura.pitch = pitch1;
        PistonAura.isSpoofingAngles = true;
    }
    
    private void breakCrystal(final Entity crystal) {
        PistonAura.mc.field_71442_b.func_78764_a((EntityPlayer)PistonAura.mc.field_71439_g, crystal);
        PistonAura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        final Packet<?> packet = event.getPacket();
        if (packet instanceof CPacketPlayer && PistonAura.isSpoofingAngles) {
            ((CPacketPlayer)packet).field_149476_e = (float)PistonAura.yaw;
            ((CPacketPlayer)packet).field_149473_f = (float)PistonAura.pitch;
        }
    }
    
    private static void resetRotation() {
        if (PistonAura.isSpoofingAngles) {
            PistonAura.yaw = PistonAura.mc.field_71439_g.field_70177_z;
            PistonAura.pitch = PistonAura.mc.field_71439_g.field_70125_A;
            PistonAura.isSpoofingAngles = false;
        }
    }
    
    static class structureTemp
    {
        public double distance;
        public int supportBlock;
        public List<Vec3d> to_place;
        public int direction;
        public float offsetX;
        public float offsetZ;
        
        public structureTemp(final double distance, final int supportBlock, final List<Vec3d> to_place) {
            this.distance = distance;
            this.supportBlock = supportBlock;
            this.to_place = to_place;
            this.direction = -1;
        }
        
        public void replaceValues(final double distance, final int supportBlock, final List<Vec3d> to_place, final int direction, final float offsetX, final float offsetZ) {
            this.distance = distance;
            this.supportBlock = supportBlock;
            this.to_place = to_place;
            this.direction = direction;
            this.offsetX = offsetX;
            this.offsetZ = offsetZ;
        }
    }
    
    private enum BreakModes
    {
        packet, 
        swing;
    }
}
