// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import java.util.Iterator;
import client.util.PlayerUtil;
import client.util.MathUtil;
import net.minecraft.entity.EntityLivingBase;
import client.Client;
import net.minecraft.entity.player.EntityPlayer;
import client.util.EntityUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.events.UpdateWalkingPlayerEvent;
import client.gui.impl.setting.Setting;
import client.util.Timer;
import net.minecraft.entity.Entity;
import client.modules.Module;

public class Aura extends Module
{
    public static Entity target;
    private final Timer timer;
    public Setting<Float> range;
    public Setting<Float> wallRange;
    public Setting<Boolean> delay;
    public Setting<Boolean> rotate;
    public Setting<Boolean> swordOnly;
    public Setting<Boolean> players;
    public Setting<Boolean> mobs;
    public Setting<Boolean> animals;
    public Setting<Boolean> vehicles;
    public Setting<Boolean> projectiles;
    public Setting<Boolean> tps;
    public Setting<Boolean> packet;
    
    public Aura() {
        super("Aura", "Attacks enemies.", Category.COMBAT);
        this.timer = new Timer();
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)6.0f, (T)0.1f, (T)7.0f));
        this.wallRange = (Setting<Float>)this.register(new Setting("WallRange", (T)6.0f, (T)0.1f, (T)7.0f));
        this.delay = (Setting<Boolean>)this.register(new Setting("Delay", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.swordOnly = (Setting<Boolean>)this.register(new Setting("SwordOnly", (T)true));
        this.players = (Setting<Boolean>)this.register(new Setting("Players", (T)true));
        this.mobs = (Setting<Boolean>)this.register(new Setting("Mobs", (T)false));
        this.animals = (Setting<Boolean>)this.register(new Setting("Animals", (T)false));
        this.vehicles = (Setting<Boolean>)this.register(new Setting("Entities", (T)false));
        this.projectiles = (Setting<Boolean>)this.register(new Setting("Projectiles", (T)false));
        this.tps = (Setting<Boolean>)this.register(new Setting("TpsSync", (T)true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
    }
    
    @Override
    public void onTick() {
        if (!this.rotate.getCurrentState()) {
            this.attackEnemy();
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayerEvent(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0 && this.rotate.getCurrentState()) {
            this.attackEnemy();
        }
    }
    
    private void attackEnemy() {
        if (this.swordOnly.getCurrentState() && !EntityUtil.holdingWeapon((EntityPlayer)Aura.mc.field_71439_g)) {
            Aura.target = null;
            return;
        }
        final int wait = this.delay.getCurrentState() ? ((int)(EntityUtil.getCooldownByWeapon((EntityPlayer)Aura.mc.field_71439_g) * (this.tps.getCurrentState() ? Client.serverManager.getTpsFactor() : 1.0f))) : 0;
        if (!this.timer.passedMs(wait)) {
            return;
        }
        Aura.target = this.getTarget();
        if (Aura.target == null) {
            return;
        }
        if (this.rotate.getCurrentState()) {
            Client.rotationManager.lookAtEntity(Aura.target);
        }
        EntityUtil.attackEntity(Aura.target, this.packet.getCurrentState(), true);
        this.timer.reset();
    }
    
    private Entity getTarget() {
        Entity target = null;
        double distance = this.range.getCurrentState();
        double maxHealth = 36.0;
        for (final Entity entity : Aura.mc.field_71441_e.field_73010_i) {
            if ((this.players.getCurrentState() && entity instanceof EntityPlayer) || (this.animals.getCurrentState() && EntityUtil.isPassive(entity)) || (this.mobs.getCurrentState() && EntityUtil.isMobAggressive(entity)) || (this.vehicles.getCurrentState() && EntityUtil.isVehicle(entity)) || (this.projectiles.getCurrentState() && EntityUtil.isProjectile(entity))) {
                if (entity instanceof EntityLivingBase && EntityUtil.isntValid(entity, distance)) {
                    continue;
                }
                if (!Aura.mc.field_71439_g.func_70685_l(entity) && !EntityUtil.canEntityFeetBeSeen(entity) && Aura.mc.field_71439_g.func_70068_e(entity) > MathUtil.square(this.wallRange.getCurrentState())) {
                    continue;
                }
                if (target == null) {
                    target = entity;
                    distance = Aura.mc.field_71439_g.func_70068_e(entity);
                    maxHealth = EntityUtil.getHealth(entity);
                }
                else {
                    if (entity instanceof EntityPlayer && PlayerUtil.isArmorLow((EntityPlayer)entity, 18)) {
                        target = entity;
                        break;
                    }
                    if (Aura.mc.field_71439_g.func_70068_e(entity) < distance) {
                        target = entity;
                        distance = Aura.mc.field_71439_g.func_70068_e(entity);
                        maxHealth = EntityUtil.getHealth(entity);
                    }
                    if (EntityUtil.getHealth(entity) >= maxHealth) {
                        continue;
                    }
                    target = entity;
                    distance = Aura.mc.field_71439_g.func_70068_e(entity);
                    maxHealth = EntityUtil.getHealth(entity);
                }
            }
        }
        return target;
    }
    
    @Override
    public String getDisplayInfo() {
        if (Aura.target instanceof EntityPlayer) {
            return Aura.target.func_70005_c_();
        }
        return null;
    }
}
