// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import java.util.Iterator;
import client.util.RenderUtil;
import client.util.ColorUtil;
import client.modules.client.ClickGui;
import java.awt.Color;
import client.events.Render3DEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Collection;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnObject;
import client.events.PacketEvent;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.entity.item.EntityEnderCrystal;
import java.util.List;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumFacing;
import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import client.util.PlayerUtil;
import net.minecraft.entity.Entity;
import client.util.BlockUtil;
import client.util.EntityUtil;
import net.minecraft.init.Items;
import java.util.HashSet;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.ArrayList;
import net.minecraft.entity.player.EntityPlayer;
import client.util.Timer;
import net.minecraft.util.math.BlockPos;
import java.util.Set;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class AutoCrystal extends Module
{
    public Setting<Settings> setting;
    public Setting<SpeedFactor> speedFactor;
    public Setting<Boolean> doBreak;
    public Setting<Boolean> doPlace;
    public Setting<Float> targetRange;
    public Setting<Boolean> cancel;
    public Setting<Float> breakRange;
    public Setting<Float> breakWallRange;
    public Setting<Integer> breakDelay;
    public Setting<Boolean> instant;
    public Setting<Priority> priority;
    public Setting<Float> placeRange;
    public Setting<Float> placeRangeWall;
    public Setting<Integer> armorPercent;
    public Setting<Float> facePlaceHP;
    public Setting<Float> minDamage;
    public Setting<Float> maxSelfDamage;
    public Setting<Boolean> swing;
    public Setting<Boolean> announceOnly;
    public Setting<Boolean> text;
    public Setting<Boolean> box;
    public Setting<RenderMode> renderMode;
    public Setting<Float> accel;
    public Setting<Float> moveSpeed;
    public Setting<Enum> fade;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Boolean> rainbow;
    public Setting<Boolean> outline;
    public Setting<Integer> cRed;
    public Setting<Integer> cGreen;
    public Setting<Integer> cBlue;
    public Setting<Integer> cAlpha;
    public Setting<Integer> lineWidth;
    public Setting<Boolean> cRainbow;
    public Set<BlockPos> placeSet;
    public Timer clearTimer;
    public Timer breakTimer;
    public int predictedId;
    public BlockPos renderPos;
    public BlockPos pos2;
    public EntityPlayer target;
    public boolean offhand;
    public boolean mainhand;
    public static AutoCrystal INSTANCE;
    private final ArrayList<RenderPos> renderMap;
    private final ArrayList<BlockPos> currentTargets;
    private BlockPos lastRenderPos;
    private AxisAlignedBB renderBB;
    private float timePassed;
    
    public AutoCrystal() {
        super("AutoCrystal", "Automatically places/breaks crystals to deal damage to opponents.", Category.COMBAT);
        this.renderMap = new ArrayList<RenderPos>();
        this.currentTargets = new ArrayList<BlockPos>();
        this.setting = (Setting<Settings>)this.register(new Setting("Setting", (T)Settings.AUTOCRYSTAL));
        this.speedFactor = (Setting<SpeedFactor>)this.register(new Setting("SpeedFactor", (T)SpeedFactor.UPDATE));
        this.doPlace = (Setting<Boolean>)this.register(new Setting("Place", (T)true, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.doBreak = (Setting<Boolean>)this.register(new Setting("Break", (T)true, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.breakRange = (Setting<Float>)this.register(new Setting("BreakRange", (T)5.0f, (T)1.0f, (T)6.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.placeRange = (Setting<Float>)this.register(new Setting("PlaceRange", (T)5.0f, (T)1.0f, (T)6.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.targetRange = (Setting<Float>)this.register(new Setting("TargetRange", (T)9.0f, (T)1.0f, (T)15.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.breakWallRange = (Setting<Float>)this.register(new Setting("BreakRangeWall", (T)5.0f, (T)1.0f, (T)6.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.placeRangeWall = (Setting<Float>)this.register(new Setting("PlaceRangeWall", (T)5.0f, (T)1.0f, (T)6.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.breakDelay = (Setting<Integer>)this.register(new Setting("BreakDelay", (T)0, (T)0, (T)200, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.instant = (Setting<Boolean>)this.register(new Setting("Predict", (T)false, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.priority = (Setting<Priority>)this.register(new Setting("PrioritizeSelf", (T)Priority.SELF, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.cancel = (Setting<Boolean>)this.register(new Setting("Cancel", (T)true, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.armorPercent = (Setting<Integer>)this.register(new Setting("Armor%", (T)10, (T)0, (T)100, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.facePlaceHP = (Setting<Float>)this.register(new Setting("FaceplaceHP", (T)8.0f, (T)0.0f, (T)36.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.minDamage = (Setting<Float>)this.register(new Setting("MinDamage", (T)4.0f, (T)1.0f, (T)36.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.maxSelfDamage = (Setting<Float>)this.register(new Setting("MaxSelfDmg", (T)8.0f, (T)1.0f, (T)36.0f, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.swing = (Setting<Boolean>)this.register(new Setting("Swing", (T)false, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.announceOnly = (Setting<Boolean>)this.register(new Setting("AnnounceOnly", (T)false, v -> this.setting.getCurrentState() == Settings.AUTOCRYSTAL));
        this.renderMode = (Setting<RenderMode>)this.register(new Setting("RenderMode", (T)RenderMode.NORMAL, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)true, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.fade = (Setting<Enum>)this.register(new Setting("Fade", (T)Enum.FAST, v -> this.setting.getCurrentState() == Settings.RENDER && this.renderMode.getCurrentState() == RenderMode.FADE));
        this.accel = (Setting<Float>)this.register(new Setting("Deceleration", (T)0.8f, (T)0.0f, (T)1.0f, v -> this.setting.getCurrentState() == Settings.RENDER && this.renderMode.getCurrentState() == RenderMode.GLIDE));
        this.moveSpeed = (Setting<Float>)this.register(new Setting("Speed", (T)900.0f, (T)0.0f, (T)1500.0f, v -> this.setting.getCurrentState() == Settings.RENDER && this.renderMode.getCurrentState() == RenderMode.GLIDE));
        this.red = (Setting<Integer>)this.register(new Setting("BoxRed", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.green = (Setting<Integer>)this.register(new Setting("BoxGreen", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.blue = (Setting<Integer>)this.register(new Setting("BoxBlue", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.alpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)120, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("BoxRainbow", (T)true, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.cRed = (Setting<Integer>)this.register(new Setting("OutlineRed", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.cGreen = (Setting<Integer>)this.register(new Setting("OutlineGreen", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.cBlue = (Setting<Integer>)this.register(new Setting("OutlineBlue", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.cAlpha = (Setting<Integer>)this.register(new Setting("OutlineAlpha", (T)255, (T)0, (T)255, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.lineWidth = (Setting<Integer>)this.register(new Setting("OutlineWidth", (T)1, (T)0, (T)5, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.cRainbow = (Setting<Boolean>)this.register(new Setting("OutlineRainbow", (T)true, v -> this.setting.getCurrentState() == Settings.RENDER));
        this.placeSet = new HashSet<BlockPos>();
        this.clearTimer = new Timer();
        this.breakTimer = new Timer();
        this.predictedId = -1;
        this.renderPos = null;
        this.pos2 = null;
        this.target = null;
        AutoCrystal.INSTANCE = this;
    }
    
    public static AutoCrystal getInstance() {
        return AutoCrystal.INSTANCE;
    }
    
    private boolean update() {
        if (fullNullCheck()) {
            return false;
        }
        if (this.clearTimer.hasReached(500L)) {
            this.placeSet.clear();
            this.predictedId = -1;
            this.renderPos = null;
            this.clearTimer.reset();
        }
        this.offhand = (AutoCrystal.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
        this.mainhand = (AutoCrystal.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP);
        return true;
    }
    
    @Override
    public void onToggle() {
        this.placeSet.clear();
        this.predictedId = -1;
        this.renderPos = null;
    }
    
    @Override
    public void onUpdate() {
        if (!this.update()) {
            return;
        }
        this.target = EntityUtil.getTarget(this.targetRange.getCurrentState());
        if (this.target == null) {
            return;
        }
        if (this.speedFactor.getCurrentState() == SpeedFactor.UPDATE && !this.announceOnly.getCurrentState()) {
            if (this.doPlace.getCurrentState()) {
                this.doPlace();
            }
            if (this.doBreak.getCurrentState()) {
                this.doBreak();
            }
        }
    }
    
    @Override
    public void onDisable() {
        this.lastRenderPos = null;
    }
    
    @Override
    public void onTick() {
        if (this.speedFactor.getCurrentState() == SpeedFactor.TICK && !this.announceOnly.getCurrentState()) {
            if (this.doPlace.getCurrentState()) {
                this.doPlace();
            }
            if (this.doBreak.getCurrentState()) {
                this.doBreak();
            }
        }
    }
    
    private void doPlace() {
        BlockPos placePos = null;
        float maxDamage = 0.5f;
        final List<BlockPos> sphere = BlockUtil.getSphere(this.placeRange.getCurrentState(), true);
        for (int size = sphere.size(), i = 0; i < size; ++i) {
            final BlockPos pos = sphere.get(i);
            final float self = this.calculate(pos, (EntityPlayer)AutoCrystal.mc.field_71439_g);
            if (BlockUtil.canPlaceCrystal(pos, true)) {
                if (this.priority.getCurrentState() == Priority.SELF) {
                    final float damage;
                    if (EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g) > self + 0.5f && this.maxSelfDamage.getCurrentState() > self && (damage = this.calculate(pos, this.target)) > maxDamage && damage > self) {
                        if (damage <= this.minDamage.getCurrentState()) {
                            if (this.facePlaceHP.getCurrentState() <= EntityUtil.getHealth((Entity)this.target) && !PlayerUtil.isArmorLow(this.target, this.armorPercent.getCurrentState())) {
                                continue;
                            }
                            if (damage <= 2.0f) {
                                continue;
                            }
                        }
                        maxDamage = damage;
                        placePos = pos;
                        this.pos2 = placePos;
                        this.currentTargets.clear();
                        this.currentTargets.add(pos);
                    }
                }
                else {
                    final float damage;
                    if (this.priority.getCurrentState() == Priority.ENEMY && EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g) > self + 0.5f && this.maxSelfDamage.getCurrentState() > self && (damage = this.calculate(pos, this.target)) > maxDamage) {
                        if (damage <= this.minDamage.getCurrentState()) {
                            if (this.facePlaceHP.getCurrentState() <= EntityUtil.getHealth((Entity)this.target) && !PlayerUtil.isArmorLow(this.target, this.armorPercent.getCurrentState())) {
                                continue;
                            }
                            if (damage <= 2.0f) {
                                continue;
                            }
                        }
                        maxDamage = damage;
                        placePos = pos;
                        this.pos2 = placePos;
                        this.currentTargets.clear();
                        this.currentTargets.add(pos);
                    }
                }
            }
        }
        if (!this.offhand && !this.mainhand) {
            this.renderPos = null;
            return;
        }
        if (placePos != null) {
            this.clearMap(placePos);
            Objects.requireNonNull(AutoCrystal.mc.func_147114_u()).func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(placePos, EnumFacing.UP, this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.5f, 0.5f, 0.5f));
            this.renderMap.add(new RenderPos(placePos, 0.0));
            this.placeSet.add(placePos);
            this.renderPos = placePos;
        }
        else {
            this.renderPos = null;
        }
    }
    
    private void doBreak() {
        Entity entity = null;
        for (int size = AutoCrystal.mc.field_71441_e.field_72996_f.size(), i = 0; i < size; ++i) {
            final Entity crystal = AutoCrystal.mc.field_71441_e.field_72996_f.get(i);
            if (crystal.getClass() == EntityEnderCrystal.class && this.isValid(crystal) && crystal.func_145782_y() != this.predictedId) {
                final float self = this.calculate(crystal, (EntityPlayer)AutoCrystal.mc.field_71439_g);
                if (this.priority.getCurrentState() == Priority.SELF) {
                    final float damage;
                    if (EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g) > self + 0.5f && (damage = this.calculate(crystal, this.target)) > self && damage > self) {
                        if (damage <= this.minDamage.getCurrentState()) {
                            if (this.facePlaceHP.getCurrentState() <= EntityUtil.getHealth((Entity)this.target) && !PlayerUtil.isArmorLow(this.target, this.armorPercent.getCurrentState())) {
                                continue;
                            }
                            if (damage <= 2.0f) {
                                continue;
                            }
                        }
                        entity = crystal;
                    }
                }
                else {
                    final float damage;
                    if (this.priority.getCurrentState() == Priority.ENEMY && EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g) > self + 0.5f && (damage = this.calculate(crystal, this.target)) > self) {
                        if (damage <= this.minDamage.getCurrentState()) {
                            if (this.facePlaceHP.getCurrentState() <= EntityUtil.getHealth((Entity)this.target) && !PlayerUtil.isArmorLow(this.target, this.armorPercent.getCurrentState())) {
                                continue;
                            }
                            if (damage <= 2.0f) {
                                continue;
                            }
                        }
                        entity = crystal;
                    }
                }
            }
            if (entity != null && this.breakTimer.passedMs(this.breakDelay.getCurrentState())) {
                final BlockPos renderPos = entity.func_180425_c().func_177977_b();
                this.clearMap(renderPos);
                Objects.requireNonNull(AutoCrystal.mc.func_147114_u()).func_147297_a((Packet)new CPacketUseEntity(entity));
                this.renderMap.add(new RenderPos(renderPos, 0.0));
                if (this.swing.getCurrentState()) {
                    AutoCrystal.mc.field_71439_g.func_184609_a(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
                }
                this.breakTimer.reset();
            }
        }
    }
    
    private boolean isValid(final Entity crystal) {
        return (AutoCrystal.mc.field_71439_g.func_70685_l(crystal) ? (this.breakRange.getCurrentState() * this.breakRange.getCurrentState()) : (this.breakWallRange.getCurrentState() * this.breakWallRange.getCurrentState())) > AutoCrystal.mc.field_71439_g.func_70068_e(crystal);
    }
    
    private float calculate(final Entity crystal, final EntityPlayer target) {
        return EntityUtil.calculate(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, (EntityLivingBase)target);
    }
    
    private float calculate(final BlockPos pos, final EntityPlayer entity) {
        return EntityUtil.calculate(pos.func_177958_n() + 0.5f, pos.func_177956_o() + 1, pos.func_177952_p() + 0.5f, (EntityLivingBase)entity);
    }
    
    public void instantHit(final int id) {
        final CPacketUseEntity hitPacket = new CPacketUseEntity();
        hitPacket.field_149567_a = id;
        hitPacket.field_149566_b = CPacketUseEntity.Action.ATTACK;
        Objects.requireNonNull(AutoCrystal.mc.func_147114_u()).func_147297_a((Packet)hitPacket);
        this.predictedId = id;
        if (this.swing.getCurrentState()) {
            AutoCrystal.mc.field_71439_g.func_184609_a(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketSpawnObject && this.instant.getCurrentState()) {
            final Object packet = event.getPacket();
            final BlockPos pos = new BlockPos(((SPacketSpawnObject)packet).func_186880_c(), ((SPacketSpawnObject)packet).func_186882_d(), ((SPacketSpawnObject)packet).func_186881_e());
            if (((SPacketSpawnObject)packet).func_148993_l() == 51 && this.placeSet.contains(pos.func_177977_b())) {
                if (AutoCrystal.mc.field_71439_g.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()) > this.breakRange.getCurrentState()) {
                    return;
                }
                this.instantHit(((SPacketSpawnObject)packet).func_149001_c());
            }
        }
        Object packet;
        if (event.getPacket() instanceof SPacketSoundEffect && this.cancel.getCurrentState() && ((SPacketSoundEffect)(packet = event.getPacket())).func_186977_b() == SoundCategory.BLOCKS && ((SPacketSoundEffect)packet).func_186978_a() == SoundEvents.field_187539_bB) {
            final ArrayList<Entity> entities = new ArrayList<Entity>(AutoCrystal.mc.field_71441_e.field_72996_f);
            for (int size = entities.size(), i = 0; i < size; ++i) {
                final Entity entity = entities.get(i);
                if (entity instanceof EntityEnderCrystal && entity.func_70092_e(((SPacketSoundEffect)packet).func_149207_d(), ((SPacketSoundEffect)packet).func_149211_e(), ((SPacketSoundEffect)packet).func_149210_f()) < 36.0) {
                    entity.func_70106_y();
                }
            }
        }
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.renderMap.isEmpty()) {
            return;
        }
        final List<RenderPos> toRemove = new ArrayList<RenderPos>();
        for (final RenderPos renderPos : this.renderMap) {
            final Color color = new Color(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), (int)Math.max(this.alpha.getCurrentState() - renderPos.alpha, 0.0));
            final Color color2 = new Color(this.cRed.getCurrentState(), this.cGreen.getCurrentState(), this.cBlue.getCurrentState(), (int)Math.max(this.cAlpha.getCurrentState() - renderPos.alpha, 0.0));
            if (this.renderMode.getCurrentState() == RenderMode.NORMAL || this.renderMode.getCurrentState() == RenderMode.FADE) {
                RenderUtil.drawBoxESP(renderPos.pos, ((boolean)this.rainbow.getCurrentState()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getCurrentState()) : color, this.outline.getCurrentState(), ((boolean)this.cRainbow.getCurrentState()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getCurrentState()) : color2, this.lineWidth.getCurrentState(), this.outline.getCurrentState(), this.box.getCurrentState(), (int)Math.max(this.cAlpha.getCurrentState() - renderPos.alpha, 0.0), true);
            }
            if (renderPos.alpha > Math.max(this.alpha.getCurrentState(), ((boolean)this.rainbow.getCurrentState()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getCurrentState()).getRGB() : ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState()))) {
                toRemove.add(renderPos);
            }
            renderPos.alpha += ((this.fade.getCurrentState() == Enum.FAST) ? 1.5 : ((this.fade.getCurrentState() == Enum.SLOW) ? 0.5 : 1.0));
            if (this.currentTargets.contains(renderPos.pos)) {
                renderPos.alpha = 0.0;
            }
            else {
                if (this.renderMode.getCurrentState() == RenderMode.FADE) {
                    continue;
                }
                toRemove.add(renderPos);
            }
        }
        this.renderMap.removeAll(toRemove);
        if (this.renderMode.getCurrentState() == RenderMode.GLIDE && this.renderPos != null) {
            final Color color3 = new Color(this.cRed.getCurrentState(), this.cGreen.getCurrentState(), this.cBlue.getCurrentState(), this.cAlpha.getCurrentState());
            final Color color4 = new Color(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState());
            if (this.lastRenderPos == null || AutoCrystal.mc.field_71439_g.func_70011_f(this.renderBB.field_72340_a, this.renderBB.field_72338_b, this.renderBB.field_72339_c) > this.placeRange.getCurrentState()) {
                this.lastRenderPos = this.renderPos;
                this.renderBB = new AxisAlignedBB(this.renderPos);
                this.timePassed = 0.0f;
            }
            if (!this.lastRenderPos.equals((Object)this.renderPos)) {
                this.lastRenderPos = this.renderPos;
                this.timePassed = 0.0f;
            }
            final double xDiff = this.renderPos.func_177958_n() - this.renderBB.field_72340_a;
            final double yDiff = this.renderPos.func_177956_o() - this.renderBB.field_72338_b;
            final double zDiff = this.renderPos.func_177952_p() - this.renderBB.field_72339_c;
            float multiplier = this.timePassed / this.moveSpeed.getCurrentState() * this.accel.getCurrentState();
            if (multiplier > 1.0f) {
                multiplier = 1.0f;
            }
            RenderUtil.drawPerryESP(this.renderBB = this.renderBB.func_72317_d(xDiff * multiplier, yDiff * multiplier, zDiff * multiplier), color4, color3, this.lineWidth.getCurrentState(), this.outline.getCurrentState(), this.box.getCurrentState(), 1.0f, 1.0f, 1.0f);
            if (this.renderBB.equals((Object)new AxisAlignedBB(this.renderPos))) {
                this.timePassed = 0.0f;
            }
            else {
                this.timePassed += 50.0f;
            }
        }
    }
    
    private void clearMap(final BlockPos checkBlock) {
        final List<RenderPos> toRemove = new ArrayList<RenderPos>();
        if (checkBlock == null || this.renderMap.isEmpty()) {
            return;
        }
        for (final RenderPos pos : this.renderMap) {
            if (pos.pos.func_177958_n() == checkBlock.func_177958_n() && pos.pos.func_177956_o() == checkBlock.func_177956_o() && pos.pos.func_177952_p() == checkBlock.func_177952_p()) {
                toRemove.add(pos);
            }
        }
        this.renderMap.removeAll(toRemove);
    }
    
    static {
        AutoCrystal.INSTANCE = new AutoCrystal();
    }
    
    public enum Settings
    {
        AUTOCRYSTAL, 
        RENDER;
    }
    
    public enum SpeedFactor
    {
        TICK, 
        UPDATE;
    }
    
    public enum Priority
    {
        SELF, 
        ENEMY;
    }
    
    public enum RenderMode
    {
        NORMAL, 
        FADE, 
        GLIDE;
    }
    
    public enum Enum
    {
        FAST, 
        MEDIUM, 
        SLOW;
    }
    
    class RenderPos
    {
        Double damage;
        double alpha;
        BlockPos pos;
        
        public RenderPos(final BlockPos pos, final Double damage) {
            this.pos = pos;
            this.damage = damage;
        }
    }
}
