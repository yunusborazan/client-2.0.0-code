// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import net.minecraft.util.math.BlockPos;
import client.util.BlockUtil;
import net.minecraft.util.EnumHand;
import net.minecraft.init.Blocks;
import net.minecraft.entity.Entity;
import client.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.player.EntityPlayer;
import client.util.EntityUtil;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class AntiCity extends Module
{
    public Setting<Boolean> packet;
    public Setting<Boolean> rotate;
    
    public AntiCity() {
        super("AntiCity", "", Category.COMBAT);
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
    }
    
    @Override
    public void onUpdate() {
        final BlockPos pos = EntityUtil.getPlayerPos((EntityPlayer)AntiCity.mc.field_71439_g);
        final int preSlot = AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c;
        final int whileSlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        if (EntityUtil.isSafe((Entity)AntiCity.mc.field_71439_g)) {
            if (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150350_a && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || AntiCity.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
                BlockUtil.placeBlock(pos.func_177978_c().func_177978_c(), EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), false);
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
            }
            if (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f()).func_177230_c() == Blocks.field_150350_a && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || AntiCity.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
                BlockUtil.placeBlock(pos.func_177974_f().func_177974_f(), EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), false);
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
            }
            if (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d()).func_177230_c() == Blocks.field_150350_a && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || AntiCity.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
                BlockUtil.placeBlock(pos.func_177968_d().func_177968_d(), EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), false);
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
            }
            if (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150350_a && AntiCity.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (AntiCity.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || AntiCity.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
                BlockUtil.placeBlock(pos.func_177976_e().func_177976_e(), EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), false);
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
                AutoTrap.mc.field_71442_b.func_78765_e();
            }
        }
    }
}
