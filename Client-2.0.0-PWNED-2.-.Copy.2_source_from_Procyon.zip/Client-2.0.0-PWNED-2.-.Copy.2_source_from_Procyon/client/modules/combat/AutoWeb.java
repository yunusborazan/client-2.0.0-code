// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import client.util.RenderUtil;
import java.awt.Color;
import client.util.ColorUtil;
import client.modules.client.ClickGui;
import client.events.Render3DEvent;
import net.minecraft.util.EnumHand;
import client.util.MathUtil;
import client.Client;
import client.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.util.InventoryUtil;
import net.minecraft.block.BlockWeb;
import java.util.Iterator;
import client.util.BlockUtil;
import java.util.Comparator;
import java.util.ArrayList;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import net.minecraft.entity.Entity;
import client.util.EntityUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import client.util.Timer;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class AutoWeb extends Module
{
    public static boolean isPlacing;
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerPlace;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> offhand;
    private final Setting<Boolean> disable;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> raytrace;
    private final Setting<Boolean> lowerbody;
    private final Setting<Boolean> upperBody;
    private final Setting<Boolean> render;
    public Setting<Boolean> box;
    private final Setting<Integer> red;
    private final Setting<Integer> green;
    private final Setting<Integer> blue;
    public Setting<Boolean> Rainbow;
    private final Setting<Integer> alpha;
    private final Setting<Integer> boxAlpha;
    public Setting<Boolean> outline;
    private final Setting<Integer> cRed;
    private final Setting<Integer> cGreen;
    private final Setting<Integer> cBlue;
    public Setting<Boolean> cRainbow;
    private final Setting<Integer> cAlpha;
    private final Setting<Float> lineWidth;
    private final Timer timer;
    public EntityPlayer target;
    private boolean didPlace;
    private boolean switchedItem;
    private boolean isSneaking;
    private int lastHotbarSlot;
    private int placements;
    private BlockPos startPos;
    private BlockPos renderPos;
    
    public AutoWeb() {
        super("AutoWeb", "Traps other players in webs", Category.COMBAT);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)10, (T)0, (T)250));
        this.blocksPerPlace = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)8, (T)1, (T)30));
        this.packet = (Setting<Boolean>)this.register(new Setting("PacketPlace", (T)false));
        this.offhand = (Setting<Boolean>)this.register(new Setting("Offhand", (T)false));
        this.disable = (Setting<Boolean>)this.register(new Setting("AutoDisable", (T)false));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.raytrace = (Setting<Boolean>)this.register(new Setting("Raytrace", (T)false));
        this.lowerbody = (Setting<Boolean>)this.register(new Setting("Feet", (T)true));
        this.upperBody = (Setting<Boolean>)this.register(new Setting("Face", (T)false));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (T)false));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)false, v -> this.render.getCurrentState()));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)0, (T)0, (T)255, v -> this.box.getCurrentState()));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255, v -> this.box.getCurrentState()));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)0, (T)0, (T)255, v -> this.box.getCurrentState()));
        this.Rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)false, v -> this.box.getCurrentState()));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255, v -> this.box.getCurrentState()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)125, (T)0, (T)255, v -> this.box.getCurrentState()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)false, v -> this.render.getCurrentState()));
        this.cRed = (Setting<Integer>)this.register(new Setting("OL-Red", (T)0, (T)0, (T)255, v -> this.outline.getCurrentState()));
        this.cGreen = (Setting<Integer>)this.register(new Setting("OL-Green", (T)0, (T)0, (T)255, v -> this.outline.getCurrentState()));
        this.cBlue = (Setting<Integer>)this.register(new Setting("OL-Blue", (T)255, (T)0, (T)255, v -> this.outline.getCurrentState()));
        this.cRainbow = (Setting<Boolean>)this.register(new Setting("OL-Rainbow", (T)false, v -> this.outline.getCurrentState()));
        this.cAlpha = (Setting<Integer>)this.register(new Setting("OL-Alpha", (T)255, (T)0, (T)255, v -> this.outline.getCurrentState()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (T)1.0f, (T)0.1f, (T)5.0f, v -> this.outline.getCurrentState()));
        this.timer = new Timer();
        this.didPlace = false;
        this.placements = 0;
        this.startPos = null;
        this.renderPos = null;
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            return;
        }
        this.startPos = EntityUtil.getRoundedBlockPos((Entity)AutoWeb.mc.field_71439_g);
        this.lastHotbarSlot = AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c;
    }
    
    @Override
    public void onTick() {
        this.doTrap();
    }
    
    @Override
    public String getDisplayInfo() {
        if (this.target != null) {
            return this.target.func_70005_c_();
        }
        return null;
    }
    
    @Override
    public void onDisable() {
        AutoWeb.isPlacing = false;
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        this.switchItem(true);
    }
    
    private void doTrap() {
        if (this.check()) {
            return;
        }
        this.doWebTrap();
        if (this.didPlace) {
            this.timer.reset();
        }
    }
    
    private void doWebTrap() {
        final List<Vec3d> placeTargets = this.getPlacements();
        this.placeList(placeTargets);
    }
    
    private List<Vec3d> getPlacements() {
        final ArrayList<Vec3d> list = new ArrayList<Vec3d>();
        final Vec3d baseVec = this.target.func_174791_d();
        if (this.lowerbody.getCurrentState()) {
            list.add(baseVec);
        }
        if (this.upperBody.getCurrentState()) {
            list.add(baseVec.func_72441_c(0.0, 1.0, 0.0));
        }
        return list;
    }
    
    private void placeList(final List<Vec3d> list) {
        list.sort((vec3d, vec3d2) -> Double.compare(AutoWeb.mc.field_71439_g.func_70092_e(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c), AutoWeb.mc.field_71439_g.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c)));
        list.sort(Comparator.comparingDouble(vec3d -> vec3d.field_72448_b));
        for (final Vec3d vec3d3 : list) {
            final BlockPos position = new BlockPos(vec3d3);
            this.renderPos = position;
            final int placeability = BlockUtil.isPositionPlaceable(position, this.raytrace.getCurrentState());
            if (placeability != 3 && placeability != 1) {
                continue;
            }
            this.placeBlock(position);
        }
    }
    
    private boolean check() {
        AutoWeb.isPlacing = false;
        this.didPlace = false;
        this.placements = 0;
        final int obbySlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
        if (this.isOff()) {
            return true;
        }
        if (this.disable.getCurrentState() && !this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)AutoWeb.mc.field_71439_g))) {
            this.disable();
            return true;
        }
        if (obbySlot == -1) {
            Command.sendMessage("" + this.getDisplayName() + " " + ChatFormatting.RED + "No Webs in hotbar disabling...");
            this.toggle();
            return true;
        }
        if (AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c != obbySlot) {
            this.lastHotbarSlot = AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c;
        }
        this.switchItem(true);
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        this.target = this.getTarget(10.0);
        return this.target == null || !this.timer.passedMs(this.delay.getCurrentState());
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = Math.pow(range, 2.0) + 1.0;
        for (final EntityPlayer player : AutoWeb.mc.field_71441_e.field_73010_i) {
            if (!EntityUtil.isntValid((Entity)player, range) && !player.field_70134_J) {
                if (Client.speedManager.getPlayerSpeed(player) > 30.0) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = AutoWeb.mc.field_71439_g.func_70068_e((Entity)player);
                }
                else {
                    if (AutoWeb.mc.field_71439_g.func_70068_e((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = AutoWeb.mc.field_71439_g.func_70068_e((Entity)player);
                }
            }
        }
        return target;
    }
    
    private void placeBlock(final BlockPos pos) {
        if (this.placements < this.blocksPerPlace.getCurrentState() && AutoWeb.mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(6.0) && this.switchItem(false)) {
            AutoWeb.isPlacing = true;
            final int originalSlot = AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c;
            final int webSlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
            if (webSlot == -1) {
                this.toggle();
            }
            AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c = ((webSlot == -1) ? webSlot : webSlot);
            AutoWeb.mc.field_71442_b.func_78765_e();
            this.isSneaking = BlockUtil.placeBlock(pos, ((boolean)this.offhand.getCurrentState()) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), this.isSneaking);
            AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
            AutoWeb.mc.field_71442_b.func_78765_e();
            this.didPlace = true;
            ++this.placements;
        }
    }
    
    private boolean switchItem(final boolean back) {
        final boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, InventoryUtil.Switch.SILENT, BlockWeb.class);
        this.switchedItem = value[0];
        return value[1];
    }
    
    @Override
    public void onLogout() {
        this.disable();
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.render.getCurrentState()) {
            RenderUtil.drawBoxESP(this.renderPos, ((boolean)this.Rainbow.getCurrentState()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getCurrentState()) : new Color(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState()), this.outline.getCurrentState(), ((boolean)this.cRainbow.getCurrentState()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getCurrentState()) : new Color(this.cRed.getCurrentState(), this.cGreen.getCurrentState(), this.cBlue.getCurrentState(), this.cAlpha.getCurrentState()), this.lineWidth.getCurrentState(), this.outline.getCurrentState(), this.box.getCurrentState(), this.boxAlpha.getCurrentState(), true);
        }
    }
    
    static {
        AutoWeb.isPlacing = false;
    }
}
