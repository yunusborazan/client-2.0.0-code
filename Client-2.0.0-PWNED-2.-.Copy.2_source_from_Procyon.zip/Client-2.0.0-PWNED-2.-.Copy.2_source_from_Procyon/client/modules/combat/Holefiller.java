// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.combat;

import java.util.Arrays;
import client.util.RotationUtil;
import client.util.RenderUtil;
import java.awt.Color;
import client.events.Render3DEvent;
import net.minecraft.util.math.Vec3i;
import java.util.ArrayList;
import client.util.BlockUtil;
import net.minecraft.util.EnumHand;
import com.google.common.eventbus.Subscribe;
import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import client.util.InventoryUtil;
import net.minecraft.item.Item;
import net.minecraft.init.Blocks;
import java.util.function.ToDoubleFunction;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import client.util.EntityUtil;
import net.minecraft.block.Block;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Holefiller extends Module
{
    public Setting<Integer> bpt;
    public Setting<Float> range;
    public Setting<Float> distance;
    public Setting<Boolean> rotate;
    public Setting<Boolean> packet;
    public Setting<Boolean> render;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Integer> boxAlpha;
    public Setting<Integer> lineWidth;
    public Setting<Boolean> fov;
    public Setting<Boolean> box;
    public Setting<Boolean> outline;
    public Setting<Integer> cRed;
    public Setting<Integer> cGreen;
    public Setting<Integer> cBlue;
    public Setting<Integer> cAlpha;
    private int placeAmount;
    private int blockSlot;
    private boolean isSneaking;
    private static final BlockPos[] surroundOffset;
    private static final List<Block> unSafeBlocks;
    
    public Holefiller() {
        super("HoleFiller", "Fills holes near enemies.", Category.COMBAT);
        this.bpt = (Setting<Integer>)this.register(new Setting("Blocks Per Tick", (T)10, (T)1, (T)20));
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)5.0f, (T)1.0f, (T)6.0f));
        this.distance = (Setting<Float>)this.register(new Setting("Smart range", (T)2.0f, (T)1.0f, (T)7.0f));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)true));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (T)true));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)120, (T)0, (T)255));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)120, (T)0, (T)255));
        this.lineWidth = (Setting<Integer>)this.register(new Setting("LineWidth", (T)1, (T)1, (T)5));
        this.fov = (Setting<Boolean>)this.register(new Setting("inFov", (T)true));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)true));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true));
        this.cRed = (Setting<Integer>)this.register(new Setting("OutlineRed", (T)255, (T)0, (T)255));
        this.cGreen = (Setting<Integer>)this.register(new Setting("OutlineGreen", (T)255, (T)0, (T)255));
        this.cBlue = (Setting<Integer>)this.register(new Setting("OutlineBlue", (T)255, (T)0, (T)255));
        this.cAlpha = (Setting<Integer>)this.register(new Setting("OutlineAlpha", (T)255, (T)0, (T)255));
        this.placeAmount = 0;
        this.blockSlot = -1;
    }
    
    @Subscribe
    @Override
    public void onUpdate() {
        if (this.check()) {
            final EntityPlayer currentTarget = EntityUtil.getTarget(10.0f);
            if (currentTarget == null) {
                return;
            }
            if (EntityUtil.isInHole((Entity)currentTarget)) {
                return;
            }
            final List<BlockPos> holes = this.calcHoles();
            holes.sort(Comparator.comparingDouble((ToDoubleFunction<? super BlockPos>)currentTarget::func_174818_b));
            if (holes.size() == 0) {
                return;
            }
            final int lastSlot = Holefiller.mc.field_71439_g.field_71071_by.field_70461_c;
            this.blockSlot = InventoryUtil.getItemFromHotbar(Item.func_150898_a(Blocks.field_150343_Z));
            if (this.blockSlot == -1) {
                return;
            }
            BlockPos hole = null;
            for (final BlockPos pos : holes) {
                if (currentTarget.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()) >= this.distance.getCurrentState()) {
                    continue;
                }
                hole = pos;
            }
            if (hole != null) {
                Objects.requireNonNull(Holefiller.mc.func_147114_u()).func_147297_a((Packet)new CPacketHeldItemChange(this.blockSlot));
                this.placeBlock(hole);
                Holefiller.mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(lastSlot));
            }
        }
    }
    
    private void placeBlock(final BlockPos pos) {
        if (this.bpt.getCurrentState() > this.placeAmount) {
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getCurrentState(), this.packet.getCurrentState(), this.isSneaking);
            ++this.placeAmount;
        }
    }
    
    private boolean check() {
        if (Holefiller.mc.field_71439_g == null) {
            return false;
        }
        this.placeAmount = 0;
        this.blockSlot = InventoryUtil.getItemFromHotbar(Item.func_150898_a(Blocks.field_150343_Z));
        return true;
    }
    
    public List<BlockPos> calcHoles() {
        final ArrayList<BlockPos> safeSpots = new ArrayList<BlockPos>();
        final List<BlockPos> positions = BlockUtil.getCock(this.range.getCurrentState(), false);
        for (final BlockPos pos : positions) {
            if (BlockUtil.isPositionPlaceable(pos, true) != 1 && Holefiller.mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a) && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a) && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a)) {
                boolean isSafe = true;
                for (final BlockPos offset : Holefiller.surroundOffset) {
                    final Block block = Holefiller.mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)offset)).func_177230_c();
                    if (block != Blocks.field_150357_h && block != Blocks.field_150343_Z) {
                        isSafe = false;
                    }
                }
                if (!isSafe) {
                    continue;
                }
                safeSpots.add(pos);
            }
        }
        return safeSpots;
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        assert Holefiller.mc.field_175622_Z != null;
        final Vec3i playerPos = new Vec3i(Holefiller.mc.field_175622_Z.field_70165_t, Holefiller.mc.field_175622_Z.field_70163_u, Holefiller.mc.field_175622_Z.field_70161_v);
        for (int x = playerPos.func_177958_n() - 5; x < playerPos.func_177958_n() + this.range.getCurrentState(); ++x) {
            for (int z = playerPos.func_177952_p() - 5; z < playerPos.func_177952_p() + this.range.getCurrentState(); ++z) {
                for (int y = playerPos.func_177956_o() + 5; y > playerPos.func_177956_o() - 5; --y) {
                    final BlockPos pos = new BlockPos(x, y, z);
                    if (Holefiller.mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a) && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a) && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a)) {
                        if (!pos.equals((Object)new BlockPos(Holefiller.mc.field_71439_g.field_70165_t, Holefiller.mc.field_71439_g.field_70163_u, Holefiller.mc.field_71439_g.field_70161_v)) || isPosInFov(pos) || !this.fov.getCurrentState()) {
                            if (Holefiller.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && Holefiller.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h) {
                                RenderUtil.drawBoxESP(pos, new Color(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState()), this.outline.getCurrentState(), new Color(this.cRed.getCurrentState(), this.cGreen.getCurrentState(), this.cBlue.getCurrentState(), this.cAlpha.getCurrentState()), this.lineWidth.getCurrentState(), this.outline.getCurrentState(), this.box.getCurrentState(), this.boxAlpha.getCurrentState(), true);
                            }
                            else if (!isBlockUnSafe(Holefiller.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c()) && !isBlockUnSafe(Holefiller.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c()) && !isBlockUnSafe(Holefiller.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c()) && !isBlockUnSafe(Holefiller.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c())) {
                                if (!isBlockUnSafe(Holefiller.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c())) {
                                    RenderUtil.drawBoxESP(pos, new Color(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState()), this.outline.getCurrentState(), new Color(this.cRed.getCurrentState(), this.cGreen.getCurrentState(), this.cBlue.getCurrentState(), this.cAlpha.getCurrentState()), this.lineWidth.getCurrentState(), this.outline.getCurrentState(), this.box.getCurrentState(), this.boxAlpha.getCurrentState(), true);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private static boolean isBlockUnSafe(final Block block) {
        return !Holefiller.unSafeBlocks.contains(block);
    }
    
    private static Boolean isPosInFov(final BlockPos pos) {
        final int dirnumber = RotationUtil.getDirection4D();
        if (dirnumber == 0 && pos.func_177952_p() - BlockUtil.mc.field_71439_g.func_174791_d().field_72449_c < 0.0) {
            return false;
        }
        if (dirnumber == 1 && pos.func_177958_n() - BlockUtil.mc.field_71439_g.func_174791_d().field_72450_a > 0.0) {
            return false;
        }
        if (dirnumber == 2 && pos.func_177952_p() - BlockUtil.mc.field_71439_g.func_174791_d().field_72449_c > 0.0) {
            return false;
        }
        return dirnumber != 3 || pos.func_177958_n() - BlockUtil.mc.field_71439_g.func_174791_d().field_72450_a >= 0.0;
    }
    
    static {
        surroundOffset = BlockUtil.toBlockPos(BlockUtil.getOffsets(0, true));
        unSafeBlocks = Arrays.asList(Blocks.field_150343_Z, Blocks.field_150357_h, Blocks.field_150477_bB, Blocks.field_150467_bQ);
    }
}
