// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import client.modules.Module;

public class PrestigeChams extends Module
{
    private static PrestigeChams INSTANCE;
    
    public PrestigeChams() {
        super("PrestigeChams", "Makes everyone look like zPrestige", Category.VISUAL);
        this.setInstance();
    }
    
    public static PrestigeChams getInstance() {
        if (PrestigeChams.INSTANCE == null) {
            PrestigeChams.INSTANCE = new PrestigeChams();
        }
        return PrestigeChams.INSTANCE;
    }
    
    private void setInstance() {
        PrestigeChams.INSTANCE = this;
    }
    
    static {
        PrestigeChams.INSTANCE = new PrestigeChams();
    }
}
