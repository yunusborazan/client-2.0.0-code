// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import client.events.RenderEntityModelEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import client.events.PacketEvent;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import client.util.ColorUtil;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.item.EntityEnderCrystal;
import java.util.Map;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class CrystalChanger extends Module
{
    private static CrystalChanger INSTANCE;
    public Setting<Boolean> chams;
    public Setting<Boolean> glint;
    public Setting<Boolean> wireframe;
    public Setting<Boolean> throughwalls;
    public Setting<Boolean> XQZ;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Integer> w_red;
    public Setting<Integer> w_green;
    public Setting<Integer> w_blue;
    public Setting<Integer> w_alpha;
    public Setting<Integer> h_red;
    public Setting<Integer> h_green;
    public Setting<Integer> h_blue;
    public Setting<Integer> h_alpha;
    public Setting<Double> width;
    public Setting<Double> scale;
    public Map<EntityEnderCrystal, Float> scaleMap;
    private final int color;
    private final int wireColor;
    private final int hiddenColor;
    
    public CrystalChanger() {
        super("CrystalChanger", "Modifies looks of end crystals.", Category.VISUAL);
        this.chams = (Setting<Boolean>)this.register(new Setting("Chams", (T)true));
        this.glint = (Setting<Boolean>)this.register(new Setting("Glint", (T)true));
        this.wireframe = (Setting<Boolean>)this.register(new Setting("Wireframe", (T)true));
        this.throughwalls = (Setting<Boolean>)this.register(new Setting("Walls", (T)true));
        this.XQZ = (Setting<Boolean>)this.register(new Setting("Depth", (T)true));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255, v -> this.chams.getCurrentState()));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255, v -> this.chams.getCurrentState()));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255, v -> this.chams.getCurrentState()));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)150, (T)0, (T)255, v -> this.chams.getCurrentState()));
        this.w_red = (Setting<Integer>)this.register(new Setting("WireframeRed", (T)255, (T)0, (T)255, v -> this.wireframe.getCurrentState()));
        this.w_green = (Setting<Integer>)this.register(new Setting("WireframeGreen", (T)255, (T)0, (T)255, v -> this.wireframe.getCurrentState()));
        this.w_blue = (Setting<Integer>)this.register(new Setting("WireframeBlue", (T)255, (T)0, (T)255, v -> this.wireframe.getCurrentState()));
        this.w_alpha = (Setting<Integer>)this.register(new Setting("WireframeAlpha", (T)150, (T)0, (T)255, v -> this.wireframe.getCurrentState()));
        this.h_red = (Setting<Integer>)this.register(new Setting("WallsRed", (T)255, (T)0, (T)255, v -> this.throughwalls.getCurrentState()));
        this.h_green = (Setting<Integer>)this.register(new Setting("WallsGreen", (T)255, (T)0, (T)255, v -> this.throughwalls.getCurrentState()));
        this.h_blue = (Setting<Integer>)this.register(new Setting("WallsBlue", (T)255, (T)0, (T)255, v -> this.throughwalls.getCurrentState()));
        this.h_alpha = (Setting<Integer>)this.register(new Setting("WallsAlpha", (T)150, (T)0, (T)255, v -> this.throughwalls.getCurrentState()));
        this.width = (Setting<Double>)this.register(new Setting("Width", (T)3.0, (T)0.1, (T)5.0));
        this.scale = (Setting<Double>)this.register(new Setting("Scale", (T)1.0, (T)0.1, (T)3.0));
        this.scaleMap = new ConcurrentHashMap<EntityEnderCrystal, Float>();
        this.color = ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState());
        this.wireColor = ColorUtil.toRGBA(this.w_red.getCurrentState(), this.w_green.getCurrentState(), this.w_blue.getCurrentState(), this.w_alpha.getCurrentState());
        this.hiddenColor = ColorUtil.toRGBA(this.h_red.getCurrentState(), this.h_green.getCurrentState(), this.h_blue.getCurrentState(), this.h_alpha.getCurrentState());
        this.setInstance();
    }
    
    private void setInstance() {
        CrystalChanger.INSTANCE = this;
    }
    
    public static CrystalChanger getInstance() {
        if (CrystalChanger.INSTANCE == null) {
            CrystalChanger.INSTANCE = new CrystalChanger();
        }
        return CrystalChanger.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        for (final Entity crystal : CrystalChanger.mc.field_71441_e.field_72996_f) {
            if (crystal instanceof EntityEnderCrystal) {
                if (!this.scaleMap.containsKey(crystal)) {
                    this.scaleMap.put((EntityEnderCrystal)crystal, 3.125E-4f);
                }
                else {
                    try {
                        this.scaleMap.put((EntityEnderCrystal)crystal, this.scaleMap.get(crystal) + 3.125E-4f);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (this.scaleMap.get(crystal) < 0.0625 * this.scale.getCurrentState()) {
                    continue;
                }
                this.scaleMap.remove(crystal);
            }
        }
    }
    
    @SubscribeEvent
    public void onPacket(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketDestroyEntities) {
            final SPacketDestroyEntities packet = event.getPacket();
            for (final int id : packet.func_149098_c()) {
                try {
                    final Entity entity = CrystalChanger.mc.field_71441_e.func_73045_a(id);
                    if (entity instanceof EntityEnderCrystal) {
                        this.scaleMap.remove(entity);
                    }
                }
                catch (Exception ex) {}
            }
        }
    }
    
    public void onRenderModel(final RenderEntityModelEvent event) {
        if (event.getStage() != 0 || !(event.entity instanceof EntityEnderCrystal) || !this.wireframe.getCurrentState()) {
            return;
        }
        CrystalChanger.mc.field_71474_y.field_74347_j = false;
        CrystalChanger.mc.field_71474_y.field_74333_Y = 10000.0f;
        GL11.glPushMatrix();
        GL11.glPushAttrib(1048575);
        GL11.glPolygonMode(1032, 6913);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        if (this.throughwalls.getCurrentState()) {
            GL11.glDisable(2929);
        }
        GL11.glEnable(2848);
        GL11.glEnable(3042);
        GlStateManager.func_179112_b(770, 771);
        GlStateManager.func_179131_c(this.red.getCurrentState() / 255.0f, this.green.getCurrentState() / 255.0f, this.blue.getCurrentState() / 255.0f, this.alpha.getCurrentState() / 255.0f);
        GlStateManager.func_187441_d(this.width.getCurrentState().floatValue());
        event.modelBase.func_78088_a(event.entity, event.limbSwing, event.limbSwingAmount, event.age, event.headYaw, event.headPitch, event.scale);
        GL11.glPopAttrib();
        GL11.glPopMatrix();
    }
}
