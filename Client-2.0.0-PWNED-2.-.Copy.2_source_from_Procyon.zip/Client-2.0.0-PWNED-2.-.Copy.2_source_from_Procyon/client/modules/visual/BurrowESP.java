// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import java.util.Iterator;
import net.minecraft.entity.Entity;
import client.util.EntityUtil;
import client.Client;
import java.awt.Color;
import net.minecraft.init.Blocks;
import client.util.RenderUtil;
import client.events.Render3DEvent;
import java.util.HashMap;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class BurrowESP extends Module
{
    private final Setting<Boolean> name;
    private final Setting<Settings> setting;
    private final Setting<Boolean> e_box;
    private final Setting<Integer> e_boxRed;
    private final Setting<Integer> e_boxGreen;
    private final Setting<Integer> e_boxBlue;
    private final Setting<Integer> e_boxAlpha;
    private final Setting<Boolean> e_outline;
    private final Setting<Float> e_outlineWidth;
    private final Setting<Boolean> e_cOutline;
    private final Setting<Integer> e_outlineRed;
    private final Setting<Integer> e_outlineGreen;
    private final Setting<Integer> e_outlineBlue;
    private final Setting<Integer> e_outlineAlpha;
    private final Setting<Boolean> o_box;
    private final Setting<Integer> o_boxRed;
    private final Setting<Integer> o_boxGreen;
    private final Setting<Integer> o_boxBlue;
    private final Setting<Integer> o_boxAlpha;
    private final Setting<Boolean> o_outline;
    private final Setting<Float> o_outlineWidth;
    private final Setting<Boolean> o_cOutline;
    private final Setting<Integer> o_outlineRed;
    private final Setting<Integer> o_outlineGreen;
    private final Setting<Integer> o_outlineBlue;
    private final Setting<Integer> o_outlineAlpha;
    private final Map<EntityPlayer, BlockPos> burrowedPlayers;
    
    public BurrowESP() {
        super("BurrowESP", "Shows info about target", Category.VISUAL);
        this.name = (Setting<Boolean>)this.register(new Setting("Name", (T)true));
        this.setting = (Setting<Settings>)this.register(new Setting("Setting", (T)Settings.ECHEST));
        this.e_box = new Setting<Boolean>("Box", true);
        this.e_boxRed = (Setting<Integer>)this.register(new Setting("BoxRed", (T)255, (T)0, (T)255, v -> this.e_box.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_boxGreen = (Setting<Integer>)this.register(new Setting("BoxGreen", (T)255, (T)0, (T)255, v -> this.e_box.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_boxBlue = (Setting<Integer>)this.register(new Setting("BoxBlue", (T)255, (T)0, (T)255, v -> this.e_box.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)127, (T)0, (T)255, v -> this.e_box.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, v -> this.setting.getCurrentState() == Settings.ECHEST));
        this.e_outlineWidth = (Setting<Float>)this.register(new Setting("OutlineWidth", (T)1.0f, (T)0.0f, (T)5.0f, v -> this.setting.getCurrentState() == Settings.ECHEST));
        this.e_cOutline = (Setting<Boolean>)this.register(new Setting("CustomOutline", (T)true, v -> this.setting.getCurrentState() == Settings.ECHEST));
        this.e_outlineRed = (Setting<Integer>)this.register(new Setting("OutlineRed", (T)255, (T)0, (T)255, v -> this.e_outline.getCurrentState() && this.e_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_outlineGreen = (Setting<Integer>)this.register(new Setting("OutlineGreen", (T)255, (T)0, (T)255, v -> this.e_outline.getCurrentState() && this.e_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_outlineBlue = (Setting<Integer>)this.register(new Setting("OutlineBlue", (T)255, (T)0, (T)255, v -> this.e_outline.getCurrentState() && this.e_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.e_outlineAlpha = (Setting<Integer>)this.register(new Setting("OutlineAlpha", (T)255, (T)0, (T)255, v -> this.e_outline.getCurrentState() && this.e_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.ECHEST));
        this.o_box = new Setting<Boolean>("Box", true);
        this.o_boxRed = (Setting<Integer>)this.register(new Setting("BoxRed", (T)255, (T)0, (T)255, v -> this.o_box.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_boxGreen = (Setting<Integer>)this.register(new Setting("BoxGreen", (T)255, (T)0, (T)255, v -> this.o_box.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_boxBlue = (Setting<Integer>)this.register(new Setting("BoxBlue", (T)255, (T)0, (T)255, v -> this.o_box.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)127, (T)0, (T)255, v -> this.o_box.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, v -> this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_outlineWidth = (Setting<Float>)this.register(new Setting("OutlineWidth", (T)1.0f, (T)0.0f, (T)5.0f, v -> this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_cOutline = (Setting<Boolean>)this.register(new Setting("CustomOutline", (T)true, v -> this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_outlineRed = (Setting<Integer>)this.register(new Setting("OutlineRed", (T)255, (T)0, (T)255, v -> this.o_outline.getCurrentState() && this.o_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_outlineGreen = (Setting<Integer>)this.register(new Setting("OutlineGreen", (T)255, (T)0, (T)255, v -> this.o_outline.getCurrentState() && this.o_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_outlineBlue = (Setting<Integer>)this.register(new Setting("OutlineBlue", (T)255, (T)0, (T)255, v -> this.o_outline.getCurrentState() && this.o_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.o_outlineAlpha = (Setting<Integer>)this.register(new Setting("OutlineAlpha", (T)255, (T)0, (T)255, v -> this.o_outline.getCurrentState() && this.o_cOutline.getCurrentState() && this.setting.getCurrentState() == Settings.OBSIDIAN));
        this.burrowedPlayers = new HashMap<EntityPlayer, BlockPos>();
    }
    
    @Override
    public void onEnable() {
        this.burrowedPlayers.clear();
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        this.burrowedPlayers.clear();
        this.getPlayers();
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (!this.burrowedPlayers.isEmpty()) {
            this.burrowedPlayers.forEach((key, value) -> {
                this.renderBurrowedBlock(value);
                if (this.name.getCurrentState()) {
                    RenderUtil.drawText(value, key.func_146103_bH().getName());
                }
            });
        }
    }
    
    private void renderBurrowedBlock(final BlockPos pos) {
        if (BurrowESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150477_bB) {
            RenderUtil.drawBoxESP(pos, new Color(this.e_boxRed.getCurrentState(), this.e_boxGreen.getCurrentState(), this.e_boxBlue.getCurrentState(), this.e_boxAlpha.getCurrentState()), true, new Color(this.e_outlineRed.getCurrentState(), this.e_outlineGreen.getCurrentState(), this.e_outlineBlue.getCurrentState(), this.e_outlineAlpha.getCurrentState()), this.e_outlineWidth.getCurrentState(), this.e_outline.getCurrentState(), this.e_box.getCurrentState(), this.e_boxAlpha.getCurrentState(), true);
        }
        if (BurrowESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150343_Z) {
            RenderUtil.drawBoxESP(pos, new Color(this.o_boxRed.getCurrentState(), this.o_boxGreen.getCurrentState(), this.o_boxBlue.getCurrentState(), this.o_boxAlpha.getCurrentState()), true, new Color(this.o_outlineRed.getCurrentState(), this.o_outlineGreen.getCurrentState(), this.o_outlineBlue.getCurrentState(), this.o_outlineAlpha.getCurrentState()), this.o_outlineWidth.getCurrentState(), this.o_outline.getCurrentState(), this.o_box.getCurrentState(), this.o_boxAlpha.getCurrentState(), true);
        }
    }
    
    private void getPlayers() {
        for (final EntityPlayer player : BurrowESP.mc.field_71441_e.field_73010_i) {
            if (player != BurrowESP.mc.field_71439_g && !Client.friendManager.isFriend(player.func_70005_c_())) {
                if (!EntityUtil.isLiving((Entity)player)) {
                    continue;
                }
                if (!this.isBurrowed(player)) {
                    continue;
                }
                this.burrowedPlayers.put(player, new BlockPos(player.field_70165_t, player.field_70163_u, player.field_70161_v));
            }
        }
    }
    
    private boolean isBurrowed(final EntityPlayer player) {
        final BlockPos pos = new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u + 0.2), Math.floor(player.field_70161_v));
        return BurrowESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150477_bB || BurrowESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150343_Z;
    }
    
    public enum Settings
    {
        OBSIDIAN, 
        ECHEST;
    }
}
