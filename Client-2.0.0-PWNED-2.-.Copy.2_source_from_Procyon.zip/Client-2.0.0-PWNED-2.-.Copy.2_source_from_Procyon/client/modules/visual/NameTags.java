// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import client.util.PlayerUtil;
import client.Client;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemTool;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.GlStateManager;
import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import client.util.EntityUtil;
import java.util.Iterator;
import client.util.RenderUtil;
import net.minecraft.entity.Entity;
import client.util.RotationUtil;
import net.minecraft.entity.player.EntityPlayer;
import client.modules.Feature;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class NameTags extends Module
{
    public static NameTags INSTANCE;
    public Setting<Boolean> healthSetting;
    public Setting<Boolean> armor;
    public Setting<Boolean> ping;
    public Setting<Double> size;
    
    public NameTags() {
        super("NameTags", "", Category.VISUAL);
        this.healthSetting = (Setting<Boolean>)this.register(new Setting("Health", (T)true));
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)true));
        this.ping = (Setting<Boolean>)this.register(new Setting("Ping", (T)true));
        this.size = (Setting<Double>)this.register(new Setting("Size", (T)0.3, (T)0.1, (T)20.0));
        this.setInstance();
    }
    
    private void setInstance() {
        NameTags.INSTANCE = this;
    }
    
    public static NameTags getInstance() {
        if (NameTags.INSTANCE == null) {
            NameTags.INSTANCE = new NameTags();
        }
        return NameTags.INSTANCE;
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (!Feature.fullNullCheck()) {
            for (final EntityPlayer player : NameTags.mc.field_71441_e.field_73010_i) {
                if (player != null && !player.equals((Object)NameTags.mc.field_71439_g) && player.func_70089_S()) {
                    if (player.func_82150_aj() && !RotationUtil.isInFov((Entity)player)) {
                        continue;
                    }
                    final double x = RenderUtil.interpolate(player.field_70142_S, player.field_70165_t, event.getPartialTicks()) - NameTags.mc.func_175598_ae().field_78725_b;
                    final double y = RenderUtil.interpolate(player.field_70137_T, player.field_70163_u, event.getPartialTicks()) - NameTags.mc.func_175598_ae().field_78726_c;
                    final double z = RenderUtil.interpolate(player.field_70136_U, player.field_70161_v, event.getPartialTicks()) - NameTags.mc.func_175598_ae().field_78723_d;
                    this.renderFinalResult(player, x, y, z, event.getPartialTicks());
                }
            }
        }
    }
    
    private void renderFinalResult(final EntityPlayer player, final double x, final double y, final double z, final float delta) {
        if (fullNullCheck()) {
            return;
        }
        if (player.func_70005_c_() == "FakePlayer") {
            return;
        }
        final float health = (float)Math.ceil(EntityUtil.getHealth((Entity)player));
        final String color = (health > 18.0f) ? "§a" : ((health > 16.0f) ? "§2" : ((health > 12.0f) ? "§e" : ((health > 8.0f) ? "§6" : ((health > 5.0f) ? "§c" : "§4"))));
        double theY = y;
        theY += (player.func_70093_af() ? 0.5 : 0.7);
        final Entity camera = NameTags.mc.func_175606_aa();
        assert camera != null;
        final double originalPositionX = camera.field_70165_t;
        final double originalPositionY = camera.field_70163_u;
        final double originalPositionZ = camera.field_70161_v;
        camera.field_70165_t = RenderUtil.interpolate(camera.field_70169_q, camera.field_70165_t, delta);
        camera.field_70163_u = RenderUtil.interpolate(camera.field_70167_r, camera.field_70163_u, delta);
        camera.field_70161_v = RenderUtil.interpolate(camera.field_70166_s, camera.field_70161_v, delta);
        final int width = this.renderer.getStringWidth(player.func_145748_c_().func_150254_d() + " " + (this.ping.getCurrentState() ? (Objects.requireNonNull(NameTags.mc.func_147114_u()).func_175102_a(player.func_110124_au()).func_178853_c() + "ms") : "") + " " + (this.healthSetting.getCurrentState() ? (color + health) : "")) / 2;
        final double distance = camera.func_70011_f(x + NameTags.mc.func_175598_ae().field_78730_l, y + NameTags.mc.func_175598_ae().field_78731_m, z + NameTags.mc.func_175598_ae().field_78728_n);
        double scale = (0.0018 + this.size.getCurrentState() * (distance * 0.2)) / 1000.0;
        if (distance <= 8.0) {
            scale = 0.0245;
        }
        GlStateManager.func_179094_E();
        RenderHelper.func_74519_b();
        GlStateManager.func_179088_q();
        GlStateManager.func_179136_a(1.0f, -1500000.0f);
        GlStateManager.func_179140_f();
        GlStateManager.func_179109_b((float)x, (float)theY + 1.4f, (float)z);
        GlStateManager.func_179114_b(-NameTags.mc.func_175598_ae().field_78735_i, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(NameTags.mc.func_175598_ae().field_78732_j, (NameTags.mc.field_71474_y.field_74320_O == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        GlStateManager.func_179139_a(-scale, -scale, scale);
        GlStateManager.func_179097_i();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        RenderUtil.drawRect((float)(-width - 2), (float)(-(NameTags.mc.field_71466_p.field_78288_b + 1)), width + 2.0f, 1.0f, 1426063360);
        GlStateManager.func_179141_d();
        final ItemStack renderMainHand = player.func_184614_ca().func_77946_l();
        if (renderMainHand.func_77962_s() && (renderMainHand.func_77973_b() instanceof ItemTool || renderMainHand.func_77973_b() instanceof ItemArmor)) {
            renderMainHand.field_77994_a = 1;
        }
        GlStateManager.func_179094_E();
        int xOffset = -8;
        for (final ItemStack stack : player.field_71071_by.field_70460_b) {
            if (stack == null) {
                continue;
            }
            xOffset -= 8;
        }
        xOffset -= 8;
        final ItemStack renderOffhand = player.func_184592_cb().func_77946_l();
        if (renderOffhand.func_77962_s() && (renderOffhand.func_77973_b() instanceof ItemTool || renderOffhand.func_77973_b() instanceof ItemArmor)) {
            renderOffhand.field_77994_a = 1;
        }
        this.renderItems(renderOffhand, xOffset, this.armor.getCurrentState());
        xOffset += 16;
        for (final ItemStack stack2 : player.field_71071_by.field_70460_b) {
            if (stack2 == null) {
                continue;
            }
            final ItemStack armourStack = stack2.func_77946_l();
            if (armourStack.func_77962_s() && (armourStack.func_77973_b() instanceof ItemTool || armourStack.func_77973_b() instanceof ItemArmor)) {
                armourStack.field_77994_a = 1;
            }
            this.renderItems(armourStack, xOffset, this.armor.getCurrentState());
            xOffset += 16;
        }
        this.renderItems(renderMainHand, xOffset, this.armor.getCurrentState());
        GlStateManager.func_179121_F();
        this.renderer.drawStringWithShadow(player.func_145748_c_().func_150254_d() + " " + (this.ping.getCurrentState() ? (Objects.requireNonNull(NameTags.mc.func_147114_u()).func_175102_a(player.func_110124_au()).func_178853_c() + "ms") : "") + " " + (this.healthSetting.getCurrentState() ? (color + health) : ""), (float)(-width), -8.0f, Client.friendManager.isFriend(player) ? -11157267 : -1);
        camera.field_70165_t = originalPositionX;
        camera.field_70163_u = originalPositionY;
        camera.field_70161_v = originalPositionZ;
        GlStateManager.func_179126_j();
        GlStateManager.func_179145_e();
        GlStateManager.func_179084_k();
        GlStateManager.func_179145_e();
        GlStateManager.func_179113_r();
        GlStateManager.func_179136_a(1.0f, 1500000.0f);
        GlStateManager.func_179121_F();
    }
    
    private void renderItems(final ItemStack stack, final int x, final boolean item) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179086_m(256);
        RenderHelper.func_74519_b();
        NameTags.mc.func_175599_af().field_77023_b = -150.0f;
        GlStateManager.func_179118_c();
        GlStateManager.func_179126_j();
        GlStateManager.func_179129_p();
        if (item) {
            NameTags.mc.func_175599_af().func_180450_b(stack, x, -26);
            NameTags.mc.func_175599_af().func_175030_a(NameTags.mc.field_71466_p, stack, x, -26);
        }
        NameTags.mc.func_175599_af().field_77023_b = 0.0f;
        RenderHelper.func_74518_a();
        GlStateManager.func_179089_o();
        GlStateManager.func_179141_d();
        GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
        GlStateManager.func_179097_i();
        this.renderArmorPercentage(stack, x);
        GlStateManager.func_179126_j();
        GlStateManager.func_179152_a(1.5f, 1.5f, 1.5f);
        GlStateManager.func_179121_F();
    }
    
    private void renderArmorPercentage(final ItemStack stack, final int x) {
        if (PlayerUtil.hasDurability(stack)) {
            final String percentColor = (PlayerUtil.getRoundedDamage(stack) >= 60) ? "§a" : ((PlayerUtil.getRoundedDamage(stack) >= 25) ? "§e" : "§c");
            this.renderer.drawStringWithShadow(percentColor + PlayerUtil.getRoundedDamage(stack) + "%", (float)(x * 2), -30.0f, -1);
        }
    }
    
    static {
        NameTags.INSTANCE = new NameTags();
    }
}
