// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import org.lwjgl.input.Keyboard;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class ThirdPerson extends Module
{
    public Setting<Boolean> onlyHold;
    public Setting<Bind> bind;
    
    public ThirdPerson() {
        super("ThirdPerson", "Third person camera but hold bind.", Category.VISUAL);
        this.onlyHold = (Setting<Boolean>)this.register(new Setting("OnlyHoldBind", (T)false));
        this.bind = (Setting<Bind>)this.register(new Setting("Bind:", (T)new Bind(-1)));
    }
    
    @Override
    public void onUpdate() {
        if (this.bind.getCurrentState().getKey() > -1) {
            if (Keyboard.isKeyDown(this.bind.getCurrentState().getKey())) {
                ThirdPerson.mc.field_71474_y.field_74320_O = 1;
            }
            else {
                ThirdPerson.mc.field_71474_y.field_74320_O = 0;
            }
        }
    }
    
    @Override
    public void onEnable() {
        if (!this.onlyHold.getCurrentState()) {
            ThirdPerson.mc.field_71474_y.field_74320_O = 1;
        }
    }
    
    @Override
    public void onDisable() {
        if (!this.onlyHold.getCurrentState()) {
            ThirdPerson.mc.field_71474_y.field_74320_O = 0;
        }
    }
}
