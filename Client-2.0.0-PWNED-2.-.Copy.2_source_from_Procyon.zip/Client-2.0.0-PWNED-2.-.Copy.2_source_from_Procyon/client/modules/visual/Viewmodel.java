// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Viewmodel extends Module
{
    public Setting<Float> sizeX;
    public Setting<Float> sizeY;
    public Setting<Float> sizeZ;
    public final Setting<Float> offsetX;
    public final Setting<Float> offsetY;
    public final Setting<Float> offsetZ;
    public final Setting<Float> offhandX;
    public final Setting<Float> offhandY;
    public final Setting<Float> offhandZ;
    private static Viewmodel INSTANCE;
    
    public Viewmodel() {
        super("Viewmodel", "Changes to the size and positions of your hands.", Category.VISUAL);
        this.sizeX = (Setting<Float>)this.register(new Setting("SizeX", (T)1.0f, (T)0.0f, (T)2.0f));
        this.sizeY = (Setting<Float>)this.register(new Setting("SizeY", (T)1.0f, (T)0.0f, (T)2.0f));
        this.sizeZ = (Setting<Float>)this.register(new Setting("SizeZ", (T)1.0f, (T)0.0f, (T)2.0f));
        this.offsetX = (Setting<Float>)this.register(new Setting("OffsetX", (T)0.0f, (T)(-1.0f), (T)1.0f));
        this.offsetY = (Setting<Float>)this.register(new Setting("OffsetY", (T)0.0f, (T)(-1.0f), (T)1.0f));
        this.offsetZ = (Setting<Float>)this.register(new Setting("OffsetZ", (T)0.0f, (T)(-1.0f), (T)1.0f));
        this.offhandX = (Setting<Float>)this.register(new Setting("OffhandX", (T)0.0f, (T)(-1.0f), (T)1.0f));
        this.offhandY = (Setting<Float>)this.register(new Setting("OffhandY", (T)0.0f, (T)(-1.0f), (T)1.0f));
        this.offhandZ = (Setting<Float>)this.register(new Setting("OffhandZ", (T)0.0f, (T)(-1.0f), (T)1.0f));
        this.setInstance();
    }
    
    private void setInstance() {
        Viewmodel.INSTANCE = this;
    }
    
    public static Viewmodel getINSTANCE() {
        if (Viewmodel.INSTANCE == null) {
            Viewmodel.INSTANCE = new Viewmodel();
        }
        return Viewmodel.INSTANCE;
    }
    
    static {
        Viewmodel.INSTANCE = new Viewmodel();
    }
}
