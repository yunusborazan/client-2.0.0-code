// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import net.minecraft.util.math.BlockPos;
import client.util.RenderUtil;
import java.awt.Color;
import client.util.ColorUtil;
import net.minecraft.init.Blocks;
import net.minecraft.entity.Entity;
import client.util.EntityUtil;
import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class CityESP extends Module
{
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Integer> selfred;
    public Setting<Integer> selfgreen;
    public Setting<Integer> selfblue;
    public Setting<Integer> selfalpha;
    
    public CityESP() {
        super("CityESP", "", Category.VISUAL);
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)120, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)120, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)120, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)120, (T)0, (T)255));
        this.selfred = (Setting<Integer>)this.register(new Setting("SelfRed", (T)120, (T)0, (T)255));
        this.selfgreen = (Setting<Integer>)this.register(new Setting("SelfGreen", (T)50, (T)0, (T)255));
        this.selfblue = (Setting<Integer>)this.register(new Setting("SelfBlue", (T)0, (T)0, (T)255));
        this.selfalpha = (Setting<Integer>)this.register(new Setting("SelfAlpha", (T)120, (T)0, (T)255));
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        for (final EntityPlayer player : CityESP.mc.field_71441_e.field_73010_i) {
            this.cityBlocks(player);
        }
    }
    
    public void cityBlocks(final EntityPlayer player) {
        final BlockPos pos = EntityUtil.getPlayerPos(player);
        if (EntityUtil.isSafe((Entity)player)) {
            if (CityESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z && CityESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150350_a && CityESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (CityESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || CityESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
                if (player.func_70005_c_().contains(CityESP.mc.func_110432_I().func_111285_a())) {
                    RenderUtil.drawBoxESP(pos.func_177978_c(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                }
                else {
                    RenderUtil.drawBoxESP(pos.func_177978_c(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
            if (CityESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z && CityESP.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f()).func_177230_c() == Blocks.field_150350_a && CityESP.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (CityESP.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || CityESP.mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
                if (player.func_70005_c_().contains(CityESP.mc.func_110432_I().func_111285_a())) {
                    RenderUtil.drawBoxESP(pos.func_177974_f(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                }
                else {
                    RenderUtil.drawBoxESP(pos.func_177974_f(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
            if (CityESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z && CityESP.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d()).func_177230_c() == Blocks.field_150350_a && CityESP.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (CityESP.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || CityESP.mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
                if (player.func_70005_c_().contains(CityESP.mc.func_110432_I().func_111285_a())) {
                    RenderUtil.drawBoxESP(pos.func_177968_d(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                }
                else {
                    RenderUtil.drawBoxESP(pos.func_177968_d(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
            if (CityESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z && CityESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150350_a && CityESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (CityESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || CityESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
                if (player.func_70005_c_().contains(CityESP.mc.func_110432_I().func_111285_a())) {
                    RenderUtil.drawBoxESP(pos.func_177976_e(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                }
                else {
                    RenderUtil.drawBoxESP(pos.func_177976_e(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
        }
    }
}
