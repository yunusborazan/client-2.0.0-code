// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import net.minecraft.util.EnumHand;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class SwingAnimations extends Module
{
    private final Setting<Switch> switchSetting;
    private final Setting<Swing> swing;
    private final Setting<Speed> speed;
    
    public SwingAnimations() {
        super("SwingAnimations", "Changes animations.", Category.VISUAL);
        this.switchSetting = (Setting<Switch>)this.register(new Setting("Switch", (T)Switch.ONEDOTEIGHT));
        this.swing = (Setting<Swing>)this.register(new Setting("Swing", (T)Swing.MAINHAND));
        this.speed = (Setting<Speed>)this.register(new Setting("Speed", (T)Speed.NORMAL));
    }
    
    @Override
    public void onUpdate() {
        if (nullCheck()) {
            return;
        }
        if (this.swing.getCurrentState() == Swing.OFFHAND) {
            SwingAnimations.mc.field_71439_g.field_184622_au = EnumHand.OFF_HAND;
        }
        if (this.swing.getCurrentState() == Swing.MAINHAND) {
            SwingAnimations.mc.field_71439_g.field_184622_au = EnumHand.MAIN_HAND;
        }
        if (this.switchSetting.getCurrentState() == Switch.ONEDOTEIGHT && SwingAnimations.mc.field_71460_t.field_78516_c.field_187470_g >= 0.9) {
            SwingAnimations.mc.field_71460_t.field_78516_c.field_187469_f = 1.0f;
            SwingAnimations.mc.field_71460_t.field_78516_c.field_187467_d = SwingAnimations.mc.field_71439_g.func_184614_ca();
        }
        if (this.speed.getCurrentState() == Speed.SLOW) {
            SwingAnimations.mc.field_71439_g.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 10));
            SwingAnimations.mc.field_71439_g.func_184589_d(MobEffects.field_76422_e);
        }
        else if (this.speed.getCurrentState() == Speed.NORMAL) {
            SwingAnimations.mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
            SwingAnimations.mc.field_71439_g.func_184589_d(MobEffects.field_76422_e);
        }
        else if (this.speed.getCurrentState() == Speed.FAST) {
            SwingAnimations.mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
            SwingAnimations.mc.field_71439_g.func_70690_d(new PotionEffect(MobEffects.field_76422_e, 10));
        }
    }
    
    @Override
    public void onDisable() {
        SwingAnimations.mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
        SwingAnimations.mc.field_71439_g.func_184589_d(MobEffects.field_76422_e);
    }
    
    private enum Switch
    {
        ONEDOTNINE, 
        ONEDOTEIGHT;
    }
    
    private enum Swing
    {
        MAINHAND, 
        OFFHAND;
    }
    
    private enum Speed
    {
        SLOW, 
        NORMAL, 
        FAST;
    }
}
