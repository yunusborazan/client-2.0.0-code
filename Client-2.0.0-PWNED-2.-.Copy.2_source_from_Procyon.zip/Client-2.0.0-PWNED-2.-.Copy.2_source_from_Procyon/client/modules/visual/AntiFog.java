// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class AntiFog extends Module
{
    private final Setting<Float> red;
    private final Setting<Float> green;
    private final Setting<Float> blue;
    private final Setting<Float> red1;
    private final Setting<Float> green1;
    private final Setting<Float> blue1;
    private final Setting<Float> red2;
    private final Setting<Float> green2;
    private final Setting<Float> blue2;
    private final Setting<Boolean> clear;
    private final Setting<Boolean> color;
    
    public AntiFog() {
        super("AntiFog", "Removes fog and makes it colored", Category.VISUAL);
        this.red = (Setting<Float>)this.register(new Setting("Red", (T)1.0f, (T)0.0f, (T)1.0f));
        this.green = (Setting<Float>)this.register(new Setting("Green", (T)1.0f, (T)0.0f, (T)1.0f));
        this.blue = (Setting<Float>)this.register(new Setting("Blue", (T)1.0f, (T)0.0f, (T)1.0f));
        this.red1 = (Setting<Float>)this.register(new Setting("Nether Red", (T)1.0f, (T)0.0f, (T)1.0f));
        this.green1 = (Setting<Float>)this.register(new Setting("Nether Green", (T)1.0f, (T)0.0f, (T)1.0f));
        this.blue1 = (Setting<Float>)this.register(new Setting("Nether Blue", (T)1.0f, (T)0.0f, (T)1.0f));
        this.red2 = (Setting<Float>)this.register(new Setting("End Red", (T)1.0f, (T)0.0f, (T)1.0f));
        this.green2 = (Setting<Float>)this.register(new Setting("End Green", (T)1.0f, (T)0.0f, (T)1.0f));
        this.blue2 = (Setting<Float>)this.register(new Setting("End Blue", (T)1.0f, (T)0.0f, (T)1.0f));
        this.clear = (Setting<Boolean>)this.register(new Setting("Remove fog", (T)true));
        this.color = (Setting<Boolean>)this.register(new Setting("Color fog", (T)true));
    }
    
    @Override
    public void onLogin() {
        if (this.isEnabled()) {
            this.disable();
            this.enable();
        }
    }
    
    @SubscribeEvent
    public void onFogDensity(final EntityViewRenderEvent.FogDensity event) {
        if (this.clear.getCurrentState()) {
            event.setDensity(0.0f);
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onFogColor(final EntityViewRenderEvent.FogColors event) {
        if (this.color.getCurrentState()) {
            if (AntiFog.mc.field_71439_g.field_71093_bK == 0) {
                event.setRed((float)this.red.getCurrentState());
                event.setGreen((float)this.green.getCurrentState());
                event.setBlue((float)this.blue.getCurrentState());
            }
            else if (AntiFog.mc.field_71439_g.field_71093_bK == -1) {
                event.setRed((float)this.red1.getCurrentState());
                event.setGreen((float)this.green1.getCurrentState());
                event.setBlue((float)this.blue1.getCurrentState());
            }
            else if (AntiFog.mc.field_71439_g.field_71093_bK == 1) {
                event.setRed((float)this.red2.getCurrentState());
                event.setGreen((float)this.green2.getCurrentState());
                event.setBlue((float)this.blue2.getCurrentState());
            }
        }
    }
}
