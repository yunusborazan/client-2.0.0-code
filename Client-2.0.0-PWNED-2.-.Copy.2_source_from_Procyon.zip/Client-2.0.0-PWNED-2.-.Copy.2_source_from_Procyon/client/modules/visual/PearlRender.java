// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import net.minecraft.util.math.BlockPos;
import java.util.Iterator;
import client.util.MathUtil;
import client.util.RenderUtil;
import java.awt.Color;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.AxisAlignedBB;
import client.util.EntityUtil;
import net.minecraft.entity.item.EntityEnderPearl;
import client.events.Render3DEvent;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.Entity;
import client.modules.Module;

public class PearlRender extends Module
{
    public PearlRender() {
        super("PearlRender", "Renders where pearls will go", Category.VISUAL);
    }
    
    public double interpolate(final double now, final double then) {
        return then + (now - then) * PearlRender.mc.func_184121_ak();
    }
    
    public double[] interpolate(final Entity entity) {
        final double posX = this.interpolate(entity.field_70165_t, entity.field_70142_S) - PearlRender.mc.func_175598_ae().field_78725_b;
        final double posY = this.interpolate(entity.field_70163_u, entity.field_70137_T) - PearlRender.mc.func_175598_ae().field_78726_c;
        final double posZ = this.interpolate(entity.field_70161_v, entity.field_70136_U) - PearlRender.mc.func_175598_ae().field_78723_d;
        return new double[] { posX, posY, posZ };
    }
    
    public void drawLineToEntity(final Entity e, final float red, final float green, final float blue, final float opacity) {
        final double[] xyz = this.interpolate(e);
        this.drawLine(xyz[0], xyz[1], xyz[2], red, green, blue, opacity);
    }
    
    public void drawLine(final double posx, final double posy, final double posz, final float red, final float green, final float blue, final float opacity) {
        final Vec3d eyes = new Vec3d(0.0, 0.0, 1.0).func_178789_a(-(float)Math.toRadians(PearlRender.mc.field_71439_g.field_70125_A)).func_178785_b(-(float)Math.toRadians(PearlRender.mc.field_71439_g.field_70177_z));
        this.drawLineFromPosToPos(eyes.field_72450_a, eyes.field_72448_b + PearlRender.mc.field_71439_g.func_70047_e(), eyes.field_72449_c, posx, posy, posz, red, green, blue, opacity);
    }
    
    public void drawLineFromPosToPos(final double posx, final double posy, final double posz, final double posx2, final double posy2, final double posz2, final float red, final float green, final float blue, final float opacity) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glLineWidth(1.0f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glColor4f(red, green, blue, opacity);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLoadIdentity();
        final boolean bobbing = PearlRender.mc.field_71474_y.field_74336_f;
        PearlRender.mc.field_71474_y.field_74336_f = false;
        PearlRender.mc.field_71460_t.func_78467_g(PearlRender.mc.func_184121_ak());
        GL11.glBegin(1);
        GL11.glVertex3d(posx, posy, posz);
        GL11.glVertex3d(posx2, posy2, posz2);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glColor3d(1.0, 1.0, 1.0);
        PearlRender.mc.field_71474_y.field_74336_f = bobbing;
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        int i = 0;
        for (final Entity entity : PearlRender.mc.field_71441_e.field_72996_f) {
            if (entity instanceof EntityEnderPearl) {
                if (PearlRender.mc.field_71439_g.func_70068_e(entity) >= 2500.0) {
                    continue;
                }
                final Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, PearlRender.mc.func_184121_ak());
                final AxisAlignedBB bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a(770, 771, 0, 1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a(false);
                GL11.glEnable(2848);
                GL11.glHint(3154, 4354);
                GL11.glLineWidth(1.0f);
                RenderGlobal.func_189696_b(bb, 255.0f, 255.0f, 255.0f, 255.0f);
                GL11.glDisable(2848);
                GlStateManager.func_179132_a(true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
                RenderUtil.drawBlockOutline(bb, new Color(255, 255, 255), 1.0f);
                this.drawLineToEntity(entity, 255.0f, 255.0f, 255.0f, 255.0f);
                final BlockPos posEntity = entity.func_180425_c();
                RenderUtil.drawText(posEntity, "X: " + MathUtil.round(entity.field_70165_t, 0) + " Y: " + MathUtil.round(entity.field_70163_u, 0) + " Z:" + MathUtil.round(entity.field_70161_v, 2));
                if (++i < 50) {
                    continue;
                }
                break;
            }
        }
    }
}
