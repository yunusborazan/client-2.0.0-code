// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import client.modules.Module;

public class FullBright extends Module
{
    public FullBright() {
        super("Fullbright", "Permanent brightness", Category.VISUAL);
    }
    
    @Override
    public void onEnable() {
        FullBright.mc.field_71474_y.field_74333_Y = 1000.0f;
    }
    
    @Override
    public void onUpdate() {
        if (FullBright.mc.field_71474_y.field_74333_Y != 6969.0f) {
            FullBright.mc.field_71474_y.field_74333_Y = 6969.0f;
        }
    }
}
