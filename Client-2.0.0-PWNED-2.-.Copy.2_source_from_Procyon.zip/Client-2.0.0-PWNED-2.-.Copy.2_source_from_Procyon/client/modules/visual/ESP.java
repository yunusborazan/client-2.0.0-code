// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.visual;

import net.minecraft.init.Blocks;
import net.minecraft.util.math.Vec3i;
import client.manager.TextManager;
import net.minecraft.client.Minecraft;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.events.Render2DEvent;
import net.minecraft.util.math.Vec3d;
import java.util.Iterator;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.client.renderer.RenderGlobal;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.AxisAlignedBB;
import client.util.EntityUtil;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.Entity;
import client.util.RenderUtil;
import java.awt.Color;
import client.util.ColorUtil;
import client.events.Render3DEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.events.ClientEvent;
import com.google.common.collect.Sets;
import client.gui.impl.setting.Setting;
import net.minecraft.util.math.BlockPos;
import java.util.HashSet;
import client.modules.Module;

public class ESP extends Module
{
    public int updates;
    HashSet<BlockPos> bedrockholes;
    HashSet<BlockPos> obsidianholes;
    public Setting<Boolean> holes;
    public Setting<Boolean> renderPerformance;
    public Setting<Integer> range;
    public Setting<Integer> rangeY;
    public Setting<Integer> updateDelay;
    public Setting<Boolean> bedrockBox;
    public Setting<Boolean> bedrockFlat;
    public Setting<Integer> bedrockBoxRed;
    public Setting<Integer> bedrockBoxGreen;
    public Setting<Integer> bedrockBoxBlue;
    public Setting<Integer> bedrockBoxAlpha;
    public Setting<Boolean> bedrockOutline;
    public Setting<Integer> bedrockOutlineRed;
    public Setting<Integer> bedrockOutlineGreen;
    public Setting<Integer> bedrockOutlineBlue;
    public Setting<Integer> bedrockOutlineAlpha;
    public Setting<Integer> bedrockOutlineLineWidth;
    public Setting<Boolean> obsidianBox;
    public Setting<Boolean> obsidianFlat;
    public Setting<Integer> obsidianBoxRed;
    public Setting<Integer> obsidianBoxGreen;
    public Setting<Integer> obsidianBoxBlue;
    public Setting<Integer> obsidianBoxAlpha;
    public Setting<Boolean> obsidianOutline;
    public Setting<Integer> obsidianOutlineRed;
    public Setting<Integer> obsidianOutlineGreen;
    public Setting<Integer> obsidianOutlineBlue;
    public Setting<Integer> obsidianOutlineAlpha;
    public Setting<Integer> obsidianOutlineLineWidth;
    public Setting<Boolean> bottles;
    public Setting<Integer> bottlesred;
    public Setting<Integer> bottlesgreen;
    public Setting<Integer> bottlesblue;
    public Setting<Integer> bottlesalpha;
    public Setting<Boolean> orbs;
    public Setting<Integer> o_red;
    public Setting<Integer> o_green;
    public Setting<Integer> o_blue;
    public Setting<Integer> o_alpha;
    
    public ESP() {
        super("ESP", "", Category.VISUAL);
        this.bedrockholes = (HashSet<BlockPos>)Sets.newHashSet();
        this.obsidianholes = (HashSet<BlockPos>)Sets.newHashSet();
        this.holes = (Setting<Boolean>)this.register(new Setting("Holes", (T)true));
        this.renderPerformance = (Setting<Boolean>)this.register(new Setting("RenderPerformance", (T)true));
        this.range = (Setting<Integer>)this.register(new Setting("X-Range", (T)0, (T)1, (T)20, v -> this.holes.getCurrentState()));
        this.rangeY = (Setting<Integer>)this.register(new Setting("Y-Range", (T)0, (T)1, (T)20, v -> this.holes.getCurrentState()));
        this.updateDelay = (Setting<Integer>)this.register(new Setting("UpdateDelay", (T)1, (T)0, (T)30, v -> this.holes.getCurrentState()));
        this.bedrockBox = (Setting<Boolean>)this.register(new Setting("BedrockBox", (T)true, v -> this.holes.getCurrentState()));
        this.bedrockFlat = (Setting<Boolean>)this.register(new Setting("BedrockFlat", (T)true, v -> this.holes.getCurrentState()));
        this.bedrockBoxRed = (Setting<Integer>)this.register(new Setting("BedrockBoxRed", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockBox.getCurrentState()));
        this.bedrockBoxGreen = (Setting<Integer>)this.register(new Setting("BedrockBoxGreen", (T)255, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockBox.getCurrentState()));
        this.bedrockBoxBlue = (Setting<Integer>)this.register(new Setting("BedrockBoxBlue", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockBox.getCurrentState()));
        this.bedrockBoxAlpha = (Setting<Integer>)this.register(new Setting("BedrockBoxAlpha", (T)120, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockBox.getCurrentState()));
        this.bedrockOutline = (Setting<Boolean>)this.register(new Setting("BedrockOutline", (T)true, v -> this.holes.getCurrentState()));
        this.bedrockOutlineRed = (Setting<Integer>)this.register(new Setting("BedrockOutlineRed", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockOutline.getCurrentState()));
        this.bedrockOutlineGreen = (Setting<Integer>)this.register(new Setting("BedrockOutlineGreen", (T)255, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockOutline.getCurrentState()));
        this.bedrockOutlineBlue = (Setting<Integer>)this.register(new Setting("BedrockOutlineBlue", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockOutline.getCurrentState()));
        this.bedrockOutlineAlpha = (Setting<Integer>)this.register(new Setting("BedrockOutlineAlpha", (T)255, (T)0, (T)255, v -> this.holes.getCurrentState() && this.bedrockOutline.getCurrentState()));
        this.bedrockOutlineLineWidth = (Setting<Integer>)this.register(new Setting("BedrockOutlineLineWidth", (T)1, (T)0.1, (T)5, v -> this.holes.getCurrentState() && this.bedrockOutline.getCurrentState()));
        this.obsidianBox = (Setting<Boolean>)this.register(new Setting("ObsidianBox", (T)true, v -> this.holes.getCurrentState()));
        this.obsidianFlat = (Setting<Boolean>)this.register(new Setting("ObsidianFlat", (T)false, v -> this.holes.getCurrentState()));
        this.obsidianBoxRed = (Setting<Integer>)this.register(new Setting("ObsidianBoxRed", (T)255, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianBox.getCurrentState()));
        this.obsidianBoxGreen = (Setting<Integer>)this.register(new Setting("ObsidianBoxGreen", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianBox.getCurrentState()));
        this.obsidianBoxBlue = (Setting<Integer>)this.register(new Setting("ObsidianBoxBlue", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianBox.getCurrentState()));
        this.obsidianBoxAlpha = (Setting<Integer>)this.register(new Setting("ObsidianBoxAlpha", (T)120, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianBox.getCurrentState()));
        this.obsidianOutline = (Setting<Boolean>)this.register(new Setting("ObsidianOutline", (T)true, v -> this.holes.getCurrentState()));
        this.obsidianOutlineRed = (Setting<Integer>)this.register(new Setting("ObsidianOutlineRed", (T)255, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianOutline.getCurrentState()));
        this.obsidianOutlineGreen = (Setting<Integer>)this.register(new Setting("ObsidianOutlineGreen", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianOutline.getCurrentState()));
        this.obsidianOutlineBlue = (Setting<Integer>)this.register(new Setting("ObsidianOutlineBlue", (T)0, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianOutline.getCurrentState()));
        this.obsidianOutlineAlpha = (Setting<Integer>)this.register(new Setting("ObsidianOutlineAlpha", (T)255, (T)0, (T)255, v -> this.holes.getCurrentState() && this.obsidianOutline.getCurrentState()));
        this.obsidianOutlineLineWidth = (Setting<Integer>)this.register(new Setting("obsidianOutlineLineWidth", (T)1, (T)0.1, (T)5, v -> this.holes.getCurrentState() && this.obsidianOutline.getCurrentState()));
        this.bottles = (Setting<Boolean>)this.register(new Setting("Bottles", (T)true));
        this.bottlesred = (Setting<Integer>)this.register(new Setting("BottlesRed", (T)255, (T)0, (T)255, v -> this.bottles.getCurrentState()));
        this.bottlesgreen = (Setting<Integer>)this.register(new Setting("BottlesGreen", (T)255, (T)0, (T)255, v -> this.bottles.getCurrentState()));
        this.bottlesblue = (Setting<Integer>)this.register(new Setting("BottlesBlue", (T)255, (T)0, (T)255, v -> this.bottles.getCurrentState()));
        this.bottlesalpha = (Setting<Integer>)this.register(new Setting("BottlesAlpha", (T)150, (T)0, (T)255, v -> this.bottles.getCurrentState()));
        this.orbs = (Setting<Boolean>)this.register(new Setting("Orbs", (T)true));
        this.o_red = (Setting<Integer>)this.register(new Setting("OrbsRed", (T)255, (T)0, (T)255, v -> this.orbs.getCurrentState()));
        this.o_green = (Setting<Integer>)this.register(new Setting("OrbsGreen", (T)255, (T)0, (T)255, v -> this.orbs.getCurrentState()));
        this.o_blue = (Setting<Integer>)this.register(new Setting("OrbsBlue", (T)255, (T)0, (T)255, v -> this.orbs.getCurrentState()));
        this.o_alpha = (Setting<Integer>)this.register(new Setting("OrbsAlpha", (T)150, (T)0, (T)255, v -> this.orbs.getCurrentState()));
    }
    
    @Override
    public void onTick() {
        if (this.holes.getCurrentState()) {
            if (this.updates > this.updateDelay.getCurrentState()) {
                this.updates = 0;
            }
            else {
                ++this.updates;
            }
        }
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (!this.holes.getCurrentState()) {
            this.obsidianholes.clear();
            this.bedrockholes.clear();
            this.updates = 0;
        }
    }
    
    @Override
    public void onEnable() {
        this.updates = 0;
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        for (final BlockPos pos : this.bedrockholes) {
            if (this.bedrockFlat.getCurrentState()) {
                RenderUtil.drawBoxESPFlat(pos, new Color(ColorUtil.toRGBA(this.bedrockBoxRed.getCurrentState(), this.bedrockBoxGreen.getCurrentState(), this.bedrockBoxBlue.getCurrentState(), this.bedrockBoxAlpha.getCurrentState())), true, new Color(ColorUtil.toRGBA(this.bedrockOutlineRed.getCurrentState(), this.bedrockOutlineGreen.getCurrentState(), this.bedrockOutlineBlue.getCurrentState(), this.bedrockOutlineAlpha.getCurrentState())), this.bedrockOutlineLineWidth.getCurrentState(), this.bedrockOutline.getCurrentState(), this.bedrockBox.getCurrentState(), this.bedrockBoxAlpha.getCurrentState(), true);
            }
            else {
                RenderUtil.drawBoxESP(pos, new Color(ColorUtil.toRGBA(this.bedrockBoxRed.getCurrentState(), this.bedrockBoxGreen.getCurrentState(), this.bedrockBoxBlue.getCurrentState(), this.bedrockBoxAlpha.getCurrentState())), true, new Color(ColorUtil.toRGBA(this.bedrockOutlineRed.getCurrentState(), this.bedrockOutlineGreen.getCurrentState(), this.bedrockOutlineBlue.getCurrentState(), this.bedrockOutlineAlpha.getCurrentState())), this.bedrockOutlineLineWidth.getCurrentState(), this.bedrockOutline.getCurrentState(), this.bedrockBox.getCurrentState(), this.bedrockBoxAlpha.getCurrentState(), true);
            }
        }
        for (final BlockPos pos : this.obsidianholes) {
            if (this.obsidianFlat.getCurrentState()) {
                RenderUtil.drawBoxESPFlat(pos, new Color(ColorUtil.toRGBA(this.obsidianBoxRed.getCurrentState(), this.obsidianBoxGreen.getCurrentState(), this.obsidianBoxBlue.getCurrentState(), this.obsidianBoxAlpha.getCurrentState())), true, new Color(ColorUtil.toRGBA(this.obsidianOutlineRed.getCurrentState(), this.obsidianOutlineGreen.getCurrentState(), this.obsidianOutlineBlue.getCurrentState(), this.obsidianOutlineAlpha.getCurrentState())), this.obsidianOutlineLineWidth.getCurrentState(), this.obsidianOutline.getCurrentState(), this.obsidianBox.getCurrentState(), this.obsidianBoxAlpha.getCurrentState(), true);
            }
            else {
                RenderUtil.drawBoxESP(pos, new Color(ColorUtil.toRGBA(this.obsidianBoxRed.getCurrentState(), this.obsidianBoxGreen.getCurrentState(), this.obsidianBoxBlue.getCurrentState(), this.obsidianBoxAlpha.getCurrentState())), true, new Color(ColorUtil.toRGBA(this.obsidianOutlineRed.getCurrentState(), this.obsidianOutlineGreen.getCurrentState(), this.obsidianOutlineBlue.getCurrentState(), this.obsidianOutlineAlpha.getCurrentState())), this.obsidianOutlineLineWidth.getCurrentState(), this.obsidianOutline.getCurrentState(), this.obsidianBox.getCurrentState(), this.obsidianBoxAlpha.getCurrentState(), true);
            }
        }
        if (this.updates > this.updateDelay.getCurrentState() && this.holes.getCurrentState()) {
            this.obsidianholes.clear();
            this.bedrockholes.clear();
            this.findHoles();
        }
        int i = 0;
        if (this.orbs.getCurrentState()) {
            for (final Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (entity instanceof EntityXPOrb) {
                    if (ESP.mc.field_71439_g.func_70068_e(entity) >= 2500.0) {
                        continue;
                    }
                    final Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, ESP.mc.func_184121_ak());
                    final AxisAlignedBB bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179097_i();
                    GlStateManager.func_179120_a(770, 771, 0, 1);
                    GlStateManager.func_179090_x();
                    GlStateManager.func_179132_a(false);
                    GL11.glEnable(2848);
                    GL11.glHint(3154, 4354);
                    GL11.glLineWidth(1.0f);
                    RenderGlobal.func_189696_b(bb, this.bottlesred.getCurrentState() / 255.0f, this.bottlesgreen.getCurrentState() / 255.0f, this.bottlesblue.getCurrentState() / 255.0f, this.bottlesalpha.getCurrentState() / 255.0f);
                    GL11.glDisable(2848);
                    GlStateManager.func_179132_a(true);
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179098_w();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179121_F();
                    RenderUtil.drawBlockOutline(bb, new Color(this.bottlesred.getCurrentState(), this.bottlesgreen.getCurrentState(), this.bottlesblue.getCurrentState(), this.bottlesalpha.getCurrentState()), 1.0f);
                    if (++i < 50) {
                        continue;
                    }
                    break;
                }
            }
        }
        if (this.bottles.getCurrentState()) {
            i = 0;
            for (final Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (entity instanceof EntityExpBottle) {
                    if (ESP.mc.field_71439_g.func_70068_e(entity) >= 2500.0) {
                        continue;
                    }
                    final Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, ESP.mc.func_184121_ak());
                    final AxisAlignedBB bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179097_i();
                    GlStateManager.func_179120_a(770, 771, 0, 1);
                    GlStateManager.func_179090_x();
                    GlStateManager.func_179132_a(false);
                    GL11.glEnable(2848);
                    GL11.glHint(3154, 4354);
                    GL11.glLineWidth(1.0f);
                    RenderGlobal.func_189696_b(bb, this.o_red.getCurrentState() / 255.0f, this.o_green.getCurrentState() / 255.0f, this.o_blue.getCurrentState() / 255.0f, this.o_alpha.getCurrentState() / 255.0f);
                    GL11.glDisable(2848);
                    GlStateManager.func_179132_a(true);
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179098_w();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179121_F();
                    RenderUtil.drawBlockOutline(bb, new Color(this.o_red.getCurrentState(), this.o_green.getCurrentState(), this.o_blue.getCurrentState(), this.o_alpha.getCurrentState()), 1.0f);
                    if (++i < 50) {
                        continue;
                    }
                    break;
                }
            }
        }
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        if (this.renderPerformance.getCurrentState()) {
            final TextManager renderer = this.renderer;
            final StringBuilder append = new StringBuilder().append(ChatFormatting.WHITE).append("ESP ").append(ChatFormatting.DARK_GRAY).append("[").append(ChatFormatting.GRAY).append(this.updates).append(" | ");
            final Minecraft mc = ESP.mc;
            renderer.drawStringWithShadow(append.append(Minecraft.func_175610_ah()).append(ChatFormatting.DARK_GRAY).append("]").toString(), 0.0f, 10.0f, 0);
        }
    }
    
    public void findHoles() {
        assert ESP.mc.field_175622_Z != null;
        final Vec3i playerPos = new Vec3i(ESP.mc.field_175622_Z.field_70165_t, ESP.mc.field_175622_Z.field_70163_u, ESP.mc.field_175622_Z.field_70161_v);
        for (int x = playerPos.func_177958_n() - this.range.getCurrentState(); x < playerPos.func_177958_n() + this.range.getCurrentState(); ++x) {
            for (int z = playerPos.func_177952_p() - this.range.getCurrentState(); z < playerPos.func_177952_p() + this.range.getCurrentState(); ++z) {
                for (int y = playerPos.func_177956_o() + this.rangeY.getCurrentState(); y > playerPos.func_177956_o() - this.rangeY.getCurrentState(); --y) {
                    final BlockPos pos = new BlockPos(x, y, z);
                    if (this.updates > this.updateDelay.getCurrentState()) {
                        if (ESP.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h) {
                            this.bedrockholes.add(pos);
                        }
                        else if (ESP.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && (ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h)) {
                            this.obsidianholes.add(pos);
                        }
                        else if (ESP.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177974_f()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177976_e()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h) {
                            this.bedrockholes.add(pos);
                            this.bedrockholes.add(pos.func_177978_c());
                        }
                        else if (ESP.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && (ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150350_a && (ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177974_f()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177974_f()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177976_e()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177976_e()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
                            this.obsidianholes.add(pos);
                            this.obsidianholes.add(pos.func_177978_c());
                        }
                        else if (ESP.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177968_d()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177978_c()).func_177230_c() == Blocks.field_150357_h && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150357_h) {
                            this.bedrockholes.add(pos);
                            this.bedrockholes.add(pos.func_177976_e());
                        }
                        else if (ESP.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && ESP.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && (ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z) && ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150350_a && (ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177968_d()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177968_d()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177978_c()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177978_c()).func_177230_c() == Blocks.field_150343_Z) && (ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150357_h || ESP.mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150343_Z)) {
                            this.obsidianholes.add(pos);
                            this.obsidianholes.add(pos.func_177976_e());
                        }
                    }
                }
            }
        }
    }
}
