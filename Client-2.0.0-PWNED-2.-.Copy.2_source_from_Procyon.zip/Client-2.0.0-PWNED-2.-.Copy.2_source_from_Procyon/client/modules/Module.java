// 
// Decompiled by Procyon v0.5.36
// 

package client.modules;

import client.command.Command;
import net.minecraftforge.fml.common.eventhandler.Event;
import client.events.ClientEvent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.Client;
import client.modules.client.Notify;
import net.minecraftforge.common.MinecraftForge;
import client.events.Render3DEvent;
import client.events.Render2DEvent;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;

public class Module extends Feature
{
    private final String description;
    private final Category category;
    public Setting<Boolean> enabled;
    public Setting<Bind> bind;
    public Setting<Boolean> drawn;
    public Setting<String> displayName;
    public boolean hasListener;
    public boolean alwaysListening;
    public boolean hidden;
    public float arrayListOffset;
    public float arrayListVOffset;
    public float offset;
    public float vOffset;
    public boolean sliding;
    
    public Module(final String name, final String description, final Category category) {
        super(name);
        this.enabled = (Setting<Boolean>)this.register(new Setting("Enabled", (T)false));
        this.bind = (Setting<Bind>)this.register(new Setting("Keybind", (T)new Bind(-1)));
        this.drawn = (Setting<Boolean>)this.register(new Setting("Drawn", (T)true));
        this.arrayListOffset = 0.0f;
        this.arrayListVOffset = 0.0f;
        this.displayName = (Setting<String>)this.register(new Setting("DisplayName", (T)name));
        this.description = description;
        this.category = category;
    }
    
    public boolean isSliding() {
        return this.sliding;
    }
    
    public void onEnable() {
    }
    
    public void onDisable() {
    }
    
    public void onToggle() {
    }
    
    public void onLoad() {
    }
    
    public void onTick() {
    }
    
    public void onLogin() {
    }
    
    public void onLogout() {
    }
    
    public void onUpdate() {
    }
    
    public void onRender2D(final Render2DEvent event) {
    }
    
    public void onRender3D(final Render3DEvent event) {
    }
    
    public void onUnload() {
    }
    
    public String getDisplayInfo() {
        return null;
    }
    
    public boolean isOn() {
        return this.enabled.getCurrentState();
    }
    
    public boolean isOff() {
        return !this.enabled.getCurrentState();
    }
    
    public void setEnabled(final boolean enabled) {
        if (enabled) {
            this.enable();
        }
        else {
            this.disable();
        }
    }
    
    public void enable() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.enabled.setValue(Boolean.TRUE);
        this.onToggle();
        this.onEnable();
        if (Notify.getInstance().chatMessages.getCurrentState() && Notify.getInstance().isOn()) {
            final TextComponentString text = new TextComponentString(Client.commandManager.getClientMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + this.getDisplayName() + ChatFormatting.RESET + ChatFormatting.GREEN + " enabled.");
            Module.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)text, 1);
        }
    }
    
    public void disable() {
        this.enabled.setValue(false);
        if (Notify.getInstance().chatMessages.getCurrentState() && Notify.getInstance().isOn()) {
            final TextComponentString text = new TextComponentString(Client.commandManager.getClientMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + this.getDisplayName() + ChatFormatting.RESET + ChatFormatting.RED + " disabled.");
            Module.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)text, 1);
        }
        this.onToggle();
        this.onDisable();
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
    
    public void toggle() {
        final ClientEvent event = new ClientEvent(this.isEnabled() ? 0 : 1, this);
        MinecraftForge.EVENT_BUS.post((Event)event);
        if (!event.isCanceled()) {
            this.setEnabled(!this.isEnabled());
        }
    }
    
    public String getDisplayName() {
        return this.displayName.getCurrentState();
    }
    
    public void setDisplayName(final String name) {
        final Module module = Client.moduleManager.getModuleByDisplayName(name);
        final Module originalModule = Client.moduleManager.getModuleByName(name);
        if (module == null && originalModule == null) {
            Command.sendMessage(this.getDisplayName() + ", name: " + this.getName() + ", has been renamed to: " + name);
            this.displayName.setValue(name);
            return;
        }
        Command.sendMessage(ChatFormatting.RED + "A module of this name already exists.");
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public Category getCategory() {
        return this.category;
    }
    
    public String getInfo() {
        return null;
    }
    
    public Bind getBind() {
        return this.bind.getCurrentState();
    }
    
    public void setBind(final int key) {
        this.bind.setValue(new Bind(key));
    }
    
    public boolean isDrawn() {
        return this.drawn.getCurrentState();
    }
    
    public void setDrawn(final boolean drawn) {
        this.drawn.setValue(drawn);
    }
    
    public boolean listening() {
        return (this.hasListener && this.isOn()) || this.alwaysListening;
    }
    
    public String getFullArrayString() {
        return this.getDisplayName() + ChatFormatting.GRAY + ((this.getDisplayInfo() != null) ? (" " + ChatFormatting.WHITE + this.getDisplayInfo()) : "");
    }
    
    public enum Category
    {
        COMBAT("Combat"), 
        MISC("Miscellaneous"), 
        MOVEMENT("Movement"), 
        PLAYER("Player"), 
        VISUAL("Visual"), 
        CORE("Core");
        
        private final String name;
        
        private Category(final String name) {
            this.name = name;
        }
        
        public String getName() {
            return this.name;
        }
    }
}
