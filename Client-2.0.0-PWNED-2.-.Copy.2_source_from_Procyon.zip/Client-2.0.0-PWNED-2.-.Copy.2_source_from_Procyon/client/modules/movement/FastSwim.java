// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import client.util.Timer;
import client.modules.Module;

public class FastSwim extends Module
{
    Timer timer;
    
    public FastSwim() {
        super("FastSwim", "", Category.MOVEMENT);
        this.timer = new Timer();
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        this.timer.setCurrentMS();
        if (FastSwim.mc.field_71439_g.func_70090_H()) {
            if (!FastSwim.mc.field_71439_g.func_70093_af()) {
                final EntityPlayerSP field_71439_g = FastSwim.mc.field_71439_g;
                field_71439_g.field_70181_x *= 0.01;
            }
            if (FastSwim.mc.field_71474_y.field_74314_A.func_151470_d()) {
                final EntityPlayerSP field_71439_g2 = FastSwim.mc.field_71439_g;
                field_71439_g2.field_70181_x *= 1.8;
            }
            final EntityPlayerSP field_71439_g3 = FastSwim.mc.field_71439_g;
            field_71439_g3.field_70159_w *= 1.18;
            final EntityPlayerSP field_71439_g4 = FastSwim.mc.field_71439_g;
            field_71439_g4.field_70179_y *= 1.18;
        }
        else {
            this.timer.setLastMS();
        }
    }
}
