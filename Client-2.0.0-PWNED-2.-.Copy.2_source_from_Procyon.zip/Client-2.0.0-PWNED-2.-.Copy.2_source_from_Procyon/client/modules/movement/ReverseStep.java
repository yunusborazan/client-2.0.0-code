// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class ReverseStep extends Module
{
    private final Setting<Integer> speed;
    
    public ReverseStep() {
        super("ReverseStep", "Speeds up downwards motion", Category.MOVEMENT);
        this.speed = (Setting<Integer>)this.register(new Setting("Speed", (T)0, (T)0, (T)20));
    }
    
    @Override
    public void onUpdate() {
        if (ReverseStep.mc.field_71439_g.func_180799_ab() || ReverseStep.mc.field_71439_g.func_70090_H() || Phase.getInstance().isOn()) {
            return;
        }
        if (ReverseStep.mc.field_71439_g.field_70122_E) {
            final EntityPlayerSP field_71439_g = ReverseStep.mc.field_71439_g;
            field_71439_g.field_70181_x -= this.speed.getCurrentState();
        }
    }
}
