// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import client.events.EntityCollisionEvent;
import client.events.PushEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import client.events.PacketEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Velocity extends Module
{
    public Setting<Boolean> explosions;
    public Setting<Float> horizontal;
    public Setting<Float> vertical;
    public Setting<Boolean> noPush;
    public Setting<Boolean> blocks;
    
    public Velocity() {
        super("Velocity", "Allows you to control your velocity", Category.MOVEMENT);
        this.explosions = (Setting<Boolean>)this.register(new Setting("Explosions", (T)false));
        this.horizontal = (Setting<Float>)this.register(new Setting("Horizontal", (T)0.0f, (T)0.0f, (T)100.0f, v -> this.explosions.getCurrentState()));
        this.vertical = (Setting<Float>)this.register(new Setting("Vertical", (T)0.0f, (T)0.0f, (T)100.0f, v -> this.explosions.getCurrentState()));
        this.noPush = (Setting<Boolean>)this.register(new Setting("NoPush", (T)false));
        this.blocks = (Setting<Boolean>)this.register(new Setting("Blocks", (T)false));
    }
    
    @Override
    public void onLogin() {
        if (this.isEnabled()) {
            this.disable();
            this.enable();
        }
    }
    
    @SubscribeEvent
    public void onPacketReceived(final PacketEvent.Receive event) {
        if (event.getStage() == 0 && Velocity.mc.field_71439_g != null) {
            if (event.getPacket() instanceof SPacketEntityVelocity) {
                final SPacketEntityVelocity velocity = event.getPacket();
                if (velocity.func_149412_c() == Velocity.mc.field_71439_g.field_145783_c) {
                    if (this.horizontal.getCurrentState() == 0.0f && this.vertical.getCurrentState() == 0.0f) {
                        event.setCanceled(true);
                        return;
                    }
                    final SPacketEntityVelocity sPacketEntityVelocity = velocity;
                    sPacketEntityVelocity.field_149415_b *= (int)(this.horizontal.getCurrentState() / 100.0f);
                    final SPacketEntityVelocity sPacketEntityVelocity2 = velocity;
                    sPacketEntityVelocity2.field_149416_c *= (int)(this.vertical.getCurrentState() / 100.0f);
                    final SPacketEntityVelocity sPacketEntityVelocity3 = velocity;
                    sPacketEntityVelocity3.field_149414_d *= (int)(this.horizontal.getCurrentState() / 100.0f);
                }
            }
            if (this.explosions.getCurrentState() && event.getPacket() instanceof SPacketExplosion) {
                if (this.horizontal.getCurrentState() == 0.0f && this.vertical.getCurrentState() == 0.0f) {
                    event.setCanceled(true);
                    return;
                }
                final SPacketExplosion velocity2;
                final SPacketExplosion sPacketExplosion7;
                final SPacketExplosion sPacketExplosion4 = sPacketExplosion7 = (velocity2 = event.getPacket());
                sPacketExplosion7.field_149152_f *= this.horizontal.getCurrentState();
                final SPacketExplosion sPacketExplosion8;
                final SPacketExplosion sPacketExplosion5 = sPacketExplosion8 = velocity2;
                sPacketExplosion8.field_149153_g *= this.vertical.getCurrentState();
                final SPacketExplosion sPacketExplosion9;
                final SPacketExplosion sPacketExplosion6 = sPacketExplosion9 = velocity2;
                sPacketExplosion9.field_149159_h *= this.horizontal.getCurrentState();
            }
        }
    }
    
    @SubscribeEvent
    public void onPush(final PushEvent event) {
        if (event.getStage() == 1 && this.blocks.getCurrentState()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onEntityCollision(final EntityCollisionEvent event) {
        if (this.noPush.getCurrentState()) {
            event.setCanceled(true);
        }
    }
}
