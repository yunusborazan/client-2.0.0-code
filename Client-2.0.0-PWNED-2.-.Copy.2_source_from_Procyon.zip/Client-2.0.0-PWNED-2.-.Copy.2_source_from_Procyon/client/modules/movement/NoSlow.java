// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.client.gui.GuiChat;
import client.events.KeyEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.MovementInput;
import net.minecraftforge.client.event.InputUpdateEvent;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.settings.KeyBinding;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class NoSlow extends Module
{
    private static NoSlow INSTANCE;
    public Setting<Boolean> items;
    public Setting<Boolean> guiMove;
    public Setting<Boolean> webs;
    private static final KeyBinding[] keys;
    
    public NoSlow() {
        super("NoSlow", "Stops packets that slow you down", Category.MOVEMENT);
        this.items = (Setting<Boolean>)this.register(new Setting("Items", (T)false));
        this.guiMove = (Setting<Boolean>)this.register(new Setting("Inventory", (T)false));
        this.webs = (Setting<Boolean>)this.register(new Setting("Webs", (T)false));
        this.setInstance();
    }
    
    public static NoSlow getInstance() {
        if (NoSlow.INSTANCE == null) {
            NoSlow.INSTANCE = new NoSlow();
        }
        return NoSlow.INSTANCE;
    }
    
    private void setInstance() {
        NoSlow.INSTANCE = this;
    }
    
    @Override
    public void onLogin() {
        if (this.isEnabled()) {
            this.disable();
            this.enable();
        }
    }
    
    @Override
    public void onUpdate() {
        if (this.guiMove.getCurrentState()) {
            if (NoSlow.mc.field_71462_r instanceof GuiOptions || NoSlow.mc.field_71462_r instanceof GuiVideoSettings || NoSlow.mc.field_71462_r instanceof GuiScreenOptionsSounds || NoSlow.mc.field_71462_r instanceof GuiContainer || NoSlow.mc.field_71462_r instanceof GuiIngameMenu) {
                for (final KeyBinding bind : NoSlow.keys) {
                    KeyBinding.func_74510_a(bind.func_151463_i(), Keyboard.isKeyDown(bind.func_151463_i()));
                }
            }
            else if (NoSlow.mc.field_71462_r == null) {
                for (final KeyBinding bind : NoSlow.keys) {
                    if (!Keyboard.isKeyDown(bind.func_151463_i())) {
                        KeyBinding.func_74510_a(bind.func_151463_i(), false);
                    }
                }
            }
        }
        if (this.webs.getCurrentState() && NoSlow.mc.field_71439_g.field_70134_J) {
            NoSlow.mc.field_71439_g.field_70134_J = false;
        }
    }
    
    @SubscribeEvent
    public void onItemEat(final InputUpdateEvent event) {
        if (this.items.getCurrentState() && NoSlow.mc.field_71439_g.func_184587_cr()) {
            final MovementInput movementInput = event.getMovementInput();
            movementInput.field_78902_a *= 5.0f;
            final MovementInput movementInput2 = event.getMovementInput();
            movementInput2.field_192832_b *= 5.0f;
        }
    }
    
    @SubscribeEvent
    public void onKeyEvent(final KeyEvent event) {
        if (this.guiMove.getCurrentState() && event.getStage() == 0 && !(NoSlow.mc.field_71462_r instanceof GuiChat)) {
            event.info = event.pressed;
        }
    }
    
    static {
        NoSlow.INSTANCE = new NoSlow();
        keys = new KeyBinding[] { NoSlow.mc.field_71474_y.field_74351_w, NoSlow.mc.field_71474_y.field_74368_y, NoSlow.mc.field_71474_y.field_74370_x, NoSlow.mc.field_71474_y.field_74366_z, NoSlow.mc.field_71474_y.field_74314_A, NoSlow.mc.field_71474_y.field_151444_V };
    }
}
