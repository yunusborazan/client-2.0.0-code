// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import client.util.Timer;
import client.modules.Module;

public class NoFall extends Module
{
    Timer timer;
    
    public NoFall() {
        super("NoFall", "", Category.MOVEMENT);
        this.timer = new Timer();
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        this.timer.setCurrentMS();
        if (NoFall.mc.field_71439_g.field_70143_R > 4.0f && this.timer.hasDelayRun(800L)) {
            final CPacketPlayer.Position outOfBoundsPosition = new CPacketPlayer.Position(NoFall.mc.field_71439_g.field_70165_t, NoFall.mc.field_71439_g.field_70163_u - 420.69, NoFall.mc.field_71439_g.field_70161_v, NoFall.mc.field_71439_g.field_70122_E);
            NoFall.mc.field_71439_g.field_71174_a.func_147297_a((Packet)outOfBoundsPosition);
            NoFall.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketConfirmTeleport());
            NoFall.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.PositionRotation(NoFall.mc.field_71439_g.field_70165_t + NoFall.mc.field_71439_g.field_70159_w, NoFall.mc.field_71439_g.field_70163_u + 0.0622, NoFall.mc.field_71439_g.field_70161_v + NoFall.mc.field_71439_g.field_70179_y, NoFall.mc.field_71439_g.field_70177_z, NoFall.mc.field_71439_g.field_70125_A, false));
            NoFall.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.PositionRotation(NoFall.mc.field_71439_g.field_70165_t + NoFall.mc.field_71439_g.field_70159_w, NoFall.mc.field_71439_g.field_70163_u - 420.69, NoFall.mc.field_71439_g.field_70161_v + NoFall.mc.field_71439_g.field_70179_y, NoFall.mc.field_71439_g.field_70177_z, NoFall.mc.field_71439_g.field_70125_A, true));
            this.timer.setLastMS();
        }
    }
}
