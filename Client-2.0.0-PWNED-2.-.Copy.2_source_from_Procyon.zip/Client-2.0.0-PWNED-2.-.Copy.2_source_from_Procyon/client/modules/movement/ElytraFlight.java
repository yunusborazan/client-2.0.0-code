// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import client.modules.Feature;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import client.events.UpdateWalkingPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.util.PlayerUtil;
import client.events.MoveEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class ElytraFlight extends Module
{
    public Setting<Double> speed;
    public Setting<Double> speedDown;
    
    public ElytraFlight() {
        super("ElytraFlight", "Allows travel with Elytras to be more easy.", Category.MOVEMENT);
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)1.0, (T)0.1, (T)10.0));
        this.speedDown = (Setting<Double>)this.register(new Setting("SpeedDown", (T)1.0, (T)0.1, (T)10.0));
    }
    
    @SubscribeEvent
    public void onMove(final MoveEvent event) {
        if (!ElytraFlight.mc.field_71439_g.func_184613_cA()) {
            return;
        }
        if (!ElytraFlight.mc.field_71439_g.field_71158_b.field_78901_c) {
            if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78899_d) {
                ElytraFlight.mc.field_71439_g.field_70181_x = -this.speedDown.getCurrentState();
            }
            else if (event.getY() != -1.01E-4) {
                event.setY(-1.01E-4);
                ElytraFlight.mc.field_71439_g.field_70181_x = -1.01E-4;
            }
            PlayerUtil.setMoveSpeed(event, this.speed.getCurrentState());
        }
    }
    
    @Override
    public void onTick() {
        if (!ElytraFlight.mc.field_71439_g.func_184613_cA()) {
            return;
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent event) {
        if (ElytraFlight.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() != Items.field_185160_cR) {
            return;
        }
    }
    
    @Override
    public void onLogin() {
        if (this.isEnabled()) {
            this.disable();
            this.enable();
        }
    }
    
    @Override
    public void onDisable() {
        if (Feature.fullNullCheck() || ElytraFlight.mc.field_71439_g.field_71075_bZ.field_75098_d) {
            return;
        }
        ElytraFlight.mc.field_71439_g.field_71075_bZ.field_75100_b = false;
    }
}
