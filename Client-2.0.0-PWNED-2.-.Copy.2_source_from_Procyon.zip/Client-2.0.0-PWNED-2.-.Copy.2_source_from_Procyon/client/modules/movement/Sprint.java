// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import client.modules.Feature;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.events.MoveEvent;
import client.modules.Module;

public class Sprint extends Module
{
    private static Sprint INSTANCE;
    
    public Sprint() {
        super("Sprint", "Modifies sprinting", Category.MOVEMENT);
        this.setInstance();
    }
    
    private void setInstance() {
        Sprint.INSTANCE = this;
    }
    
    public static Sprint getInstance() {
        if (Sprint.INSTANCE == null) {
            Sprint.INSTANCE = new Sprint();
        }
        return Sprint.INSTANCE;
    }
    
    @SubscribeEvent
    public void onSprint(final MoveEvent event) {
        if (event.getStage() == 1 || Sprint.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f) {
            event.setCanceled(true);
        }
    }
    
    @Override
    public void onUpdate() {
        if ((!Sprint.mc.field_71474_y.field_74351_w.func_151470_d() && !Sprint.mc.field_71474_y.field_74368_y.func_151470_d() && !Sprint.mc.field_71474_y.field_74370_x.func_151470_d() && !Sprint.mc.field_71474_y.field_74366_z.func_151470_d()) || Sprint.mc.field_71439_g.func_70093_af() || Sprint.mc.field_71439_g.field_70123_F || Sprint.mc.field_71439_g.func_71024_bL().func_75116_a() <= 6.0f) {
            return;
        }
        Sprint.mc.field_71439_g.func_70031_b(true);
    }
    
    @Override
    public void onDisable() {
        if (!Feature.nullCheck()) {
            Sprint.mc.field_71439_g.func_70031_b(false);
        }
    }
    
    @Override
    public String getDisplayInfo() {
        if ((!Sprint.mc.field_71474_y.field_74351_w.func_151470_d() && !Sprint.mc.field_71474_y.field_74368_y.func_151470_d() && !Sprint.mc.field_71474_y.field_74370_x.func_151470_d() && !Sprint.mc.field_71474_y.field_74366_z.func_151470_d()) || Sprint.mc.field_71439_g.func_70093_af() || Sprint.mc.field_71439_g.field_70123_F || Sprint.mc.field_71439_g.func_71024_bL().func_75116_a() <= 6.0f) {
            return null;
        }
        return "Sprinting";
    }
    
    static {
        Sprint.INSTANCE = new Sprint();
    }
}
