// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.util.MovementInput;
import client.modules.Feature;
import client.events.MoveEvent;
import client.events.ClientEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import client.util.EntityUtil;
import client.events.WalkEvent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import com.mojang.realmsclient.gui.ChatFormatting;
import client.Client;
import org.lwjgl.input.Keyboard;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Strafe extends Module
{
    private static Strafe INSTANCE;
    private int delay;
    private boolean preMotion;
    private double motion;
    public boolean antiShake;
    public boolean changeY;
    public double minY;
    public Setting<Mode> mode;
    public Setting<Bind> switchBind;
    
    public Strafe() {
        super("Strafe", "", Category.MOVEMENT);
        this.antiShake = false;
        this.changeY = false;
        this.minY = 0.0;
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.STRAFE));
        this.switchBind = (Setting<Bind>)this.register(new Setting("SwitchBind", (T)new Bind(-1)));
        this.setInstance();
    }
    
    public static Strafe getInstance() {
        if (Strafe.INSTANCE == null) {
            Strafe.INSTANCE = new Strafe();
        }
        return Strafe.INSTANCE;
    }
    
    private void setInstance() {
        Strafe.INSTANCE = this;
    }
    
    @Override
    public void onEnable() {
        this.motion = 0.0;
    }
    
    @Override
    public void onTick() {
        if (this.delay < 12) {
            ++this.delay;
        }
        if (this.delay > 10 && this.switchBind.getCurrentState().getKey() > -1 && Keyboard.isKeyDown(this.switchBind.getCurrentState().getKey())) {
            if (this.mode.getCurrentState() == Mode.INSTANT) {
                this.mode.setValue(Mode.STRAFE);
                Strafe.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(Client.commandManager.getClientMessage() + ChatFormatting.BOLD + " Strafe: " + ChatFormatting.GRAY + "Mode set to: " + ChatFormatting.RED + ChatFormatting.BOLD + "Strafe"), 1);
                this.delay = 0;
            }
            else if (this.mode.getCurrentState() == Mode.STRAFE) {
                this.mode.setValue(Mode.INSTANT);
                Strafe.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(Client.commandManager.getClientMessage() + ChatFormatting.BOLD + " Strafe: " + ChatFormatting.GRAY + "Mode set to: " + ChatFormatting.RED + ChatFormatting.BOLD + "Instant"), 1);
                this.delay = 0;
            }
        }
    }
    
    @SubscribeEvent
    public void onMove(final WalkEvent event) {
        if (this.mode.getCurrentState() == Mode.STRAFE) {
            if (!EntityUtil.onMovementInput()) {
                this.motion = EntityUtil.getMovementSpeed();
                event.setMotionX(0.0);
                event.setMotionZ(0.0);
                return;
            }
            if (Strafe.mc.field_71439_g.field_70122_E) {
                this.motion *= 1.57;
                event.setMotionY(Strafe.mc.field_71439_g.field_70181_x = 0.412);
            }
            else {
                this.motion = (this.preMotion ? (this.motion -= 0.66 * (this.motion - EntityUtil.getMovementSpeed())) : (this.motion -= this.motion / 159.0));
            }
            this.preMotion = Strafe.mc.field_71439_g.field_70122_E;
            this.motion = Math.max(this.motion, EntityUtil.getMovementSpeed());
            this.motion = Math.min(this.motion, 0.547);
            event.setMotionX(Strafe.mc.field_71439_g.field_70159_w = -(Math.sin(EntityUtil.getDirection()) * this.motion));
            event.setMotionZ(Strafe.mc.field_71439_g.field_70179_y = Math.cos(EntityUtil.getDirection()) * this.motion);
        }
    }
    
    @Override
    public void onUpdate() {
        if (Strafe.mc.field_71439_g.func_70093_af() || Strafe.mc.field_71439_g.func_70090_H() || Strafe.mc.field_71439_g.func_180799_ab() || (!Strafe.mc.field_71439_g.field_70122_E && this.mode.getCurrentState() == Mode.INSTANT)) {
            return;
        }
    }
    
    @Override
    public void onDisable() {
        this.changeY = false;
        this.antiShake = false;
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2) {
            Strafe.mc.field_71439_g.field_70181_x = -0.1;
        }
    }
    
    @SubscribeEvent
    public void onMode(final MoveEvent event) {
        if (this.mode.getCurrentState() == Mode.INSTANT && ((event.getStage() == 0 && !Feature.nullCheck() && !Strafe.mc.field_71439_g.func_70093_af() && !Strafe.mc.field_71439_g.func_70090_H() && !Strafe.mc.field_71439_g.func_180799_ab() && (Strafe.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || Strafe.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f)) || !Strafe.mc.field_71439_g.field_70122_E)) {
            final MovementInput movementInput = Strafe.mc.field_71439_g.field_71158_b;
            float moveForward = movementInput.field_192832_b;
            float moveStrafe = movementInput.field_78902_a;
            float rotationYaw = Strafe.mc.field_71439_g.field_70177_z;
            if (moveForward == 0.0 && moveStrafe == 0.0) {
                event.setX(0.0);
                event.setZ(0.0);
            }
            else {
                if (moveForward != 0.0) {
                    if (moveStrafe > 0.0) {
                        rotationYaw += ((moveForward > 0.0) ? -45 : 45);
                    }
                    else if (moveStrafe < 0.0) {
                        rotationYaw += ((moveForward > 0.0) ? 45 : -45);
                    }
                    moveStrafe = 0.0f;
                    if (moveForward != 0.0f) {
                        moveForward = ((moveForward > 0.0) ? 1.0f : -1.0f);
                    }
                }
                moveStrafe = ((moveStrafe == 0.0f) ? moveStrafe : ((moveStrafe > 0.0) ? 1.0f : -1.0f));
                event.setX(moveForward * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians(rotationYaw + 90.0f)) + moveStrafe * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians(rotationYaw + 90.0f)));
                event.setZ(moveForward * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians(rotationYaw + 90.0f)) - moveStrafe * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians(rotationYaw + 90.0f)));
            }
        }
    }
    
    static {
        Strafe.INSTANCE = new Strafe();
    }
    
    public enum Mode
    {
        STRAFE, 
        INSTANT;
    }
}
