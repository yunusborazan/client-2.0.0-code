// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.block.material.Material;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Step extends Module
{
    public Setting<Boolean> vanilla;
    public Setting<Integer> stepHeight;
    private final double[] oneblockPositions;
    private final double[] twoblockPositions;
    private final double[] futurePositions;
    final double[] twoFiveOffset;
    private final double[] fourBlockPositions;
    private double[] selectedPositions;
    private int packets;
    private static Step instance;
    
    public Step() {
        super("Step", "Step up yo mam", Category.MOVEMENT);
        this.vanilla = (Setting<Boolean>)this.register(new Setting("Vanilla", (T)false));
        this.stepHeight = (Setting<Integer>)this.register(new Setting("Height", (T)2, (T)1, (T)4, v -> !this.vanilla.getCurrentState()));
        this.oneblockPositions = new double[] { 0.42, 0.75 };
        this.twoblockPositions = new double[] { 0.4, 0.75, 0.5, 0.41, 0.83, 1.16, 1.41, 1.57, 1.58, 1.42 };
        this.futurePositions = new double[] { 0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43 };
        this.twoFiveOffset = new double[] { 0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.907 };
        this.fourBlockPositions = new double[] { 0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43, 1.78, 1.63, 1.51, 1.9, 2.21, 2.45, 2.43, 2.78, 2.63, 2.51, 2.9, 3.21, 3.45, 3.43 };
        this.selectedPositions = new double[0];
        Step.instance = this;
    }
    
    public static Step getInstance() {
        if (Step.instance == null) {
            Step.instance = new Step();
        }
        return Step.instance;
    }
    
    @Override
    public void onToggle() {
        Step.mc.field_71439_g.field_70138_W = 0.6f;
    }
    
    @Override
    public void onUpdate() {
        if (this.vanilla.getCurrentState()) {
            Step.mc.field_71439_g.field_70138_W = this.stepHeight.getCurrentState();
            return;
        }
        switch (this.stepHeight.getCurrentState()) {
            case 1: {
                this.selectedPositions = this.oneblockPositions;
                break;
            }
            case 2: {
                this.selectedPositions = this.futurePositions;
                break;
            }
            case 3: {
                this.selectedPositions = this.twoFiveOffset;
            }
            case 4: {
                this.selectedPositions = this.fourBlockPositions;
                break;
            }
        }
        if (Step.mc.field_71439_g.field_70123_F && Step.mc.field_71439_g.field_70122_E) {
            ++this.packets;
        }
        if (Step.mc.field_71439_g.field_70122_E && !Step.mc.field_71439_g.func_70055_a(Material.field_151586_h) && !Step.mc.field_71439_g.func_70055_a(Material.field_151587_i) && Step.mc.field_71439_g.field_70124_G && Step.mc.field_71439_g.field_70143_R == 0.0f && !Step.mc.field_71474_y.field_74314_A.field_74513_e && Step.mc.field_71439_g.field_70123_F && !Step.mc.field_71439_g.func_70617_f_() && (this.packets > this.selectedPositions.length - 2 || this.packets > 0)) {
            for (final double position : this.selectedPositions) {
                Step.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + position, Step.mc.field_71439_g.field_70161_v, true));
            }
            Step.mc.field_71439_g.func_70107_b(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + this.selectedPositions[this.selectedPositions.length - 1], Step.mc.field_71439_g.field_70161_v);
            this.packets = 0;
        }
    }
    
    @Override
    public String getDisplayInfo() {
        if (this.vanilla.getCurrentState()) {
            return "Vanilla";
        }
        return "NCP";
    }
}
