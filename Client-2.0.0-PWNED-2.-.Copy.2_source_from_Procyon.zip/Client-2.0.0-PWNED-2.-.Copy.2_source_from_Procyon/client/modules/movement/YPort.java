// 
// Decompiled by Procyon v0.5.36
// 

package client.modules.movement;

import net.minecraft.entity.EntityLivingBase;
import client.Client;
import client.util.EntityUtil;
import client.util.Timer;
import client.gui.impl.setting.Setting;
import client.modules.Module;

public class YPort extends Module
{
    private final Setting<Double> speed;
    public Setting<String> futurePrefix;
    private final Timer timer;
    
    public YPort() {
        super("Longjump", "Terrible rip off longjump", Category.MOVEMENT);
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)0.1, (T)0.0, (T)1.0));
        this.futurePrefix = (Setting<String>)this.register(new Setting("FuturePrefix", (T)"."));
        this.timer = new Timer();
    }
    
    @Override
    public void onDisable() {
        this.timer.reset();
        EntityUtil.resetTimer();
    }
    
    @Override
    public void onUpdate() {
        if (YPort.mc.field_71439_g.func_70093_af() || YPort.mc.field_71439_g.func_70090_H() || YPort.mc.field_71439_g.func_180799_ab() || YPort.mc.field_71439_g.func_70617_f_() || Client.moduleManager.isModuleEnabled("Strafe")) {
            return;
        }
        if (YPort.mc.field_71439_g == null || YPort.mc.field_71441_e == null) {
            this.disable();
            return;
        }
        this.handleYPortSpeed();
        if (Step.mc.field_71439_g.field_70123_F && Step.mc.field_71439_g.field_70122_E) {
            this.disable();
            YPort.mc.field_71439_g.func_71165_d(this.futurePrefix.getCurrentState() + "toggle Speed");
            Step.getInstance().enable();
        }
    }
    
    @Override
    public void onToggle() {
        YPort.mc.field_71439_g.field_70181_x = -3.0;
        YPort.mc.field_71439_g.field_70138_W = 0.6f;
    }
    
    private void handleYPortSpeed() {
        if (!EntityUtil.isMoving((EntityLivingBase)YPort.mc.field_71439_g) || (YPort.mc.field_71439_g.func_70090_H() && YPort.mc.field_71439_g.func_180799_ab()) || YPort.mc.field_71439_g.field_70123_F) {
            return;
        }
        if (YPort.mc.field_71439_g.field_70122_E) {
            YPort.mc.field_71439_g.func_70664_aZ();
            EntityUtil.setSpeed((EntityLivingBase)YPort.mc.field_71439_g, EntityUtil.getBaseMoveSpeed() + this.speed.getCurrentState());
        }
        else {
            YPort.mc.field_71439_g.field_70181_x = -1.0;
        }
    }
}
