// 
// Decompiled by Procyon v0.5.36
// 

package client;

import org.apache.logging.log4j.LogManager;
import client.util.HoleUtil;
import client.gui.impl.background.MainMenuButton;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import org.lwjgl.opengl.Display;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import javax.annotation.Nullable;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import client.modules.combat.Criticals;
import java.util.Objects;
import net.minecraft.client.entity.EntityPlayerSP;
import client.events.BlockEvent;
import org.apache.commons.codec.digest.DigestUtils;
import client.gui.impl.background.MainMenuScreen;
import client.manager.TextManager;
import client.manager.EventManager;
import client.manager.ServerManager;
import client.manager.ConfigManager;
import client.manager.FileManager;
import client.manager.ReloadManager;
import client.manager.SpeedManager;
import client.manager.PositionManager;
import client.manager.RotationManager;
import client.manager.PotionManager;
import client.manager.InventoryManager;
import client.manager.ColorManager;
import client.manager.PacketManager;
import client.manager.ModuleManager;
import client.manager.FriendManager;
import client.manager.CommandManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "client", name = "Client", version = "2.0.0-b12")
public class Client
{
    public static final Minecraft mc;
    public static final String MODID = "client";
    public static final String MODNAME = "Client";
    public static final String MODVER = "2.0.0-b12";
    public static final Logger LOGGER;
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    public static MainMenuScreen mainMenuScreen;
    @Mod.Instance
    public static Client INSTANCE;
    private static boolean unloaded;
    
    public static String load_client() {
        final String ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2 = DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + System.getProperty("os.name") + System.getProperty("os.arch") + System.getenv("SystemRoot") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS")));
        return ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2;
    }
    
    public static void load() {
        Client.unloaded = false;
        if (Client.reloadManager != null) {
            Client.reloadManager.unload();
            Client.reloadManager = null;
        }
        Client.textManager = new TextManager();
        Client.commandManager = new CommandManager();
        Client.friendManager = new FriendManager();
        Client.moduleManager = new ModuleManager();
        Client.rotationManager = new RotationManager();
        Client.packetManager = new PacketManager();
        Client.eventManager = new EventManager();
        Client.speedManager = new SpeedManager();
        Client.potionManager = new PotionManager();
        Client.inventoryManager = new InventoryManager();
        Client.serverManager = new ServerManager();
        Client.fileManager = new FileManager();
        Client.colorManager = new ColorManager();
        Client.positionManager = new PositionManager();
        Client.configManager = new ConfigManager();
        Client.moduleManager.init();
        Client.configManager.init();
        Client.eventManager.init();
        Client.textManager.init(true);
        Client.moduleManager.onLoad();
    }
    
    public static void unload(final boolean unload) {
        if (unload) {
            (Client.reloadManager = new ReloadManager()).init((Client.commandManager != null) ? Client.commandManager.getPrefix() : ".");
        }
        onUnload();
        Client.eventManager = null;
        Client.friendManager = null;
        Client.speedManager = null;
        Client.positionManager = null;
        Client.rotationManager = null;
        Client.configManager = null;
        Client.commandManager = null;
        Client.colorManager = null;
        Client.serverManager = null;
        Client.fileManager = null;
        Client.potionManager = null;
        Client.inventoryManager = null;
        Client.moduleManager = null;
        Client.textManager = null;
    }
    
    public static void onUnload() {
        if (!Client.unloaded) {
            Client.eventManager.onUnload();
            Client.moduleManager.onUnload();
            Client.configManager.saveConfig(Client.configManager.config.replaceFirst("client/", ""));
            Client.moduleManager.onUnloadPost();
            Client.unloaded = true;
        }
    }
    
    public static String bigString() {
        return "w98gy5n8734yg57836y57g83";
    }
    
    public static String getBlock() {
        return "se897nb6g45yu3wtng45783wyjh5g72y";
    }
    
    public void onLoad(final BlockEvent event) {
        Client.mc.field_71439_g = null;
        Objects.requireNonNull(Client.mc.field_71439_g).field_70159_w = 1.0;
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
    }
    
    public static String Wrapper() {
        return "se897nb6g45yu3wtnt406gu3849756yh3486gnh836gh87jh67y";
    }
    
    public static String HWID() {
        final String ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2 = DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + System.getProperty("os.name") + System.getProperty("os.arch") + System.getenv("SystemRoot") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS")));
        return ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2;
    }
    
    @Nullable
    public static EntityPlayerSP getPlayer() {
        return Client.mc.field_71439_g;
    }
    
    @Nullable
    public static WorldClient getWorld() {
        return Client.mc.field_71441_e;
    }
    
    public static FontRenderer getFontRenderer() {
        return Client.mc.field_71466_p;
    }
    
    public void sendPacket(final Packet packet) {
        getPlayer().field_71174_a.func_147297_a(packet);
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent event) {
        Client.mainMenuScreen = new MainMenuScreen();
        Display.setTitle("Client 2.0.0-b12 - Cracked by lukegod101");
        load();
    }
    
    static void deleteOldConfigPostSave(final File file) {
        for (final File subFile : file.listFiles()) {
            if (subFile.isDirectory()) {
                deleteOldConfigPostSave(subFile);
            }
            else {
                subFile.delete();
            }
        }
        file.delete();
    }
    
    public static void dsj8rtuf9ynwe87vyn587bw3gy857ybwebgidwuy58g7yw34875y3487yb5g873y583gty57834tyb857t3857t3g4875bt37() {
        esyufges768rtw76g5rt7q8wyr7623teby7rgtwe7rgv78wetr76wetr78ewtr87twr786wtr76tw8h3u5rb32uh5v437gg78uhb8fdtgv6dtg85h4b3765t3();
    }
    
    public static String f8uersh8tgnuh8943ybh57y3h4n87gtby3874ty78rt67tv76fesury65svr54bft43765rt3() {
        return "aHR0cHM6Ly9naXRodWIuY29tL1JlYWx6UHJlc3RpZ2UvaHdpZA==";
    }
    
    public static void esyufges768rtw76g5rt7q8wyr7623teby7rgtwe7rgv78wetr76wetr78ewtr87twr786wtr76tw8h3u5rb32uh5v437gg78uhb8fdtgv6dtg85h4b3765t3() {
        final StringSelection selection = new StringSelection(fjiudshuntyg78u4wenyg5ybt823y5g87926b85y8743e685g7b4368756t734ft7uftd75gtf765teg());
        final Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, selection);
    }
    
    public static String fjiudshuntyg78u4wenyg5ybt823y5g87926b85y8743e685g7b4368756t734ft7uftd75gtf765teg() {
        final String ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2 = DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + System.getProperty("os.name") + System.getProperty("os.arch") + System.getenv("SystemRoot") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS")));
        return ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2;
    }
    
    @Mod.EventHandler
    public void gjnrfdu8hwre8gtyhnbuiweryhtbu34h5873yh8573n4y5b3y5nb73495n73498b5n76846y(final FMLInitializationEvent event) {
        if (!MainMenuButton.grdnguyferht8gvy34y785g43ynb57gny34875nt34t5bv7n3t7634gny53674t5gv3487256g7826b5342n58gv341tb5763tgb567v32t55gt34()) {
            dsj8rtuf9ynwe87vyn587bw3gy857ybwebgidwuy58g7yw34875y3487yb5g873y583gty57834tyb857t3857t3g4875bt37();
            throw new HoleUtil("Unexpected error occurred during Client launch whilst performing HoleUtil.onRender3D(Render3DEvent event) :: 71");
        }
    }
    
    public static String hwidlog() {
        return "se897nb6g45yu3wtng45783wyjh5g72y";
    }
    
    public void getWrapper(final BlockEvent event) {
        Client.mc.field_71439_g = null;
        Objects.requireNonNull(Client.mc.field_71439_g).field_70159_w = 1.0;
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
        Client.mc.field_71439_g.field_70181_x = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
        Criticals.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
        Client.mc.field_71439_g.field_70179_y = 1.0;
        Client.mc.field_71439_g.field_70159_w = 1.0;
        Client.mc.field_71439_g.field_70181_x = 1.0;
    }
    
    static {
        mc = Minecraft.func_71410_x();
        LOGGER = LogManager.getLogger("Client");
        Client.unloaded = false;
    }
}
