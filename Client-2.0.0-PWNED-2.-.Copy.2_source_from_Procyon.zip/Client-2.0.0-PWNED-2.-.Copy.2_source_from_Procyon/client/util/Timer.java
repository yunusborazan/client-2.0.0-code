// 
// Decompiled by Procyon v0.5.36
// 

package client.util;

import net.minecraft.client.Minecraft;

public class Timer implements Util
{
    private long time;
    public static final String tickLength;
    public static final String timer;
    private long currentMS;
    private long lastMS;
    private final long current;
    
    public void setCurrentMS() {
        this.currentMS = System.nanoTime() / 1000000L;
    }
    
    public boolean hasDelayRun(final long time) {
        return this.currentMS - this.lastMS >= time;
    }
    
    public void setLastMS() {
        this.lastMS = System.nanoTime() / 1000000L;
    }
    
    public boolean passedS(final double s) {
        return this.passedMs((long)s * 1000L);
    }
    
    public boolean passedDms(final double dms) {
        return this.passedMs((long)dms * 10L);
    }
    
    public boolean passedDs(final double ds) {
        return this.passedMs((long)ds * 100L);
    }
    
    public boolean passedMs(final long ms) {
        return this.passedNS(this.convertToNS(ms));
    }
    
    public void setMs(final long ms) {
        this.time = System.nanoTime() - this.convertToNS(ms);
    }
    
    public boolean passedNS(final long ns) {
        return System.nanoTime() - this.time >= ns;
    }
    
    public long getPassedTimeMs() {
        return this.getMs(System.nanoTime() - this.time);
    }
    
    public long getMs(final long time) {
        return time / 1000000L;
    }
    
    public long convertToNS(final long time) {
        return time * 1000000L;
    }
    
    public static boolean isObfuscated() {
        try {
            return Minecraft.class.getDeclaredField("instance") == null;
        }
        catch (Exception var1) {
            return true;
        }
    }
    
    public Timer() {
        this.time = -1L;
        this.currentMS = 0L;
        this.lastMS = -1L;
        this.current = -1L;
    }
    
    public final boolean hasReached(final long delay) {
        return System.currentTimeMillis() - this.current >= delay;
    }
    
    public boolean hasReached(final long delay, final boolean reset) {
        if (reset) {
            this.reset();
        }
        return System.currentTimeMillis() - this.current >= delay;
    }
    
    public long time() {
        return System.nanoTime() / 1000000L - this.current;
    }
    
    public Timer reset() {
        this.time = System.nanoTime();
        return this;
    }
    
    public boolean passed(final long time, final Format format) {
        switch (format) {
            default: {
                return this.getMS(System.nanoTime() - this.time) >= time;
            }
            case TICKS: {
                return Timer.mc.field_71439_g.field_70173_aa % (int)time == 0;
            }
        }
    }
    
    public long getMS(final long time) {
        return time / 1000000L;
    }
    
    public boolean passed(final long delay) {
        return System.currentTimeMillis() - this.current >= delay;
    }
    
    static {
        tickLength = (isObfuscated() ? "field_194149_e" : "tickLength");
        timer = (isObfuscated() ? "field_71428_T" : "timer");
    }
    
    public enum Format
    {
        SYSTEM, 
        TICKS;
    }
}
