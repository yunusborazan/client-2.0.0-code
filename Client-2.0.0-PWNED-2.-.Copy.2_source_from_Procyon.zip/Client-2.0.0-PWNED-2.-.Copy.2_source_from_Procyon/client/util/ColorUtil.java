// 
// Decompiled by Procyon v0.5.36
// 

package client.util;

import org.lwjgl.opengl.GL11;
import client.modules.client.Hud;
import client.modules.client.ClickGui;
import java.awt.Color;

public class ColorUtil
{
    private float hue;
    
    public static int toARGB(final int r, final int g, final int b, final int a) {
        return new Color(r, g, b, a).getRGB();
    }
    
    public static int toRGBA(final int r, final int g, final int b) {
        return toRGBA(r, g, b, 255);
    }
    
    public static int toRGBA(final int r, final int g, final int b, final int a) {
        return (r << 16) + (g << 8) + b + (a << 24);
    }
    
    public static Color rainbow(final int delay) {
        final double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        return Color.getHSBColor((float)(rainbowState % 360.0 / 360.0), ClickGui.getInstance().rainbowSaturation.getCurrentState() / 255.0f, ClickGui.getInstance().rainbowBrightness.getCurrentState() / 255.0f);
    }
    
    public static Color rainbowHighDelay(final int delay) {
        final double rainbowState = Math.ceil((System.currentTimeMillis() + delay * 100L) / 20.0);
        return Color.getHSBColor((float)(rainbowState % 360.0 / 360.0), ClickGui.getInstance().rainbowSaturation.getCurrentState() / 255.0f, ClickGui.getInstance().rainbowBrightness.getCurrentState() / 255.0f);
    }
    
    public static Color rainbowHud(final int delay) {
        final double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        return Color.getHSBColor((float)(rainbowState % 360.0 / 360.0), Hud.getInstance().rainbowSaturation.getCurrentState() / 255.0f, Hud.getInstance().rainbowBrightness.getCurrentState() / 255.0f);
    }
    
    public static int toRGBA(final Color color) {
        return toRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }
    
    public static int getRainbow(final int speed, final int offset, final float s, final float b) {
        float hue = (float)((System.currentTimeMillis() + offset) % speed);
        return Color.getHSBColor(hue /= speed, s, b).getRGB();
    }
    
    public static void setColor(final Color color) {
        GL11.glColor4d((double)(color.getRed() / 255.0f), (double)(color.getGreen() / 255.0f), (double)(color.getBlue() / 255.0f), (double)(color.getAlpha() / 255.0f));
    }
}
