// 
// Decompiled by Procyon v0.5.36
// 

package client.util;

import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.RenderGlobal;
import java.util.Objects;
import net.minecraft.entity.Entity;
import client.Client;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;
import java.awt.Color;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;

public class RenderUtil implements Util
{
    public static Tessellator tessellator;
    public static RenderItem itemRender;
    public static ICamera camera;
    
    public static void drawFilledBox(final AxisAlignedBB bb, final int color) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(770, 771, 0, 1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        final float alpha = (color >> 24 & 0xFF) / 255.0f;
        final float red = (color >> 16 & 0xFF) / 255.0f;
        final float green = (color >> 8 & 0xFF) / 255.0f;
        final float blue = (color & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }
    
    public static AxisAlignedBB interpolateAxis(final AxisAlignedBB bb) {
        return new AxisAlignedBB(bb.field_72340_a - RenderUtil.mc.func_175598_ae().field_78730_l, bb.field_72338_b - RenderUtil.mc.func_175598_ae().field_78731_m, bb.field_72339_c - RenderUtil.mc.func_175598_ae().field_78728_n, bb.field_72336_d - RenderUtil.mc.func_175598_ae().field_78730_l, bb.field_72337_e - RenderUtil.mc.func_175598_ae().field_78731_m, bb.field_72334_f - RenderUtil.mc.func_175598_ae().field_78728_n);
    }
    
    public static double interpolate(final double previous, final double current, final float partialTicks) {
        return previous + (current - previous) * partialTicks;
    }
    
    public static void drawTexturedRect(final int x, final int y, final int textureX, final int textureY, final int width, final int height, final int zLevel) {
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder BufferBuilder2 = tessellator.func_178180_c();
        BufferBuilder2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        BufferBuilder2.func_181662_b((double)x, (double)(y + height), (double)zLevel).func_187315_a((double)(textureX * 0.00390625f), (double)((textureY + height) * 0.00390625f)).func_181675_d();
        BufferBuilder2.func_181662_b((double)(x + width), (double)(y + height), (double)zLevel).func_187315_a((double)((textureX + width) * 0.00390625f), (double)((textureY + height) * 0.00390625f)).func_181675_d();
        BufferBuilder2.func_181662_b((double)(x + width), (double)y, (double)zLevel).func_187315_a((double)((textureX + width) * 0.00390625f), (double)(textureY * 0.00390625f)).func_181675_d();
        BufferBuilder2.func_181662_b((double)x, (double)y, (double)zLevel).func_187315_a((double)(textureX * 0.00390625f), (double)(textureY * 0.00390625f)).func_181675_d();
        tessellator.func_78381_a();
    }
    
    public static void drawRoundedRect(double x, double y, double width, double height, final double radius, final Color color) {
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        x *= 2.0;
        y *= 2.0;
        width *= 2.0;
        height *= 2.0;
        width += x;
        height += y;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glEnable(2848);
        GL11.glBegin(9);
        for (int i = 0; i <= 90; ++i) {
            GL11.glVertex2d(x + radius + Math.sin(i * 3.141592653589793 / 180.0) * radius * -1.0, y + radius + Math.cos(i * 3.141592653589793 / 180.0) * radius * -1.0);
        }
        for (int i = 90; i <= 180; ++i) {
            GL11.glVertex2d(x + radius + Math.sin(i * 3.141592653589793 / 180.0) * radius * -1.0, height - radius + Math.cos(i * 3.141592653589793 / 180.0) * radius * -1.0);
        }
        for (int i = 0; i <= 90; ++i) {
            GL11.glVertex2d(width - radius + Math.sin(i * 3.141592653589793 / 180.0) * radius, height - radius + Math.cos(i * 3.141592653589793 / 180.0) * radius);
        }
        for (int i = 90; i <= 180; ++i) {
            GL11.glVertex2d(width - radius + Math.sin(i * 3.141592653589793 / 180.0) * radius, y + radius + Math.cos(i * 3.141592653589793 / 180.0) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2.0, 2.0, 2.0);
        GL11.glPopAttrib();
    }
    
    public static void drawBottomRoundedRect(double x, double y, double width, double height, final double radius, final Color color) {
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        x *= 2.0;
        y *= 2.0;
        width *= 2.0;
        height *= 2.0;
        width += x;
        height += y;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glEnable(2848);
        GL11.glBegin(9);
        for (int i = 90; i <= 180; ++i) {
            GL11.glVertex2d(x + radius + Math.sin(i * 3.141592653589793 / 180.0) * radius * -1.0, height - radius + Math.cos(i * 3.141592653589793 / 180.0) * radius * -1.0);
        }
        for (int i = 0; i <= 90; ++i) {
            GL11.glVertex2d(width - radius + Math.sin(i * 3.141592653589793 / 180.0) * radius, height - radius + Math.cos(i * 3.141592653589793 / 180.0) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2.0, 2.0, 2.0);
        GL11.glPopAttrib();
    }
    
    public static void drawTopRoundedRect(double x, double y, double width, double height, final double radius, final Color color) {
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        x *= 2.0;
        y *= 2.0;
        width *= 2.0;
        height *= 2.0;
        width += x;
        height += y;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glEnable(2848);
        GL11.glBegin(9);
        for (int i = 0; i <= 90; ++i) {
            GL11.glVertex2d(x + radius + Math.sin(i * 3.141592653589793 / 180.0) * radius * -1.0, y + radius + Math.cos(i * 3.141592653589793 / 180.0) * radius * -1.0);
        }
        for (int i = 90; i <= 180; ++i) {
            GL11.glVertex2d(x + 1.0 + Math.sin(i * 3.141592653589793 / 180.0) * -1.0, height - 1.0 + Math.cos(i * 3.141592653589793 / 180.0) * -1.0);
        }
        for (int i = 0; i <= 90; ++i) {
            GL11.glVertex2d(width - 1.0 + Math.sin(i * 3.141592653589793 / 180.0), height - 1.0 + Math.cos(i * 3.141592653589793 / 180.0));
        }
        for (int i = 90; i <= 180; ++i) {
            GL11.glVertex2d(width - radius + Math.sin(i * 3.141592653589793 / 180.0) * radius, y + radius + Math.cos(i * 3.141592653589793 / 180.0) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2.0, 2.0, 2.0);
        GL11.glPopAttrib();
    }
    
    public static void drawClawBox(final BlockPos blockPos, final double height, final double length, final double width, final Color color) {
        final BufferBuilder buffer = RenderUtil.tessellator.func_178180_c();
        buffer.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        addChainedClawBoxVertices(buffer, blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), blockPos.func_177958_n() + length, blockPos.func_177956_o() + height, blockPos.func_177952_p() + width, color);
        RenderUtil.tessellator.func_78381_a();
    }
    
    public static void addChainedClawBoxVertices(final BufferBuilder buffer, final double minX, final double minY, final double minZ, final double maxX, final double maxY, final double maxZ, final Color color) {
        buffer.func_181662_b(minX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, minY, maxZ - 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, minY, minZ + 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, minY, maxZ - 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, minY, minZ + 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX - 0.8, minY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX - 0.8, minY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX + 0.8, minY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX + 0.8, minY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, minY + 0.2, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, minY + 0.2, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, minY + 0.2, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, minY + 0.2, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, maxY, maxZ - 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, maxY, minZ + 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, maxY, maxZ - 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, maxY, minZ + 0.8).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX - 0.8, maxY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX - 0.8, maxY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX + 0.8, maxY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX + 0.8, maxY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, maxY - 0.2, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(minX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(minX, maxY - 0.2, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, maxY - 0.2, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
        buffer.func_181662_b(maxX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0f).func_181675_d();
        buffer.func_181662_b(maxX, maxY - 0.2, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
    }
    
    public static void drawRoundedRect(final int x, final int y, final int width, final int height, final int color, final int radius) {
        drawRect((float)x, (float)(y + radius), (float)(x + width), (float)(y + height - radius), color);
        drawRect((float)(x + radius), (float)y, (float)(x + width - radius), (float)(y + radius), color);
        drawRect((float)(x + radius), (float)(y + height - radius), (float)(x + width - radius), (float)(y + height), color);
        drawFilledCircle(x + radius, y + radius, radius, color);
        drawFilledCircle(x + width - radius, y + radius, radius, color);
        drawFilledCircle(x + radius, y + height - radius, radius, color);
        drawFilledCircle(x + width - radius, y + height - radius, radius, color);
    }
    
    public static void drawFilledCircle(final int x, final int y, final double radius, final int color) {
        GL11.glDisable(3042);
        GL11.glDisable(3008);
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glColor4f((color >> 16 & 0xFF) / 255.0f, (color >> 8 & 0xFF) / 255.0f, (color & 0xFF) / 255.0f, (color >> 24 & 0xFF) / 255.0f);
        GL11.glBegin(6);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d(x + Math.sin(i * 3.141592653589793 / 180.0) * radius, y + Math.cos(i * 3.141592653589793 / 180.0) * radius);
        }
        glEnd();
        GL11.glDisable(2848);
        GL11.glEnable(3553);
        GL11.glDisable(3042);
    }
    
    public static void drawLine(final float x, final float y, final float x1, final float y1, final float thickness, final int hex) {
        final float red = (hex >> 16 & 0xFF) / 255.0f;
        final float green = (hex >> 8 & 0xFF) / 255.0f;
        final float blue = (hex & 0xFF) / 255.0f;
        final float alpha = (hex >> 24 & 0xFF) / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GlStateManager.func_179103_j(7425);
        GL11.glLineWidth(thickness);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferbuilder.func_181662_b((double)x, (double)y, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b((double)x1, (double)y1, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j(7424);
        GL11.glDisable(2848);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179121_F();
    }
    
    public static void drawBlockOutline(final AxisAlignedBB bb, final Color color, final float linewidth) {
        final float red = color.getRed() / 255.0f;
        final float green = color.getGreen() / 255.0f;
        final float blue = color.getBlue() / 255.0f;
        final float alpha = color.getAlpha() / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(770, 771, 0, 1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(linewidth);
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable(2848);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }
    
    public static void setColor(final Color color) {
        GL11.glColor4d(color.getRed() / 255.0, color.getGreen() / 255.0, color.getBlue() / 255.0, color.getAlpha() / 255.0);
    }
    
    public static void drawText(final BlockPos pos, final String text) {
        GlStateManager.func_179094_E();
        glBillboardDistanceScaled(pos.func_177958_n() + 0.5f, pos.func_177956_o() + 0.5f, pos.func_177952_p() + 0.5f, (EntityPlayer)RenderUtil.mc.field_71439_g, 1.0f);
        GlStateManager.func_179097_i();
        GlStateManager.func_179137_b(-(Client.textManager.getStringWidth(text) / 2.0), 0.0, 0.0);
        Client.textManager.drawStringWithShadow(text, 0.0f, 0.0f, -5592406);
        GlStateManager.func_179121_F();
    }
    
    public static void drawRect(final float x, final float y, final float w, final float h, final int color) {
        final float alpha = (color >> 24 & 0xFF) / 255.0f;
        final float red = (color >> 16 & 0xFF) / 255.0f;
        final float green = (color >> 8 & 0xFF) / 255.0f;
        final float blue = (color & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder bufferbuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferbuilder.func_181662_b((double)x, (double)h, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b((double)w, (double)h, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b((double)w, (double)y, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b((double)x, (double)y, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }
    
    public static void glEnd() {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
        GL11.glEnable(2929);
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
    }
    
    public static void drawBox(final BlockPos pos, final Color color) {
        final AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, pos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, pos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, pos.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, pos.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, pos.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        RenderUtil.camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (RenderUtil.camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, bb.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, bb.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, bb.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, bb.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, bb.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a(770, 771, 0, 1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            RenderGlobal.func_189696_b(bb, color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
            GL11.glDisable(2848);
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }
    
    public static void drawBlockOutline(final BlockPos pos, final Color color, final float linewidth, final boolean air) {
        final IBlockState iblockstate = RenderUtil.mc.field_71441_e.func_180495_p(pos);
        if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
            final Vec3d interp = EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
            drawBlockOutline(iblockstate.func_185918_c((World)RenderUtil.mc.field_71441_e, pos).func_186662_g(0.0020000000949949026).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), color, linewidth);
        }
    }
    
    public static void drawBoxESP(final BlockPos pos, final Color color, final boolean secondC, final Color secondColor, final float lineWidth, final boolean outline, final boolean box, final int boxAlpha, final boolean air) {
        if (box) {
            drawBox(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha));
        }
        if (outline) {
            drawBlockOutline(pos, secondC ? secondColor : color, lineWidth, air);
        }
    }
    
    public static void drawPerryESP(final AxisAlignedBB a, final Color boxColor, final Color outlineColor, final float lineWidth, final boolean outline, final boolean box, float alpha, final float scale, final float slab) {
        final double f = 0.5 * (1.0f - scale);
        final AxisAlignedBB bb = interpolateAxis(new AxisAlignedBB(a.field_72340_a + f, a.field_72338_b + f + (1.0f - slab), a.field_72339_c + f, a.field_72336_d - f, a.field_72337_e - f, a.field_72334_f - f));
        final float rB = boxColor.getRed() / 255.0f;
        final float gB = boxColor.getGreen() / 255.0f;
        final float bB = boxColor.getBlue() / 255.0f;
        float aB = boxColor.getAlpha() / 255.0f;
        final float rO = outlineColor.getRed() / 255.0f;
        final float gO = outlineColor.getGreen() / 255.0f;
        final float bO = outlineColor.getBlue() / 255.0f;
        float aO = outlineColor.getAlpha() / 255.0f;
        if (alpha > 1.0f) {
            alpha = 1.0f;
        }
        aB *= alpha;
        aO *= alpha;
        if (box) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a(770, 771, 0, 1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            RenderGlobal.func_189696_b(bb, rB, gB, bB, aB);
            GL11.glDisable(2848);
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
        if (outline) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a(770, 771, 0, 1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            GL11.glLineWidth(lineWidth);
            final Tessellator tessellator = Tessellator.func_178181_a();
            final BufferBuilder bufferbuilder = tessellator.func_178180_c();
            bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
            tessellator.func_78381_a();
            GL11.glDisable(2848);
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }
    
    public static void glBillboard(final float x, final float y, final float z) {
        final float scale = 0.02666667f;
        GlStateManager.func_179137_b(x - RenderUtil.mc.func_175598_ae().field_78725_b, y - RenderUtil.mc.func_175598_ae().field_78726_c, z - RenderUtil.mc.func_175598_ae().field_78723_d);
        GlStateManager.func_187432_a(0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(-RenderUtil.mc.field_71439_g.field_70177_z, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(RenderUtil.mc.field_71439_g.field_70125_A, (RenderUtil.mc.field_71474_y.field_74320_O == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        GlStateManager.func_179152_a(-scale, -scale, scale);
    }
    
    public static void glBillboardDistanceScaled(final float x, final float y, final float z, final EntityPlayer player, final float scale) {
        glBillboard(x, y, z);
        final int distance = (int)player.func_70011_f((double)x, (double)y, (double)z);
        float scaleDistance = distance / 2.0f / (2.0f + (2.0f - scale));
        if (scaleDistance < 1.0f) {
            scaleDistance = 1.0f;
        }
        GlStateManager.func_179152_a(scaleDistance, scaleDistance, scaleDistance);
    }
    
    public static void drawBoxESPFlat(final BlockPos pos, final Color color, final boolean secondC, final Color secondColor, final float lineWidth, final boolean outline, final boolean box, final int boxAlpha, final boolean air) {
        if (box) {
            drawBoxFlat(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha));
        }
        if (outline) {
            drawBlockOutlineFlat(pos, secondC ? secondColor : color, lineWidth, air);
        }
    }
    
    public static void drawBlockOutlineFlat(final BlockPos pos, final Color color, final float linewidth, final boolean air) {
        final IBlockState iblockstate = RenderUtil.mc.field_71441_e.func_180495_p(pos);
        if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
            final Vec3d interp = EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
            drawBlockOutlineFlat(iblockstate.func_185918_c((World)RenderUtil.mc.field_71441_e, pos).func_186662_g(0.0020000000949949026).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), color, linewidth);
        }
    }
    
    public static void drawBoxFlat(final BlockPos pos, final Color color) {
        final AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, pos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, pos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, pos.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, pos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, pos.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        RenderUtil.camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (RenderUtil.camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, bb.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, bb.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, bb.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, bb.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, bb.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a(770, 771, 0, 1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            RenderGlobal.func_189696_b(bb, color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
            GL11.glDisable(2848);
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }
    
    public static void drawBlockOutlineFlat(final AxisAlignedBB bb, final Color color, final float linewidth) {
        final float red = color.getRed() / 255.0f;
        final float green = color.getGreen() / 255.0f;
        final float blue = color.getBlue() / 255.0f;
        final float alpha = color.getAlpha() / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(770, 771, 0, 1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(linewidth);
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable(2848);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }
    
    static {
        RenderUtil.itemRender = RenderUtil.mc.func_175599_af();
        RenderUtil.camera = (ICamera)new Frustum();
    }
}
