// 
// Decompiled by Procyon v0.5.36
// 

package client.util;

import net.minecraft.client.Minecraft;

public interface Util
{
    public static final Minecraft mc = Minecraft.func_71410_x();
}
