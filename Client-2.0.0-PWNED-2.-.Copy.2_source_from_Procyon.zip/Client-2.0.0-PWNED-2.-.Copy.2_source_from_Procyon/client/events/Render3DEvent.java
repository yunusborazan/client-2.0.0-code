// 
// Decompiled by Procyon v0.5.36
// 

package client.events;

public class Render3DEvent extends EventProcessor
{
    private final float partialTicks;
    
    public Render3DEvent(final float partialTicks) {
        this.partialTicks = partialTicks;
    }
    
    public float getPartialTicks() {
        return this.partialTicks;
    }
}
