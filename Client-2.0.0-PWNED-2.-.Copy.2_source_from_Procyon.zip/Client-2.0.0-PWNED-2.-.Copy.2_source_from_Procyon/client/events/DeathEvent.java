// 
// Decompiled by Procyon v0.5.36
// 

package client.events;

import net.minecraft.entity.player.EntityPlayer;

public class DeathEvent extends EventProcessor
{
    public EntityPlayer player;
    
    public DeathEvent(final EntityPlayer player) {
        this.player = player;
    }
}
