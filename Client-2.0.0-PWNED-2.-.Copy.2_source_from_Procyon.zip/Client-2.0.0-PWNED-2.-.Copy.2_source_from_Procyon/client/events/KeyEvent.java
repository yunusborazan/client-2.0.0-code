// 
// Decompiled by Procyon v0.5.36
// 

package client.events;

public class KeyEvent extends EventProcessor
{
    public boolean info;
    public boolean pressed;
    
    public KeyEvent(final int stage, final boolean info, final boolean pressed) {
        super(stage);
        this.info = info;
        this.pressed = pressed;
    }
}
