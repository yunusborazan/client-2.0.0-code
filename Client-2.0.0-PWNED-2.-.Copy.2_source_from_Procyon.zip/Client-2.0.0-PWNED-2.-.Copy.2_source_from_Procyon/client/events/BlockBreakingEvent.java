// 
// Decompiled by Procyon v0.5.36
// 

package client.events;

import net.minecraft.util.math.BlockPos;

public class BlockBreakingEvent extends EventProcessor
{
    public BlockPos pos;
    public int breakingID;
    public int breakStage;
    
    public BlockBreakingEvent(final BlockPos pos, final int breakingID, final int breakStage) {
        this.pos = pos;
        this.breakingID = breakingID;
        this.breakStage = breakStage;
    }
}
