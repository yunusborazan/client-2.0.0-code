// 
// Decompiled by Procyon v0.5.36
// 

package client.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class EventProcessor extends Event
{
    private int stage;
    
    public EventProcessor() {
    }
    
    public EventProcessor(final int stage) {
        this.stage = stage;
    }
    
    public int getStage() {
        return this.stage;
    }
    
    public void setStage(final int stage) {
        this.stage = stage;
    }
}
