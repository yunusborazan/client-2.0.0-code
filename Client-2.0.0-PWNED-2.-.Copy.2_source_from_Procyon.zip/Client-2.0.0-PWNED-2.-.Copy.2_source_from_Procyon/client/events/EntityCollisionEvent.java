// 
// Decompiled by Procyon v0.5.36
// 

package client.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class EntityCollisionEvent extends EventProcessor
{
}
